import React from 'react';
import { motion } from 'motion/react';
import { 
  LayoutDashboard, 
  Calendar, 
  Image as ImageIcon, 
  MessageSquare, 
  Users, 
  Mic, 
  Palette,
  PenTool,
  BookOpen,
  Moon, 
  Sun,
  ChevronRight,
  LogOut,
  X
} from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { Feature } from '@/src/types';

interface SidebarProps {
  activeFeature: Feature;
  onFeatureChange: (feature: Feature) => void;
  isDark: boolean;
  toggleDark: () => void;
  isOpen: boolean;
  onClose: () => void;
  onLogout: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  activeFeature, 
  onFeatureChange, 
  isDark, 
  toggleDark,
  isOpen,
  onClose,
  onLogout
}) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dasbor', icon: LayoutDashboard },
    { id: 'calendar', label: 'Kalender Konten', icon: Calendar },
    { id: 'static', label: 'Animasi Statis', icon: ImageIcon },
    { id: 'lipsync', label: 'Animasi Lipsync', icon: MessageSquare },
    { id: 'voiceover', label: 'Voice Over', icon: Mic },
    { id: 'graphic-design', label: 'Desain Grafis', icon: Palette },
    { id: 'logo-design', label: 'Desain Logo', icon: PenTool },
    { id: 'affiliate', label: 'Afiliasi', icon: Users },
    { id: 'education-promotion', label: 'Edukasi & Promosi', icon: BookOpen },
  ];

  return (
    <>
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: isOpen ? 1 : 0 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className={cn(
          "fixed inset-0 bg-slate-950/40 backdrop-blur-sm z-40 transition-all duration-300",
          isOpen ? "pointer-events-auto" : "pointer-events-none"
        )}
      />

      {/* Sidebar Drawer */}
      <motion.div 
        initial={{ x: -300 }}
        animate={{ x: isOpen ? 0 : -300 }}
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
        className="fixed left-0 top-0 w-72 h-screen bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col z-50 shadow-2xl transition-colors duration-300"
      >
        <div className="p-6 flex items-center justify-between">
          <h1 className="text-xl font-bold text-blue-600 dark:text-blue-400 tracking-tight">
            AIO Generate
            <span className="block text-xs font-normal text-slate-500 dark:text-slate-400">by AA Studio</span>
          </h1>
          <button 
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        <nav className="flex-1 px-4 space-y-1 overflow-y-auto">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeFeature === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => {
                  onFeatureChange(item.id as Feature);
                  onClose();
                }}
                className={cn(
                  "w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all duration-200 group",
                  isActive 
                    ? "bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400" 
                    : "text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50"
                )}
              >
                <div className="flex items-center gap-3">
                  <Icon size={20} className={cn(isActive ? "text-blue-600" : "text-slate-400 group-hover:text-slate-600")} />
                  <span className="font-medium text-sm">{item.label}</span>
                </div>
                {isActive && (
                  <motion.div layoutId="active-pill">
                    <ChevronRight size={16} />
                  </motion.div>
                )}
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-200 dark:border-slate-800 space-y-2">
          <button
            onClick={toggleDark}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-all"
          >
            {isDark ? <Sun size={20} /> : <Moon size={20} />}
            <span className="font-medium text-sm">{isDark ? 'Mode Terang' : 'Mode Gelap'}</span>
          </button>
          <button
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-900/20 transition-all"
          >
            <LogOut size={20} />
            <span className="font-medium text-sm">Keluar</span>
          </button>
        </div>
      </motion.div>
    </>
  );
};
