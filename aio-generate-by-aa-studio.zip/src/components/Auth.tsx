import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Lock, Mail, User, KeyRound, ArrowRight, AlertCircle, CheckCircle2 } from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface AuthProps {
  onLogin: (username: string) => void;
}

type AuthMode = 'login' | 'register' | 'forgot';

export const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [mode, setMode] = useState<AuthMode>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [masterUsername, setMasterUsername] = useState('');
  const [masterPassword, setMasterPassword] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!username || !password) {
      setError('Username dan password wajib diisi.');
      return;
    }

    // Master user check
    if (username === 'AHKP' && password === '123') {
      onLogin(username);
      return;
    }

    // Other users check
    const usersStr = localStorage.getItem('app_users');
    const users = usersStr ? JSON.parse(usersStr) : {};

    if (users[username] && users[username] === password) {
      onLogin(username);
    } else {
      setError('Username atau password salah.');
    }
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!username || !password || !confirmPassword || !masterUsername || !masterPassword) {
      setError('Semua kolom wajib diisi.');
      return;
    }

    if (masterUsername !== 'AHKP' || masterPassword !== '123') {
      setError('Otorisasi Master gagal. Hanya Master yang dapat membuat akun.');
      return;
    }

    if (password !== confirmPassword) {
      setError('Password tidak cocok.');
      return;
    }

    // Email validation for non-master users
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(username)) {
      setError('Username harus berupa alamat email yang valid.');
      return;
    }

    const usersStr = localStorage.getItem('app_users');
    const users = usersStr ? JSON.parse(usersStr) : {};

    if (users[username] || username === 'AHKP') {
      setError('Username sudah terdaftar.');
      return;
    }

    users[username] = password;
    localStorage.setItem('app_users', JSON.stringify(users));
    setSuccess('Pendaftaran berhasil! Silakan login.');
    setTimeout(() => {
      setMode('login');
      setPassword('');
      setConfirmPassword('');
      setMasterUsername('');
      setMasterPassword('');
      setSuccess('');
    }, 2000);
  };

  const handleForgot = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!username) {
      setError('Masukkan email Anda.');
      return;
    }

    const usersStr = localStorage.getItem('app_users');
    const users = usersStr ? JSON.parse(usersStr) : {};

    if (users[username]) {
      setSuccess(`Password Anda adalah: ${users[username]}`);
    } else if (username === 'AHKP') {
      setSuccess('Password master adalah: 123');
    } else {
      setError('Email tidak ditemukan.');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-blue-600 rounded-2xl mx-auto flex items-center justify-center mb-4 shadow-lg shadow-blue-500/30">
            <Lock className="text-white" size={32} />
          </div>
          <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">AIO Generate</h1>
          <p className="text-slate-500 dark:text-slate-400 mt-2">by AA Studio</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl shadow-xl border border-slate-200 dark:border-slate-800">
          <AnimatePresence mode="wait">
            <motion.div
              key={mode}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
            >
              {mode === 'login' && (
                <form onSubmit={handleLogin} className="space-y-5">
                  <div className="text-center mb-6">
                    <h2 className="text-xl font-bold text-slate-900 dark:text-white">Selamat Datang</h2>
                    <p className="text-sm text-slate-500 dark:text-slate-400">Silakan masuk ke akun Anda</p>
                  </div>

                  {error && (
                    <div className="p-3 bg-rose-50 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400 rounded-xl text-sm flex items-center gap-2">
                      <AlertCircle size={16} /> {error}
                    </div>
                  )}

                  <div className="space-y-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Username / Email</label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <User size={18} className="text-slate-400" />
                        </div>
                        <input
                          type="text"
                          value={username}
                          onChange={(e) => setUsername(e.target.value)}
                          className="w-full pl-10 p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-medium outline-none focus:ring-2 focus:ring-blue-500"
                          placeholder="Masukkan username atau email"
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Password</label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <KeyRound size={18} className="text-slate-400" />
                        </div>
                        <input
                          type="password"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="w-full pl-10 p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-medium outline-none focus:ring-2 focus:ring-blue-500"
                          placeholder="Masukkan password"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-end">
                    <button 
                      type="button" 
                      onClick={() => { setMode('forgot'); setError(''); setSuccess(''); }}
                      className="text-sm font-medium text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
                    >
                      Lupa Password?
                    </button>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold shadow-lg shadow-blue-500/30 transition-all flex items-center justify-center gap-2"
                  >
                    Lanjut ke Aplikasi <ArrowRight size={18} />
                  </button>

                  <div className="text-center pt-4 border-t border-slate-100 dark:border-slate-800">
                    <p className="text-sm text-slate-500 dark:text-slate-400">
                      Belum punya akun?{' '}
                      <button 
                        type="button" 
                        onClick={() => { setMode('register'); setError(''); setSuccess(''); }}
                        className="font-bold text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
                      >
                        Buat Akun
                      </button>
                    </p>
                  </div>
                </form>
              )}

              {mode === 'register' && (
                <form onSubmit={handleRegister} className="space-y-5">
                  <div className="text-center mb-6">
                    <h2 className="text-xl font-bold text-slate-900 dark:text-white">Buat Akun Baru</h2>
                    <p className="text-sm text-slate-500 dark:text-slate-400">Daftarkan email Anda untuk mengakses aplikasi</p>
                  </div>

                  {error && (
                    <div className="p-3 bg-rose-50 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400 rounded-xl text-sm flex items-center gap-2">
                      <AlertCircle size={16} /> {error}
                    </div>
                  )}

                  {success && (
                    <div className="p-3 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 rounded-xl text-sm flex items-center gap-2">
                      <CheckCircle2 size={16} /> {success}
                    </div>
                  )}

                  <div className="space-y-4">
                    <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl border border-blue-100 dark:border-blue-800/50 space-y-4 mb-4">
                      <div className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                        <Lock size={14} /> Otorisasi Master
                      </div>
                      <div className="space-y-1.5">
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <User size={18} className="text-slate-400" />
                          </div>
                          <input
                            type="text"
                            value={masterUsername}
                            onChange={(e) => setMasterUsername(e.target.value)}
                            className="w-full pl-10 p-3 rounded-xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-medium outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Username Master"
                          />
                        </div>
                      </div>
                      <div className="space-y-1.5">
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <KeyRound size={18} className="text-slate-400" />
                          </div>
                          <input
                            type="password"
                            value={masterPassword}
                            onChange={(e) => setMasterPassword(e.target.value)}
                            className="w-full pl-10 p-3 rounded-xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-medium outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Password Master"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Email</label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <Mail size={18} className="text-slate-400" />
                        </div>
                        <input
                          type="email"
                          value={username}
                          onChange={(e) => setUsername(e.target.value)}
                          className="w-full pl-10 p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-medium outline-none focus:ring-2 focus:ring-blue-500"
                          placeholder="nama@email.com"
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Password</label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <KeyRound size={18} className="text-slate-400" />
                        </div>
                        <input
                          type="password"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="w-full pl-10 p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-medium outline-none focus:ring-2 focus:ring-blue-500"
                          placeholder="Buat password"
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Konfirmasi Password</label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <KeyRound size={18} className="text-slate-400" />
                        </div>
                        <input
                          type="password"
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          className="w-full pl-10 p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-medium outline-none focus:ring-2 focus:ring-blue-500"
                          placeholder="Ulangi password"
                        />
                      </div>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold shadow-lg shadow-blue-500/30 transition-all"
                  >
                    Daftar Sekarang
                  </button>

                  <div className="text-center pt-4 border-t border-slate-100 dark:border-slate-800">
                    <p className="text-sm text-slate-500 dark:text-slate-400">
                      Sudah punya akun?{' '}
                      <button 
                        type="button" 
                        onClick={() => { setMode('login'); setError(''); setSuccess(''); }}
                        className="font-bold text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
                      >
                        Masuk
                      </button>
                    </p>
                  </div>
                </form>
              )}

              {mode === 'forgot' && (
                <form onSubmit={handleForgot} className="space-y-5">
                  <div className="text-center mb-6">
                    <h2 className="text-xl font-bold text-slate-900 dark:text-white">Lupa Password</h2>
                    <p className="text-sm text-slate-500 dark:text-slate-400">Masukkan email Anda untuk melihat password</p>
                  </div>

                  {error && (
                    <div className="p-3 bg-rose-50 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400 rounded-xl text-sm flex items-center gap-2">
                      <AlertCircle size={16} /> {error}
                    </div>
                  )}

                  {success && (
                    <div className="p-4 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-300 rounded-xl text-sm flex items-start gap-3 border border-emerald-200 dark:border-emerald-800">
                      <CheckCircle2 size={20} className="mt-0.5 flex-shrink-0" /> 
                      <div className="font-medium">{success}</div>
                    </div>
                  )}

                  <div className="space-y-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Email Terdaftar</label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <Mail size={18} className="text-slate-400" />
                        </div>
                        <input
                          type="text"
                          value={username}
                          onChange={(e) => setUsername(e.target.value)}
                          className="w-full pl-10 p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-medium outline-none focus:ring-2 focus:ring-blue-500"
                          placeholder="Masukkan email Anda"
                        />
                      </div>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold shadow-lg shadow-blue-500/30 transition-all"
                  >
                    Tampilkan Password
                  </button>

                  <div className="text-center pt-4 border-t border-slate-100 dark:border-slate-800">
                    <button 
                      type="button" 
                      onClick={() => { setMode('login'); setError(''); setSuccess(''); }}
                      className="text-sm font-bold text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200"
                    >
                      Kembali ke Login
                    </button>
                  </div>
                </form>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};
