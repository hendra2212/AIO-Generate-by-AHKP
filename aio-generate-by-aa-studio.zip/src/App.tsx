import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu } from 'lucide-react';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './features/Dashboard';
import { ContentCalendar } from './features/ContentCalendar';
import { StaticAnimation } from './features/StaticAnimation';
import { LipsyncAnimation } from './features/LipsyncAnimation';
import { VoiceOver } from './features/VoiceOver';
import { PromptGenerator } from './features/PromptGenerator';
import { GraphicDesign } from './features/GraphicDesign';
import { Affiliate } from './features/Affiliate';
import { LogoDesign } from './features/LogoDesign';
import { EducationPromotion } from './features/EducationPromotion';
import { Auth } from './components/Auth';
import { useDarkMode } from './hooks/useDarkMode';
import { Feature } from './types';

export default function App() {
  const [activeFeature, setActiveFeature] = useState<Feature>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('activeFeature');
      return (saved as Feature) || 'dashboard';
    }
    return 'dashboard';
  });

  useEffect(() => {
    localStorage.setItem('activeFeature', activeFeature);
  }, [activeFeature]);

  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { isDark, toggle: toggleDark } = useDarkMode();

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('isAuthenticated') === 'true';
    }
    return false;
  });

  const [currentUser, setCurrentUser] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('currentUser') || '';
    }
    return '';
  });

  const handleLogin = (username: string) => {
    setIsAuthenticated(true);
    setCurrentUser(username);
    localStorage.setItem('isAuthenticated', 'true');
    localStorage.setItem('currentUser', username);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setCurrentUser('');
    localStorage.removeItem('isAuthenticated');
    localStorage.removeItem('currentUser');
  };

  if (!isAuthenticated) {
    return <Auth onLogin={handleLogin} />;
  }

  const renderFeature = () => {
    switch (activeFeature) {
      case 'dashboard':
        return <Dashboard onFeatureChange={setActiveFeature} />;
      case 'calendar':
        return <ContentCalendar />;
      case 'static':
        return <StaticAnimation />;
      case 'lipsync':
        return <LipsyncAnimation />;
      case 'voiceover':
        return <VoiceOver />;
      case 'graphic-design':
        return <GraphicDesign />;
      case 'affiliate':
        return <Affiliate />;
      case 'logo-design':
        return <LogoDesign />;
      case 'education-promotion':
        return <EducationPromotion />;
      default:
        return <Dashboard />;
    }
  };

  const getFeatureTitle = (feature: Feature) => {
    const titles: Record<Feature, string> = {
      dashboard: 'Dasbor',
      calendar: 'Kalender Konten',
      static: 'Animasi Statis',
      lipsync: 'Animasi Lipsync',
      voiceover: 'Voice Over',
      'graphic-design': 'Desain Grafis',
      affiliate: 'Afiliasi',
      'logo-design': 'Desain Logo',
      'education-promotion': 'Edukasi & Promosi'
    };
    return titles[feature];
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 transition-colors duration-300">
      <Sidebar 
        activeFeature={activeFeature} 
        onFeatureChange={setActiveFeature}
        isDark={isDark}
        toggleDark={toggleDark}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        onLogout={handleLogout}
      />
      
      {/* Header with Toggle */}
      <header className="sticky top-0 z-30 glass border-b px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-6">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="p-2.5 -ml-2 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-900 rounded-2xl transition-all active:scale-95"
            >
              <Menu size={24} />
            </button>
            <div className="h-6 w-[1px] bg-slate-200 dark:bg-slate-800 hidden sm:block" />
            <h1 className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight hidden sm:block">
              {getFeatureTitle(activeFeature)}
            </h1>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-1 bg-slate-100 dark:bg-slate-900 p-1 rounded-xl">
              <button className="px-3 py-1.5 text-[10px] font-bold text-blue-600 dark:text-blue-400 bg-white dark:bg-slate-800 rounded-lg shadow-sm uppercase tracking-wider">Personal</button>
              <button className="px-3 py-1.5 text-[10px] font-bold text-slate-500 uppercase tracking-wider">Tim</button>
            </div>
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center text-white text-sm font-bold shadow-lg shadow-blue-500/20 uppercase">
              {currentUser.substring(0, 2)}
            </div>
          </div>
        </div>
      </header>

      <main className="p-4 sm:p-8 lg:p-12">
        <div className="max-w-7xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeFeature}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {renderFeature()}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
