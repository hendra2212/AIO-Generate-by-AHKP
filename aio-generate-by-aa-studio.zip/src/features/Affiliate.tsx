import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShoppingBag, Users, MapPin, Clock, Layers, Globe, 
  Smile, Sparkles, Upload, Image as ImageIcon, Loader2, 
  AlertCircle, Check, Copy, Video, FileText, RefreshCw,
  ChevronRight, ChevronDown, Download
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { cn } from '@/src/lib/utils';

const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

const CONTENT_STYLES = [
  "Review", "Storytelling", "Problem Solution", "Reaction", "Unboxing"
];

const DURATIONS = ["8 detik", "15 detik", "30 detik", "45 detik"];

const TONES = [
  "Santai", "Lucu", "Penasaran", "Edukatif", "Dramatis"
];

const LANGUAGES = ["Indonesia", "English"];

const GENDERS = ["Wanita", "Pria", "Netral"];
const ASPECT_RATIOS = ["9:16", "16:9", "1:1", "4:5"];

export const Affiliate: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<any>(null);
  const [copiedStates, setCopiedStates] = useState<Record<string, boolean>>({});

  const [productImage, setProductImage] = useState<string | null>(null);
  const [modelImage, setModelImage] = useState<string | null>(null);
  const [productFile, setProductFile] = useState<File | null>(null);
  const [modelFile, setModelFile] = useState<File | null>(null);

  const [formData, setFormData] = useState({
    productName: '',
    category: '',
    benefits: '',
    targetAudience: '',
    location: '',
    style: 'Review',
    sceneCount: 3,
    language: 'Indonesia',
    tone: 'Santai',
    modelVisualSuggestion: '',
    gender: 'Wanita',
    aspectRatio: '9:16'
  });

  const [sceneImages, setSceneImages] = useState<Record<number, string>>({});
  const [loadingImages, setLoadingImages] = useState<Record<number, boolean>>({});

  const resultRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (result && !loading && resultRef.current) {
      resultRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, [result, loading]);

  const handleRenderVisual = async (index: number, prompt: string) => {
    setLoadingImages(prev => ({ ...prev, [index]: true }));
    try {
      // Append aspect ratio and visual suggestion to the prompt for better adherence
      const enhancedPrompt = `${prompt}. Aspect Ratio: ${formData.aspectRatio}. ${formData.modelVisualSuggestion ? `Model details: ${formData.modelVisualSuggestion}.` : ''} ${formData.gender !== 'Netral' ? `Gender: ${formData.gender}.` : ''}`;
      const parts: any[] = [{ text: enhancedPrompt }];
      
      // Include reference images if available to guide the generation
      if (productImage && productFile) {
        parts.push({ 
          inlineData: { 
            data: productImage.split(',')[1], 
            mimeType: productFile.type 
          } 
        });
      }
      if (modelImage && modelFile) {
        parts.push({ 
          inlineData: { 
            data: modelImage.split(',')[1], 
            mimeType: modelFile.type 
          } 
        });
      }

      const response = await genAI.models.generateContent({
        model: "gemini-2.5-flash-image",
        contents: [{ role: 'user', parts: parts }],
      });

      // Find image part in response
      let generatedImage = null;
      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            generatedImage = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
            break;
          }
        }
      }

      if (generatedImage) {
        setSceneImages(prev => ({ ...prev, [index]: generatedImage }));
      } else {
        // Fallback or error handling if no image returned
        console.warn("No image generated in response");
      }

    } catch (err) {
      console.error("Failed to render visual:", err);
    } finally {
      setLoadingImages(prev => ({ ...prev, [index]: false }));
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'product' | 'model') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (type === 'product') {
          setProductImage(reader.result as string);
          setProductFile(file);
        } else {
          setModelImage(reader.result as string);
          setModelFile(file);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedStates(prev => ({ ...prev, [id]: true }));
    setTimeout(() => setCopiedStates(prev => ({ ...prev, [id]: false })), 2000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.productName || !formData.category) {
      setError("Nama Produk dan Kategori wajib diisi.");
      return;
    }
    
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const systemInstruction = `
        Anda adalah AI profesional yang ahli dalam:
        • UGC content creation
        • Affiliate marketing video
        • AI image prompt engineering
        • AI video prompt engineering
        • visual storytelling untuk TikTok / Reels / Shorts
        • consumer behavior analysis

        Tugas Anda adalah membuat konsep video UGC affiliate realistis.
        
        FACE CONSISTENCY SYSTEM (CRITICAL):
        Jika ada referensi wajah model, Anda WAJIB menganalisisnya dan membuat profil karakter yang konsisten.
        Identitas model (struktur wajah, mata, hidung, bibir, proporsi, warna kulit, rambut) HARUS TETAP SAMA di semua adegan.
        Gunakan frasa "same person from the reference face" atau "consistent face identity" dalam setiap prompt visual.

        PROSES ANALISIS AI:
        1. Analisis produk dan kategori.
        2. Analisis kebutuhan target audience.
        3. Identifikasi masalah umum yang sering dialami target audience.
        4. Pilih masalah yang paling relatable dan menarik untuk konten UGC.
        5. Buat MODEL CHARACTER PROFILE berdasarkan referensi wajah (jika ada) atau deskripsi umum jika tidak ada.

        OUTPUT HARUS DALAM FORMAT JSON:
        {
          "model_character_profile": {
            "name": "...",
            "age_approx": "...",
            "gender": "...",
            "skin_tone": "...",
            "hair_color": "...",
            "hair_length": "...",
            "hair_style": "...",
            "face_shape": "...",
            "distinguishing_features": "..."
          },
          "audience_analysis": {
            "main_problem": "...",
            "additional_problems": ["...", "...", "..."]
          },
          "scenes": [
            {
              "scene_number": 1,
              "render_image_prompt": "...",
              "visual_description": "...",
              "dialog": "...",
              "video_generator_prompt": "..."
            }
          ]
        }

        DETAIL OUTPUT PER SCENE:
        1. render_image_prompt: Prompt untuk menghasilkan gambar model menggunakan produk. WAJIB sertakan deskripsi fisik dari model_character_profile dan frasa "same [gender] model as reference photo".
        2. visual_scene_description: Deskripsi visual singkat.
        3. dialog: Dialog natural, conversational, tidak seperti iklan.
        4. video_generator_prompt: FINAL MASTER VIDEO PROMPT untuk scene ini. Prompt video detail (karakter, ekspresi, aksi, kamera, interaksi, suasana, lighting, realistic UGC style, handheld). WAJIB sertakan deskripsi fisik dari model_character_profile dan frasa "same [gender] model as reference photo". WAJIB sertakan juga dialog yang diucapkan karakter dalam format: "Character says: [DIALOG]".
      `;

      const userPrompt = `
        INPUT DATA:
        Nama Produk: ${formData.productName}
        Kategori Produk: ${formData.category}
        Manfaat Produk: ${formData.benefits}
        Target Audience: ${formData.targetAudience}
        Lokasi Scene: ${formData.location}
        Gaya Konten: ${formData.style}
        Durasi Total: ${Number(formData.sceneCount) * 8} detik (8 detik per scene)
        Jumlah Adegan: ${formData.sceneCount}
        Bahasa: ${formData.language}
        Tone: ${formData.tone}
        Gender Model: ${formData.gender}
        Rasio Video: ${formData.aspectRatio}
        Anjuran Visual Model: ${formData.modelVisualSuggestion || '-'}
      `;

      const parts: any[] = [{ text: userPrompt }];

      if (productImage && productFile) {
        parts.push({ 
          inlineData: { 
            data: productImage.split(',')[1], 
            mimeType: productFile.type 
          } 
        });
        parts.push({ text: "Ini adalah referensi foto produk." });
      }

      if (modelImage && modelFile) {
        parts.push({ 
          inlineData: { 
            data: modelImage.split(',')[1], 
            mimeType: modelFile.type 
          } 
        });
        parts.push({ text: "Ini adalah referensi wajah model. Pastikan output mengikuti wajah ini." });
      }

      const response = await genAI.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [{ role: 'user', parts: parts }],
        config: {
          systemInstruction: systemInstruction,
          responseMimeType: "application/json"
        }
      });

      const text = response.text || "{}";
      setResult(JSON.parse(text));

    } catch (err) {
      console.error(err);
      setError("Gagal menghasilkan konsep konten. Silakan coba lagi.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight flex items-center gap-3">
            <div className="p-2 bg-emerald-600 rounded-xl text-white shadow-lg shadow-emerald-500/20">
              <ShoppingBag size={24} />
            </div>
            Affiliate <span className="text-emerald-600 dark:text-emerald-400">Creator</span>
          </h2>
          <p className="text-slate-500 dark:text-slate-400 mt-1">
            Buat konten UGC affiliate yang natural dan konversi tinggi dengan AI.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Input Form */}
        <div className="lg:col-span-4 space-y-6 h-fit lg:sticky lg:top-8">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div className="flex items-center gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
              <Video className="w-5 h-5 text-emerald-600" />
              <h3 className="font-bold text-slate-900 dark:text-white uppercase tracking-widest text-xs">Detail Produk & Konten</h3>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Product & Model Images */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Foto Produk</label>
                  <div className="relative group aspect-square">
                    <input 
                      type="file" 
                      accept="image/*"
                      onChange={(e) => handleFileUpload(e, 'product')}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                    />
                    <div className={cn(
                      "w-full h-full rounded-2xl border-2 border-dashed transition-all flex flex-col items-center justify-center gap-2 overflow-hidden",
                      productImage 
                        ? "border-emerald-500 bg-emerald-50 dark:bg-emerald-900/10" 
                        : "border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 hover:border-emerald-400"
                    )}>
                      {productImage ? (
                        <img src={productImage} alt="Product" className="w-full h-full object-cover" />
                      ) : (
                        <div className="flex flex-col items-center text-slate-400">
                          <Upload size={20} className="mb-1" />
                          <span className="text-[10px] font-bold">Upload</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Wajah Model</label>
                  <div className="relative group aspect-square">
                    <input 
                      type="file" 
                      accept="image/*"
                      onChange={(e) => handleFileUpload(e, 'model')}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                    />
                    <div className={cn(
                      "w-full h-full rounded-2xl border-2 border-dashed transition-all flex flex-col items-center justify-center gap-2 overflow-hidden",
                      modelImage 
                        ? "border-emerald-500 bg-emerald-50 dark:bg-emerald-900/10" 
                        : "border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 hover:border-emerald-400"
                    )}>
                      {modelImage ? (
                        <img src={modelImage} alt="Model" className="w-full h-full object-cover" />
                      ) : (
                        <div className="flex flex-col items-center text-slate-400">
                          <Upload size={20} className="mb-1" />
                          <span className="text-[10px] font-bold">Upload</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Basic Info */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Nama Produk</label>
                  <input 
                    type="text" 
                    name="productName"
                    value={formData.productName}
                    onChange={handleInputChange}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-medium outline-none focus:ring-2 focus:ring-emerald-500"
                    placeholder="Contoh: Serum Wajah Glowing"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Kategori</label>
                  <input 
                    type="text" 
                    name="category"
                    value={formData.category}
                    onChange={handleInputChange}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-medium outline-none focus:ring-2 focus:ring-emerald-500"
                    placeholder="Contoh: Skincare / Elektronik"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Manfaat Utama</label>
                  <textarea 
                    name="benefits"
                    value={formData.benefits}
                    onChange={handleInputChange}
                    rows={2}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-medium outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
                    placeholder="Jelaskan manfaat produk..."
                  />
                </div>
              </div>

              {/* Target & Location */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Target Audience</label>
                  <input 
                    type="text" 
                    name="targetAudience"
                    value={formData.targetAudience}
                    onChange={handleInputChange}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-medium outline-none focus:ring-2 focus:ring-emerald-500"
                    placeholder="Mahasiswa, Ibu..."
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Lokasi Scene</label>
                  <input 
                    type="text" 
                    name="location"
                    value={formData.location}
                    onChange={handleInputChange}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-medium outline-none focus:ring-2 focus:ring-emerald-500"
                    placeholder="Kamar, Mobil..."
                  />
                </div>
              </div>

              {/* Model Details */}
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Gender Model</label>
                    <select 
                      name="gender"
                      value={formData.gender}
                      onChange={handleInputChange}
                      className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-medium outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      {GENDERS.map(g => <option key={g} value={g}>{g}</option>)}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Rasio Video</label>
                    <select 
                      name="aspectRatio"
                      value={formData.aspectRatio}
                      onChange={handleInputChange}
                      className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-medium outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      {ASPECT_RATIOS.map(r => <option key={r} value={r}>{r}</option>)}
                    </select>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Anjuran Visual Model (Opsional)</label>
                  <input 
                    type="text" 
                    name="modelVisualSuggestion"
                    value={formData.modelVisualSuggestion}
                    onChange={handleInputChange}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-medium outline-none focus:ring-2 focus:ring-emerald-500"
                    placeholder="Contoh: Berjilbab, Kacamata, Rambut Pendek..."
                  />
                </div>
              </div>

              {/* Style & Tone */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Gaya Konten</label>
                  <select 
                    name="style"
                    value={formData.style}
                    onChange={handleInputChange}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-medium outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    {CONTENT_STYLES.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Tone</label>
                  <select 
                    name="tone"
                    value={formData.tone}
                    onChange={handleInputChange}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-medium outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    {TONES.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
              </div>

              {/* Duration & Scenes */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Jml Scene</label>
                  <input 
                    type="number" 
                    name="sceneCount"
                    min="1" max="10"
                    value={formData.sceneCount}
                    onChange={handleInputChange}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-medium outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Total Durasi</label>
                  <div className="w-full p-3 rounded-xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-500 dark:text-slate-400 flex items-center">
                    {Number(formData.sceneCount) * 8} Detik (Otomatis)
                  </div>
                </div>
              </div>

              {/* Language */}
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Bahasa</label>
                <select 
                  name="language"
                  value={formData.language}
                  onChange={handleInputChange}
                  className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-medium outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  {LANGUAGES.map(l => <option key={l} value={l}>{l}</option>)}
                </select>
              </div>

              <button 
                type="submit" 
                disabled={loading}
                className={cn(
                  "w-full py-4 rounded-xl font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 transition-all shadow-lg",
                  loading 
                    ? "bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed" 
                    : "bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-500/30 hover:-translate-y-1 active:translate-y-0"
                )}
              >
                {loading ? <Loader2 className="animate-spin" size={18} /> : <Sparkles size={18} />}
                {loading ? "Menganalisis..." : "Generate Konsep UGC"}
              </button>
            </form>
          </div>

          {error && (
            <div className="bg-rose-50 dark:bg-rose-900/20 border border-rose-100 dark:border-rose-800 p-4 rounded-xl flex items-start gap-3 text-rose-600 dark:text-rose-300">
              <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <p className="text-sm font-medium">{error}</p>
            </div>
          )}
        </div>

        {/* Output Section */}
        <div className="lg:col-span-8 space-y-8">
          {!result && !loading && (
            <div className="bg-white dark:bg-slate-900 p-12 rounded-3xl border-2 border-dashed border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center text-center h-full min-h-[500px] space-y-6">
              <div className="w-20 h-20 bg-slate-50 dark:bg-slate-950 rounded-2xl flex items-center justify-center text-slate-200 dark:text-slate-800">
                <ShoppingBag size={40} />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">Belum Ada Konsep</h3>
                <p className="text-slate-500 dark:text-slate-400 max-w-sm mx-auto text-base">
                  Isi detail produk dan upload referensi untuk membuat konsep video affiliate yang menarik.
                </p>
              </div>
            </div>
          )}

          {loading && (
            <div className="bg-white dark:bg-slate-900 p-12 rounded-3xl border border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center text-center h-full min-h-[500px] shadow-sm space-y-8">
              <div className="relative">
                <div className="w-20 h-20 border-4 border-emerald-100 dark:border-emerald-900 rounded-full" />
                <div className="w-20 h-20 border-4 border-emerald-600 rounded-full border-t-transparent animate-spin absolute top-0" />
                <Sparkles className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-emerald-600" size={28} />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">Menganalisis Produk</h3>
                <p className="text-slate-500 dark:text-slate-400 text-base">Sedang merancang strategi UGC yang relatable...</p>
              </div>
            </div>
          )}

          {result && !loading && (
            <div ref={resultRef} className="space-y-8">
              {/* Model Character Profile */}
              {result.model_character_profile && (
                <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
                  <div className="bg-slate-50 dark:bg-slate-950/50 px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3">
                    <Smile className="text-emerald-600" size={20} />
                    <h3 className="font-black text-slate-900 dark:text-white uppercase tracking-widest text-sm">Model Character Profile</h3>
                  </div>
                  <div className="p-6 grid grid-cols-2 md:grid-cols-3 gap-4">
                    {Object.entries(result.model_character_profile).map(([key, value]) => (
                      <div key={key} className="space-y-1">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{key.replace(/_/g, ' ')}</span>
                        <p className="text-sm font-medium text-slate-800 dark:text-slate-200 capitalize">{String(value)}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Audience Analysis */}
              <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
                <div className="bg-slate-50 dark:bg-slate-950/50 px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3">
                  <Users className="text-emerald-600" size={20} />
                  <h3 className="font-black text-slate-900 dark:text-white uppercase tracking-widest text-sm">Audience Problem Analysis</h3>
                </div>
                <div className="p-6 space-y-6">
                  <div className="space-y-2">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Masalah Utama</span>
                    <p className="text-lg font-medium text-slate-800 dark:text-slate-200">"{result.audience_analysis.main_problem}"</p>
                  </div>
                  <div className="space-y-3">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Masalah Tambahan</span>
                    <ul className="space-y-2">
                      {result.audience_analysis.additional_problems.map((prob: string, i: number) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-slate-600 dark:text-slate-400">
                          <span className="w-5 h-5 rounded-full bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 flex items-center justify-center text-[10px] font-bold flex-shrink-0 mt-0.5">{i + 1}</span>
                          {prob}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              {/* Scenes */}
              <div className="space-y-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-emerald-600 rounded-lg text-white">
                    <Layers size={18} />
                  </div>
                  <h3 className="font-black text-slate-900 dark:text-white uppercase tracking-widest text-lg">Daftar Adegan</h3>
                </div>

                {result.scenes.map((scene: any, idx: number) => (
                  <motion.div 
                    key={idx}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.1 }}
                    className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm hover:shadow-md transition-all"
                  >
                    <div className="bg-slate-50 dark:bg-slate-950/50 px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
                      <span className="bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 px-3 py-1 rounded-lg text-xs font-black uppercase tracking-wider">
                        Scene {scene.scene_number}
                      </span>
                    </div>
                    
                    <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-8">
                      {/* Visual & Dialog */}
                      <div className="space-y-6">
                        <div className="space-y-2">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                            <ImageIcon size={12} /> Deskripsi Visual
                          </span>
                          <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">{scene.visual_description}</p>
                          
                          {/* Rendered Image Area */}
                          <div className="mt-4">
                            {sceneImages[idx] ? (
                              <div className="relative aspect-video rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 group">
                                <img src={sceneImages[idx]} alt={`Scene ${scene.scene_number}`} className="w-full h-full object-cover" />
                                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                                  <button 
                                    onClick={() => {
                                      const link = document.createElement('a');
                                      link.href = sceneImages[idx];
                                      link.download = `scene-${scene.scene_number}-render.png`;
                                      link.click();
                                    }}
                                    className="p-2 bg-white/20 hover:bg-white/40 rounded-lg text-white transition-colors"
                                    title="Download Image"
                                  >
                                    <Download size={16} />
                                  </button>
                                  <button 
                                    onClick={() => handleRenderVisual(idx, scene.render_image_prompt)}
                                    className="p-2 bg-white/20 hover:bg-white/40 rounded-lg text-white transition-colors"
                                    title="Regenerate"
                                  >
                                    <RefreshCw size={16} />
                                  </button>
                                </div>
                              </div>
                            ) : (
                              <button
                                onClick={() => handleRenderVisual(idx, scene.render_image_prompt)}
                                disabled={loadingImages[idx]}
                                className="w-full aspect-video rounded-xl border-2 border-dashed border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center gap-2 text-slate-400 hover:text-emerald-600 hover:border-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-900/10 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                              >
                                {loadingImages[idx] ? (
                                  <>
                                    <Loader2 size={24} className="animate-spin text-emerald-600" />
                                    <span className="text-xs font-bold text-emerald-600">Rendering...</span>
                                  </>
                                ) : (
                                  <>
                                    <ImageIcon size={24} />
                                    <span className="text-xs font-bold uppercase tracking-wider">Render Visual Scene</span>
                                  </>
                                )}
                              </button>
                            )}
                          </div>
                        </div>
                        <div className="space-y-2">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                            <Smile size={12} /> Dialog
                          </span>
                          <div className="bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 p-4 rounded-xl relative">
                            <p className="text-sm font-medium text-slate-800 dark:text-slate-200 italic">"{scene.dialog}"</p>
                          </div>
                        </div>
                      </div>

                      {/* Prompts */}
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Render Image Prompt</span>
                            <button onClick={() => copyToClipboard(scene.render_image_prompt, `img-${idx}`)} className="text-slate-400 hover:text-emerald-600 transition-colors">
                              {copiedStates[`img-${idx}`] ? <Check size={14} /> : <Copy size={14} />}
                            </button>
                          </div>
                          <div className="bg-slate-900 p-3 rounded-xl text-[10px] font-mono text-slate-400 leading-relaxed h-24 overflow-y-auto custom-scrollbar">
                            {scene.render_image_prompt}
                          </div>
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Final Master Video Prompt</span>
                            <button onClick={() => copyToClipboard(scene.video_generator_prompt, `vid-${idx}`)} className="text-slate-400 hover:text-emerald-600 transition-colors">
                              {copiedStates[`vid-${idx}`] ? <Check size={14} /> : <Copy size={14} />}
                            </button>
                          </div>
                          <div className="bg-slate-900 p-3 rounded-xl text-[10px] font-mono text-slate-400 leading-relaxed h-24 overflow-y-auto custom-scrollbar">
                            {scene.video_generator_prompt}
                          </div>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
