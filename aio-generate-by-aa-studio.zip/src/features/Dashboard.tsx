import React from 'react';
import { motion } from 'motion/react';
import { 
  TrendingUp, Zap, Clock, Star, Sparkles, 
  Calendar, Image as ImageIcon, MessageSquare, Mic, Users,
  ChevronRight, LayoutDashboard
} from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { Feature } from '@/src/types';

interface DashboardProps {
  onFeatureChange?: (feature: Feature) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onFeatureChange }) => {
  const stats = [
    { label: 'Total Prompt', value: '1,284', icon: Zap, color: 'text-blue-600', bg: 'bg-blue-100' },
    { label: 'Proyek Aktif', value: '12', icon: Clock, color: 'text-emerald-600', bg: 'bg-emerald-100' },
    { label: 'Tingkat Generasi', value: '+24%', icon: TrendingUp, color: 'text-purple-600', bg: 'bg-purple-100' },
    { label: 'Templat Tersimpan', value: '48', icon: Star, color: 'text-amber-600', bg: 'bg-amber-100' },
  ];

  const features = [
    { 
      id: 'calendar', 
      label: 'Kalender Konten', 
      icon: Calendar, 
      desc: 'Jadwalkan dan kelola strategi konten media sosial Anda.',
      color: 'text-blue-600',
      bg: 'bg-blue-50 dark:bg-blue-900/20',
      border: 'border-blue-100 dark:border-blue-800'
    },
    { 
      id: 'static', 
      label: 'Animasi Statis', 
      icon: ImageIcon, 
      desc: 'Ubah gambar statis menjadi video animasi yang memukau.',
      color: 'text-indigo-600',
      bg: 'bg-indigo-50 dark:bg-indigo-900/20',
      border: 'border-indigo-100 dark:border-indigo-800'
    },
    { 
      id: 'lipsync', 
      label: 'Animasi Lipsync', 
      icon: MessageSquare, 
      desc: 'Sinkronkan gerakan bibir karakter dengan audio apa pun.',
      color: 'text-purple-600',
      bg: 'bg-purple-50 dark:bg-purple-900/20',
      border: 'border-purple-100 dark:border-purple-800'
    },
    { 
      id: 'voiceover', 
      label: 'Voice Over', 
      icon: Mic, 
      desc: 'Hasilkan suara narasi AI yang natural dan ekspresif.',
      color: 'text-rose-600',
      bg: 'bg-rose-50 dark:bg-rose-900/20',
      border: 'border-rose-100 dark:border-rose-800'
    },
    { 
      id: 'affiliate', 
      label: 'Afiliasi', 
      icon: Users, 
      desc: 'Strategi konten viral UGC untuk meningkatkan konversi affiliate Anda.',
      color: 'text-emerald-600',
      bg: 'bg-emerald-50 dark:bg-emerald-900/20',
      border: 'border-emerald-100 dark:border-emerald-800'
    },
  ];

  return (
    <div className="space-y-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">Selamat datang kembali, Kreator</h2>
          <p className="text-slate-500 dark:text-slate-400 mt-1">Pilih alat yang ingin Anda gunakan hari ini.</p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider">Sistem Optimal</span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="group p-5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-all duration-300"
          >
            <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center mb-4 transition-transform group-hover:scale-110", stat.bg)}>
              <stat.icon className={stat.color} size={20} />
            </div>
            <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">{stat.label}</p>
            <h3 className="text-2xl font-bold text-slate-900 dark:text-white mt-1 tracking-tight">{stat.value}</h3>
          </motion.div>
        ))}
      </div>

      {/* Features Grid */}
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-600 rounded-xl text-white shadow-lg shadow-blue-500/20">
            <LayoutDashboard size={20} />
          </div>
          <h3 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">Eksplorasi Fitur</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => (
            <motion.button
              key={feature.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 + (i * 0.05) }}
              onClick={() => onFeatureChange?.(feature.id as Feature)}
              className={cn(
                "group p-8 rounded-[2.5rem] border text-left transition-all duration-500 relative overflow-hidden",
                "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800",
                "hover:shadow-2xl hover:shadow-blue-500/10 hover:-translate-y-2 hover:border-blue-400 dark:hover:border-blue-600"
              )}
            >
              <div className="relative z-10">
                <div className={cn("w-16 h-16 rounded-3xl flex items-center justify-center mb-6 transition-all duration-500 group-hover:rotate-12 group-hover:scale-110 shadow-lg shadow-black/5", feature.bg)}>
                  <feature.icon className={feature.color} size={32} />
                </div>
                <h4 className="text-xl font-bold text-slate-900 dark:text-white mb-2 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                  {feature.label}
                </h4>
                <p className="text-sm text-slate-500 dark:text-slate-400 leading-relaxed mb-6">
                  {feature.desc}
                </p>
                <div className="flex items-center gap-2 text-xs font-bold text-blue-600 dark:text-blue-400 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-x-[-10px] group-hover:translate-x-0">
                  Buka Sekarang <ChevronRight size={14} />
                </div>
              </div>
              
              {/* Decorative background element */}
              <div className={cn(
                "absolute -right-8 -bottom-8 w-32 h-32 opacity-5 transition-all duration-700 group-hover:scale-150 group-hover:opacity-10",
                feature.color
              )}>
                <feature.icon size={128} />
              </div>
            </motion.button>
          ))}

          {/* Quick Tips Card */}
          <div className="p-8 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-[2.5rem] text-white shadow-xl shadow-blue-500/20 relative overflow-hidden group flex flex-col justify-between">
            <div className="relative z-10">
              <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center mb-6">
                <Sparkles size={24} />
              </div>
              <h3 className="text-xl font-bold mb-2">Tips Pro</h3>
              <p className="text-blue-100 text-sm leading-relaxed">
                Gunakan fitur Animasi Lipsync untuk membuat karakter Anda berbicara dengan emosi yang lebih nyata.
              </p>
            </div>
            <button className="relative z-10 mt-6 px-6 py-3 bg-white text-blue-600 rounded-2xl text-xs font-bold hover:bg-blue-50 transition-colors w-fit">
              Pelajari Tekniknya
            </button>
            <Sparkles className="absolute -right-4 -bottom-4 w-40 h-40 text-white/10 group-hover:scale-110 transition-transform duration-700" />
          </div>
        </div>
      </div>

      {/* System Status Footer */}
      <div className="p-6 bg-slate-100 dark:bg-slate-800/50 rounded-3xl flex flex-wrap items-center justify-center gap-8">
        {[
          { label: 'AI Engine', status: 'Online', color: 'bg-emerald-500' },
          { label: 'API Gateway', status: 'Online', color: 'bg-emerald-500' },
          { label: 'Storage', status: 'Optimal', color: 'bg-blue-500' },
        ].map((item) => (
          <div key={item.label} className="flex items-center gap-3">
            <span className={cn("w-2 h-2 rounded-full", item.color)} />
            <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">{item.label}</span>
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300">{item.status}</span>
          </div>
        ))}
      </div>
    </div>
  );
};
