import React, { useState, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import { 
  Mic, Play, Square, Download, RefreshCw, 
  Settings, Volume2, Clock, User, Type, 
  Loader2, AlertCircle, FileAudio
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

const VOICES = [
  { id: 'Kore', name: 'Kore (Female, Soothing)', gender: 'Female' },
  { id: 'Fenrir', name: 'Fenrir (Male, Deep)', gender: 'Male' },
  { id: 'Puck', name: 'Puck (Male, Energetic)', gender: 'Male' },
  { id: 'Charon', name: 'Charon (Male, Deep)', gender: 'Male' },
  { id: 'Zephyr', name: 'Zephyr (Female, Calm)', gender: 'Female' },
];

const TEMPOS = [
  { id: 'normal', label: 'Normal' },
  { id: 'slow', label: 'Lambat' },
  { id: 'fast', label: 'Cepat' },
];

const STYLES = [
  { id: 'natural', label: 'Natural' },
  { id: 'enthusiastic', label: 'Antusias' },
  { id: 'professional', label: 'Profesional' },
  { id: 'custom', label: 'Custom' },
];

const writeString = (view: DataView, offset: number, string: string) => {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
};

export const VoiceOver: React.FC = () => {
  const [script, setScript] = useState('');
  const [selectedVoice, setSelectedVoice] = useState(VOICES[0].id);
  const [selectedTempo, setSelectedTempo] = useState(TEMPOS[0].id);
  const [selectedStyle, setSelectedStyle] = useState(STYLES[0].id);
  const [customStyle, setCustomStyle] = useState('');
  
  const [isGenerating, setIsGenerating] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement>(null);

  React.useEffect(() => {
    if (audioUrl && audioRef.current) {
      audioRef.current.load();
      audioRef.current.play().catch(e => console.log("Auto-play prevented:", e));
    }
  }, [audioUrl]);

  const handleGenerate = async () => {
    if (!script.trim()) {
      setError('Mohon isi naskah terlebih dahulu.');
      return;
    }

    setIsGenerating(true);
    setError(null);
    setAudioUrl(null);

    try {
      let instruction = "";
      
      // Construct instruction based on style and tempo
      let styleText = "";
      if (selectedStyle === 'custom') {
        styleText = customStyle;
      } else if (selectedStyle !== 'natural') {
        styleText = selectedStyle; // enthusiastic, professional
      }

      let tempoText = "";
      if (selectedTempo === 'slow') tempoText = "slowly";
      if (selectedTempo === 'fast') tempoText = "quickly";

      if (styleText || tempoText) {
        instruction = `Say ${styleText}${styleText && tempoText ? ' and ' : ''}${tempoText}: `;
      }

      const finalPrompt = `${instruction}${script}`;

      const response = await genAI.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: finalPrompt }] }],
        config: {
          responseModalities: ["AUDIO"],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: selectedVoice },
            },
          },
        },
      });

      const part = response.candidates?.[0]?.content?.parts?.[0];
      const base64Audio = part?.inlineData?.data;
      const apiMimeType = part?.inlineData?.mimeType;
      
      if (base64Audio) {
        const binaryString = window.atob(base64Audio);
        const len = binaryString.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
          bytes[i] = binaryString.charCodeAt(i);
        }

        let mimeType = apiMimeType || 'audio/mpeg';
        let finalBytes = bytes;

        // Check for RIFF header (WAV)
        const isWav = bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46;
        // Check for MP3 sync word (approximate)
        const isMp3 = bytes[0] === 0xFF && (bytes[1] & 0xE0) === 0xE0;

        if (!isWav && !isMp3) {
          console.log("No header detected, assuming raw PCM 24kHz Mono 16-bit. Adding WAV header...");
          // Construct WAV header for 24kHz, 1 channel, 16-bit PCM
          const wavHeader = new ArrayBuffer(44);
          const view = new DataView(wavHeader);
          
          const sampleRate = 24000;
          const numChannels = 1;
          const bitsPerSample = 16;
          
          // RIFF chunk descriptor
          writeString(view, 0, 'RIFF');
          view.setUint32(4, 36 + bytes.length, true); // File size - 8
          writeString(view, 8, 'WAVE');
          
          // fmt sub-chunk
          writeString(view, 12, 'fmt ');
          view.setUint32(16, 16, true); // Subchunk1Size (16 for PCM)
          view.setUint16(20, 1, true); // AudioFormat (1 for PCM)
          view.setUint16(22, numChannels, true); // NumChannels
          view.setUint32(24, sampleRate, true); // SampleRate
          view.setUint32(28, sampleRate * numChannels * (bitsPerSample / 8), true); // ByteRate
          view.setUint16(32, numChannels * (bitsPerSample / 8), true); // BlockAlign
          view.setUint16(34, bitsPerSample, true); // BitsPerSample
          
          // data sub-chunk
          writeString(view, 36, 'data');
          view.setUint32(40, bytes.length, true); // Subchunk2Size
          
          // Combine header and data
          const headerBytes = new Uint8Array(wavHeader);
          const combined = new Uint8Array(headerBytes.length + bytes.length);
          combined.set(headerBytes);
          combined.set(bytes, headerBytes.length);
          
          finalBytes = combined;
          mimeType = 'audio/wav';
        } else if (isWav) {
          mimeType = 'audio/wav';
        }

        console.log("Final MIME type:", mimeType);
        
        const blob = new Blob([finalBytes], { type: mimeType });
        const url = URL.createObjectURL(blob);
        setAudioUrl(url);
      } else {
        throw new Error("Gagal menghasilkan audio. Respons kosong dari AI.");
      }

    } catch (err) {
      console.error(err);
      setError('Terjadi kesalahan saat membuat voice over. Silakan coba lagi.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleReset = () => {
    if (window.confirm('Reset semua pengaturan?')) {
      setScript('');
      setSelectedVoice(VOICES[0].id);
      setSelectedTempo(TEMPOS[0].id);
      setSelectedStyle(STYLES[0].id);
      setCustomStyle('');
      setAudioUrl(null);
      setError(null);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-xl shadow-indigo-500/20">
              <Mic size={24} />
            </div>
            <h2 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight">Voice Over AI</h2>
          </div>
          <p className="text-slate-500 dark:text-slate-400 max-w-2xl text-lg">
            Ubah naskah teks menjadi suara manusia yang natural dengan berbagai karakter dan gaya bicara.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Configuration Panel */}
        <div className="lg:col-span-4 space-y-6 h-fit lg:sticky lg:top-8">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <Settings className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-slate-900 dark:text-white uppercase tracking-widest text-xs">Konfigurasi Suara</h3>
              </div>
              <button
                onClick={handleReset}
                className="text-xs text-slate-400 hover:text-rose-500 flex items-center gap-1.5 transition-colors font-medium"
              >
                <RefreshCw size={12} />
                Reset
              </button>
            </div>

            <div className="space-y-5">
              {/* Voice Selection */}
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <User size={12} /> Karakter Suara
                </label>
                <div className="grid grid-cols-1 gap-2">
                  {VOICES.map((voice) => (
                    <button
                      key={voice.id}
                      onClick={() => setSelectedVoice(voice.id)}
                      className={`
                        flex items-center justify-between p-3 rounded-xl border text-left transition-all
                        ${selectedVoice === voice.id 
                          ? 'bg-indigo-50 dark:bg-indigo-900/20 border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300' 
                          : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-indigo-300'}
                      `}
                    >
                      <span className="text-sm font-bold">{voice.name}</span>
                      {selectedVoice === voice.id && <div className="w-2 h-2 rounded-full bg-indigo-600" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Tempo Selection */}
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <Clock size={12} /> Tempo Bicara
                </label>
                <div className="flex bg-slate-100 dark:bg-slate-950 p-1 rounded-xl">
                  {TEMPOS.map((tempo) => (
                    <button
                      key={tempo.id}
                      onClick={() => setSelectedTempo(tempo.id)}
                      className={`
                        flex-1 py-2 text-xs font-bold rounded-lg transition-all
                        ${selectedTempo === tempo.id 
                          ? 'bg-white dark:bg-slate-800 text-indigo-600 shadow-sm' 
                          : 'text-slate-500 hover:text-slate-700'}
                      `}
                    >
                      {tempo.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Style Selection */}
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <Volume2 size={12} /> Gaya Bicara
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {STYLES.map((style) => (
                    <button
                      key={style.id}
                      onClick={() => setSelectedStyle(style.id)}
                      className={`
                        py-2.5 px-3 text-xs font-bold rounded-xl border transition-all text-center
                        ${selectedStyle === style.id 
                          ? 'bg-indigo-50 dark:bg-indigo-900/20 border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300' 
                          : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-indigo-300'}
                      `}
                    >
                      {style.label}
                    </button>
                  ))}
                </div>
                {selectedStyle === 'custom' && (
                  <input
                    type="text"
                    value={customStyle}
                    onChange={(e) => setCustomStyle(e.target.value)}
                    placeholder="Contoh: Sedih, Berbisik, Marah..."
                    className="w-full mt-2 p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Input & Output Area */}
        <div className="lg:col-span-8 space-y-8">
          {/* Script Input */}
          <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Type size={18} className="text-indigo-600" />
                <h3 className="font-bold text-slate-900 dark:text-white uppercase tracking-widest text-sm">Naskah / Script</h3>
              </div>
              <span className="text-xs font-bold text-slate-400 bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded-full">
                {script.length} Karakter
              </span>
            </div>
            
            <textarea
              value={script}
              onChange={(e) => setScript(e.target.value)}
              placeholder="Tulis naskah yang ingin Anda ubah menjadi suara di sini..."
              className="w-full h-48 p-6 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white text-lg leading-relaxed focus:ring-2 focus:ring-indigo-500 outline-none resize-none placeholder:text-slate-400"
            />

            <div className="flex justify-end">
              <button
                onClick={handleGenerate}
                disabled={isGenerating || !script.trim()}
                className={`
                  px-8 py-4 rounded-xl font-black text-sm uppercase tracking-widest flex items-center gap-3 transition-all shadow-xl
                  ${isGenerating || !script.trim()
                    ? 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                    : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-500/30 hover:-translate-y-1 active:translate-y-0'}
                `}
              >
                {isGenerating ? <Loader2 className="animate-spin" size={20} /> : <Play size={20} fill="currentColor" />}
                {isGenerating ? 'Memproses Audio...' : 'Generate Voice Over'}
              </button>
            </div>
          </div>

          {/* Error Message */}
          {error && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-rose-50 dark:bg-rose-900/20 border border-rose-100 dark:border-rose-800 p-6 rounded-2xl flex items-center gap-4 text-rose-700 dark:text-rose-300"
            >
              <AlertCircle size={24} />
              <p className="font-medium">{error}</p>
            </motion.div>
          )}

          {/* Audio Result */}
          <AnimatePresence>
            {audioUrl && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-slate-900 dark:bg-black p-8 rounded-[2.5rem] border border-slate-800 shadow-2xl relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-600/20 blur-[100px] rounded-full" />
                
                <div className="relative z-10 space-y-6">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-indigo-500 flex items-center justify-center text-white animate-pulse">
                      <FileAudio size={24} />
                    </div>
                    <div>
                      <h3 className="text-xl font-black text-white tracking-tight">Audio Berhasil Dibuat!</h3>
                      <p className="text-indigo-200 text-sm">Siap untuk didengarkan atau diunduh.</p>
                    </div>
                  </div>

                  <div className="bg-white/10 rounded-2xl p-4 backdrop-blur-sm border border-white/10">
                    <audio 
                      key={audioUrl}
                      ref={audioRef} 
                      controls 
                      src={audioUrl} 
                      className="w-full h-10 [&::-webkit-media-controls-panel]:bg-transparent [&::-webkit-media-controls-enclosure]:bg-transparent"
                    />
                  </div>

                  <div className="flex justify-end">
                    <a
                      href={audioUrl}
                      download={`voiceover-${Date.now()}.mp3`}
                      className="px-6 py-3 bg-white text-slate-900 rounded-xl font-bold text-sm uppercase tracking-wider flex items-center gap-2 hover:bg-indigo-50 transition-colors shadow-lg"
                    >
                      <Download size={18} />
                      Download MP3
                    </a>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};
