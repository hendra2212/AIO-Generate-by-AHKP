import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  BookOpen, Target, Briefcase, MapPin, Palette, Sparkles, 
  Loader2, AlertCircle, Check, Copy, Film, MessageSquare,
  Image as ImageIcon, Video, FileText, Clock
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { cn } from '@/src/lib/utils';

const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

const VISUAL_STYLES = [
  "3D Cartoon", "Claymation", "Realistic CGI", "Anime", "Cinematic", "Minimalist Vector", "Custom"
];

const PURPOSES = ["Edukasi", "Promosi"];

export const EducationPromotion: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<any>(null);
  const [copiedStates, setCopiedStates] = useState<Record<string, boolean>>({});

  const [formData, setFormData] = useState({
    title: '',
    purpose: 'Edukasi',
    profession: '',
    location: '',
    sceneCount: '3',
    visualStyle: '3D Cartoon',
    customStyle: ''
  });

  const resultRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (result && !loading && resultRef.current) {
      resultRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, [result, loading]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedStates(prev => ({ ...prev, [id]: true }));
    setTimeout(() => setCopiedStates(prev => ({ ...prev, [id]: false })), 2000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.profession || !formData.location) {
      setError("Judul, Profesi, dan Lokasi wajib diisi.");
      return;
    }
    
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const systemInstruction = `
        Anda adalah seorang Creative Director dan Scriptwriter profesional yang ahli dalam membuat konten edukasi dan promosi berkualitas tinggi.
        Tugas Anda adalah membuat naskah dan panduan visual untuk video pendek berdasarkan input pengguna.

        STRUKTUR OUTPUT HARUS DALAM FORMAT JSON:
        {
          "description": "Deskripsi singkat 3-5 paragraf tentang judul/topik yang diangkat...",
          "scenes": [
            {
              "scene_number": 1,
              "visual_description": "Deskripsi visual detail untuk scene ini...",
              "dialog": "Dialog natural selama 8 detik (MAKSIMAL 20 KATA)...",
              "text_to_image_prompt": "Prompt ultra-detail untuk generator gambar (Midjourney/DALL-E). Prompt HARUS mencakup: 1. Karakter Utama (penampilan, ekspresi, pakaian), 2. Objek (detail benda di sekitar), 3. Environment (latar belakang, pencahayaan, suasana), 4. Kamera (angle, shot type, focal length). Semua harus mengikuti Visual Description dan Gaya Visual yang dipilih.",
              "image_to_video_prompt": "Prompt detail untuk generator video (Luma/Runway/Kling). WAJIB sertakan dialog dalam format: 'Character says: [DIALOG]'. Pastikan prompt menjelaskan gerakan dan suasana."
            }
          ]
        }

        ATURAN:
        1. Setiap scene berdurasi tepat 8 detik.
        2. Gaya visual harus konsisten di seluruh scene.
        3. Dialog harus informatif (untuk edukasi) atau persuasif (untuk promosi) dan MAKSIMAL 20 KATA per scene.
        4. Prompt AI harus ultra-detail dan profesional.
      `;

      const userPrompt = `
        Judul: ${formData.title}
        Tujuan: ${formData.purpose}
        Profesi: ${formData.profession}
        Lokasi: ${formData.location}
        Jumlah Scene: ${formData.sceneCount}
        Gaya Visual: ${formData.visualStyle === 'Custom' ? formData.customStyle : formData.visualStyle}
        Durasi per Scene: 8 detik
      `;

      const response = await genAI.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [{ role: 'user', parts: [{ text: userPrompt }] }],
        config: {
          systemInstruction: systemInstruction,
          responseMimeType: "application/json"
        }
      });

      const text = response.text || "{}";
      setResult(JSON.parse(text));

    } catch (err) {
      console.error(err);
      setError("Gagal menghasilkan konten. Silakan coba lagi.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight flex items-center gap-3">
            <div className="p-2 bg-emerald-600 rounded-xl text-white shadow-lg shadow-emerald-500/20">
              <BookOpen size={24} />
            </div>
            Edukasi & <span className="text-emerald-600 dark:text-emerald-400">Promosi</span>
          </h2>
          <p className="text-slate-500 dark:text-slate-400 mt-1">
            Buat konten video edukatif dan promotif profesional dengan panduan visual AI.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Input Form */}
        <div className="lg:col-span-4 space-y-6 h-fit lg:sticky lg:top-8">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div className="flex items-center gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
              <FileText className="w-5 h-5 text-emerald-600" />
              <h3 className="font-bold text-slate-900 dark:text-white uppercase tracking-widest text-xs">Konten Brief</h3>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Judul Konten *</label>
                  <input 
                    type="text" 
                    name="title"
                    value={formData.title}
                    onChange={handleInputChange}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-medium outline-none focus:ring-2 focus:ring-emerald-500"
                    placeholder="Contoh: Manfaat Menabung Sejak Dini"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Tujuan</label>
                    <select 
                      name="purpose"
                      value={formData.purpose}
                      onChange={handleInputChange}
                      className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-medium outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      {PURPOSES.map(p => <option key={p} value={p}>{p}</option>)}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Jml Scene</label>
                    <input 
                      type="number" 
                      name="sceneCount"
                      min="1" max="10"
                      value={formData.sceneCount}
                      onChange={handleInputChange}
                      className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-medium outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Profesi *</label>
                  <input 
                    type="text" 
                    name="profession"
                    value={formData.profession}
                    onChange={handleInputChange}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-medium outline-none focus:ring-2 focus:ring-emerald-500"
                    placeholder="Contoh: Guru, Dokter, Sales..."
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Lokasi Edukasi/Promosi *</label>
                  <input 
                    type="text" 
                    name="location"
                    value={formData.location}
                    onChange={handleInputChange}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-medium outline-none focus:ring-2 focus:ring-emerald-500"
                    placeholder="Contoh: Ruang Kelas, Rumah Sakit, Kantor..."
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Gaya Visual</label>
                  <select 
                    name="visualStyle"
                    value={formData.visualStyle}
                    onChange={handleInputChange}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-medium outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    {VISUAL_STYLES.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>

                {formData.visualStyle === 'Custom' && (
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Gaya Custom</label>
                    <input 
                      type="text" 
                      name="customStyle"
                      value={formData.customStyle}
                      onChange={handleInputChange}
                      className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-medium outline-none focus:ring-2 focus:ring-emerald-500"
                      placeholder="Masukkan gaya visual custom..."
                    />
                  </div>
                )}
              </div>

              <button 
                type="submit" 
                disabled={loading}
                className={cn(
                  "w-full py-4 rounded-xl font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 transition-all shadow-lg",
                  loading 
                    ? "bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed" 
                    : "bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-500/30 hover:-translate-y-1 active:translate-y-0"
                )}
              >
                {loading ? <Loader2 className="animate-spin" size={18} /> : <Sparkles size={18} />}
                {loading ? "Menyusun Materi..." : "Generate Konten"}
              </button>
            </form>
          </div>

          {error && (
            <div className="bg-rose-50 dark:bg-rose-900/20 border border-rose-100 dark:border-rose-800 p-4 rounded-xl flex items-start gap-3 text-rose-600 dark:text-rose-300">
              <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <p className="text-sm font-medium">{error}</p>
            </div>
          )}
        </div>

        {/* Output Section */}
        <div className="lg:col-span-8 space-y-8">
          {!result && !loading && (
            <div className="bg-white dark:bg-slate-900 p-12 rounded-3xl border-2 border-dashed border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center text-center h-full min-h-[500px] space-y-6">
              <div className="w-20 h-20 bg-slate-50 dark:bg-slate-950 rounded-2xl flex items-center justify-center text-slate-200 dark:text-slate-800">
                <Film size={40} />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">Belum Ada Konten</h3>
                <p className="text-slate-500 dark:text-slate-400 max-w-sm mx-auto text-base">
                  Isi brief di samping untuk mulai merancang materi edukasi atau promosi Anda.
                </p>
              </div>
            </div>
          )}

          {loading && (
            <div className="bg-white dark:bg-slate-900 p-12 rounded-3xl border border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center text-center h-full min-h-[500px] shadow-sm space-y-8">
              <div className="relative">
                <div className="w-20 h-20 border-4 border-emerald-100 dark:border-emerald-900 rounded-full" />
                <div className="w-20 h-20 border-4 border-emerald-600 rounded-full border-t-transparent animate-spin absolute top-0" />
                <Sparkles className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-emerald-600" size={28} />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">Menyusun Konten</h3>
                <p className="text-slate-500 dark:text-slate-400 text-base">Menganalisis topik, membuat narasi, dan menyusun panduan visual...</p>
              </div>
            </div>
          )}

          {result && !loading && (
            <div ref={resultRef} className="space-y-8 animate-in slide-in-from-bottom-4 duration-700">
              
              {/* Description */}
              <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
                <div className="bg-slate-50 dark:bg-slate-950/50 px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3">
                  <FileText className="text-emerald-600" size={20} />
                  <h3 className="font-black text-slate-900 dark:text-white uppercase tracking-widest text-sm">Deskripsi Konten</h3>
                </div>
                <div className="p-8 prose dark:prose-invert max-w-none">
                  <div className="text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap text-sm">
                    {result.description}
                  </div>
                </div>
              </div>

              {/* Scenes */}
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-emerald-600 rounded-lg text-white">
                      <Film size={18} />
                    </div>
                    <h3 className="font-black text-slate-900 dark:text-white uppercase tracking-widest text-lg">Detail Per Adegan (8 Detik/Scene)</h3>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-6">
                  {result.scenes.map((scene: any, idx: number) => (
                    <motion.div 
                      key={idx}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.1 }}
                      className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm"
                    >
                      <div className="bg-slate-50 dark:bg-slate-950/50 px-6 py-3 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <span className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-black">
                            {scene.scene_number}
                          </span>
                          <h4 className="font-bold text-slate-900 dark:text-white text-sm">Scene {scene.scene_number}</h4>
                        </div>
                        <div className="flex items-center gap-2 text-slate-400">
                          <Clock size={14} />
                          <span className="text-[10px] font-bold uppercase tracking-widest">8 Detik</span>
                        </div>
                      </div>

                      <div className="p-6 space-y-6">
                        {/* Visual & Dialog */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="space-y-2">
                            <div className="flex items-center gap-2 text-emerald-600">
                              <ImageIcon size={14} />
                              <span className="text-[10px] font-bold uppercase tracking-widest">Visual Description</span>
                            </div>
                            <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">{scene.visual_description}</p>
                          </div>
                          <div className="space-y-2">
                            <div className="flex items-center gap-2 text-blue-600">
                              <MessageSquare size={14} />
                              <span className="text-[10px] font-bold uppercase tracking-widest">Dialog (8s)</span>
                            </div>
                            <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-2xl border border-blue-100 dark:border-blue-800 italic text-sm text-blue-900 dark:text-blue-100">
                              "{scene.dialog}"
                            </div>
                          </div>
                        </div>

                        {/* Prompts */}
                        <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-800">
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2 text-indigo-600">
                                <Sparkles size={14} />
                                <span className="text-[10px] font-bold uppercase tracking-widest">Text-to-Image Prompt</span>
                              </div>
                              <button 
                                onClick={() => copyToClipboard(scene.text_to_image_prompt, `t2i-${idx}`)}
                                className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors text-slate-400 hover:text-indigo-600"
                              >
                                {copiedStates[`t2i-${idx}`] ? <Check size={14} /> : <Copy size={14} />}
                              </button>
                            </div>
                            <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800">
                              <p className="text-xs font-mono text-slate-300 leading-relaxed">{scene.text_to_image_prompt}</p>
                            </div>
                          </div>

                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2 text-purple-600">
                                <Video size={14} />
                                <span className="text-[10px] font-bold uppercase tracking-widest">Image-to-Video Prompt (Master)</span>
                              </div>
                              <button 
                                onClick={() => copyToClipboard(scene.image_to_video_prompt, `i2v-${idx}`)}
                                className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors text-slate-400 hover:text-purple-600"
                              >
                                {copiedStates[`i2v-${idx}`] ? <Check size={14} /> : <Copy size={14} />}
                              </button>
                            </div>
                            <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800">
                              <p className="text-xs font-mono text-slate-300 leading-relaxed">{scene.image_to_video_prompt}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>

            </div>
          )}
        </div>
      </div>
    </div>
  );
};
