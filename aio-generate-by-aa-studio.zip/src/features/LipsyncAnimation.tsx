import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Film, Wand2, Users, Clapperboard, Copy, Check, Loader2, 
  Sparkles, AlertCircle, ChevronRight, Monitor, Smartphone, 
  Tablet as TabletIcon, Feather, Music, Zap, Download,
  MessageSquare, RefreshCw, Eye, Trash2, Plus, Mic, Settings
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { cn } from '@/src/lib/utils';

// --- API Configuration using SDK ---
const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

const callGeminiAPI = async (promptText: string, systemInstruction: string) => {
  try {
    const model = "gemini-3-flash-preview";
    const response = await genAI.models.generateContent({
      model: model,
      contents: [{ role: 'user', parts: [{ text: promptText }] }],
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json"
      }
    });
    return response.text || "{}";
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Gagal menghubungi AI.");
  }
};

const callGeminiText = async (promptText: string) => {
  try {
    const model = "gemini-3-flash-preview";
    const response = await genAI.models.generateContent({
      model: model,
      contents: [{ role: 'user', parts: [{ text: promptText }] }]
    });
    return response.text || "";
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Gagal menghubungi AI.");
  }
};

export const LipsyncAnimation: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [generatingIdea, setGeneratingIdea] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<any>(null);

  const [copiedStates, setCopiedStates] = useState<Record<string, boolean>>({});
  const [suggestedTitles, setSuggestedTitles] = useState<string[]>([]);
  const [generatingTitle, setGeneratingTitle] = useState(false);
  const [loadingDialogues, setLoadingDialogues] = useState<Record<number, boolean>>({});
  const [loadingBackstories, setLoadingBackstories] = useState<Record<number, boolean>>({});
  const [generatingTwist, setGeneratingTwist] = useState(false);
  const [loadingAudio, setLoadingAudio] = useState<Record<number, boolean>>({});
  const [referenceImage, setReferenceImage] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);

  const [formData, setFormData] = useState({
    title: '',
    theme: 'Edukasi',
    style: 'Pixar 3D',
    visualSuggestion: '',
    idea: '',
    sceneCount: 3,
    characterCount: 2,
    aspectRatio: '16:9'
  });

  const resultRef = useRef<HTMLDivElement>(null);

  // --- Persistence Logic ---
  useEffect(() => {
    const savedState = localStorage.getItem('lipsyncAnimationState');
    if (savedState) {
      try {
        const parsed = JSON.parse(savedState);
        const savedTime = parsed.timestamp;
        const currentTime = new Date().getTime();

        // Check if 1 hour (3600000 ms) has passed
        if (savedTime && (currentTime - savedTime < 3600000)) {
          if (parsed.formData) setFormData(parsed.formData);
          if (parsed.result) setResult(parsed.result);
          if (parsed.suggestedTitles) setSuggestedTitles(parsed.suggestedTitles);
          if (parsed.referenceImage) setReferenceImage(parsed.referenceImage);
        } else {
          // Clear expired state
          localStorage.removeItem('lipsyncAnimationState');
        }
      } catch (e) {
        console.error("Failed to load saved state", e);
      }
    }
  }, []);

  useEffect(() => {
    const stateToSave = {
      timestamp: new Date().getTime(),
      formData,
      result,
      suggestedTitles,
      referenceImage
    };
    localStorage.setItem('lipsyncAnimationState', JSON.stringify(stateToSave));
  }, [formData, result, suggestedTitles, referenceImage]);

  useEffect(() => {
    if (result && !loading && resultRef.current) {
      resultRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, [result, loading]);

  const handleReset = () => {
    if (window.confirm('Apakah Anda yakin ingin mereset semua data formulir? Data yang belum disimpan akan hilang.')) {
      setFormData({
        title: '',
        theme: 'Edukasi',
        style: 'Pixar 3D',
        visualSuggestion: '',
        idea: '',
        sceneCount: 3,
        characterCount: 2,
        aspectRatio: '16:9'
      });
      setResult(null);
      setReferenceImage(null);
      setImageFile(null);
      setSuggestedTitles([]);
    }
  };

  const themes = ['Edukasi', 'Promosi / Iklan', 'Hiburan', 'Penjelasan (Explainer)', 'Cerita Pendek', 'Layanan Masyarakat'];
  const styles = ['Pixar 3D', '3D Cartoon', 'Claymation Realistis', 'Anime Style', '2D Vector Flat', 'Cyberpunk 3D', 'Hyper-realistic CGI'];
  const aspectRatios = ['16:9', '9:16', '1:1', '4:3', '21:9'];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedStates(prev => ({ ...prev, [id]: true }));
    setTimeout(() => setCopiedStates(prev => ({ ...prev, [id]: false })), 2000);
  };

  const handleSuggestTitles = async () => {
    if (!formData.title) {
      setError("Isi Judul Animasi terlebih dahulu.");
      return;
    }
    setGeneratingTitle(true);
    setError(null);
    try {
      const prompt = `Berikan 5 saran judul alternatif yang SANGAT MENARIK dan berpotensi VIRAL untuk animasi tema "${formData.theme}" berdasarkan judul awal: "${formData.title}". Keluarkan HANYA format array JSON string: ["Judul 1", "Judul 2", "Judul 3", "Judul 4", "Judul 5"].`;
      const resText = await callGeminiAPI(prompt, "Anda adalah Pakar SEO dan Viral Content.");
      setSuggestedTitles(JSON.parse(resText));
    } catch (err) {
      setError("Gagal menghasilkan opsi judul.");
    } finally {
      setGeneratingTitle(false);
    }
  };

  const handleAutoGenerateIdea = async () => {
    if (!formData.title) {
      setError("Isi Judul Animasi terlebih dahulu.");
      return;
    }
    setGeneratingIdea(true);
    setError(null);
    try {
      const prompt = `Buatkan ide cerita/sinopsis SANGAT DETAIL dan sempurna untuk produksi animasi. Judul: "${formData.title}", Tema: ${formData.theme}, Gaya: ${formData.style}. Tulis sinopsis 3-5 paragraf mencakup latar, karakter, konflik, dan resolusi. Langsung ke isi teks.`;
      const resText = await callGeminiText(prompt);
      setFormData(prev => ({ ...prev, idea: resText.trim() }));
    } catch (err) {
      setError("Gagal menghasilkan ide cerita.");
    } finally {
      setGeneratingIdea(false);
    }
  };

  const handleGenerateTwist = async () => {
    if (!formData.idea) {
      setError("Isi Ide Cerita terlebih dahulu untuk menambahkan Plot Twist.");
      return;
    }
    setGeneratingTwist(true);
    setError(null);
    try {
      const prompt = `Berikan satu Plot Twist (kejutan cerita) yang sangat cerdas, tak terduga, namun masuk akal untuk melanjutkan atau mengubah arah cerita berikut: "${formData.idea}". Tema: ${formData.theme}. Keluarkan HANYA teks plot twist-nya saja dalam 1-2 kalimat Bahasa Indonesia tanpa kata pengantar.`;
      const resText = await callGeminiText(prompt);
      setFormData(prev => ({ 
        ...prev, 
        idea: prev.idea + "\n\nPlot Twist: " + resText.trim() 
      }));
    } catch (err) {
      setError("Gagal menghasilkan plot twist.");
    } finally {
      setGeneratingTwist(false);
    }
  };

  const handleGenerateBackstory = async (idx: number) => {
    setLoadingBackstories(prev => ({ ...prev, [idx]: true }));
    try {
      const char = result.master_characters[idx];
      const prompt = `Buatkan backstory singkat 2-3 kalimat untuk karakter animasi: ${char.name}, Peran: ${char.role}, Cerita: ${result.title}.`;
      const resText = await callGeminiText(prompt);
      setResult((prev: any) => {
        const newRes = { ...prev };
        newRes.master_characters[idx].backstory = resText.trim();
        return newRes;
      });
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingBackstories(prev => ({ ...prev, [idx]: false }));
    }
  };

  const handleEnhanceDialogue = async (idx: number) => {
    setLoadingDialogues(prev => ({ ...prev, [idx]: true }));
    try {
      const scene = result.scenes[idx];
      const prompt = `Perbagus dialog animasi ini agar lebih emosional/dramatis sesuai konteks. Narasi: ${scene.narration}, Dialog Asli: ${scene.dialogue}. Keluarkan HANYA teks dialog baru dengan format "[Nama Karakter]: [Isi Dialog]".`;
      const resText = await callGeminiText(prompt);
      setResult((prev: any) => {
        const newRes = { ...prev };
        newRes.scenes[idx].dialogue = resText.trim();
        return newRes;
      });
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingDialogues(prev => ({ ...prev, [idx]: false }));
    }
  };

  const handleGenerateAudio = async (idx: number) => {
    setLoadingAudio(prev => ({ ...prev, [idx]: true }));
    try {
      const scene = result.scenes[idx];
      const prompt = `Sebagai Audio Director untuk animasi, berikan saran panduan Background Music (BGM) dan Efek Suara (SFX) yang dramatis dan tepat untuk mendukung adegan berikut: "${scene.narration}". Keluarkan HANYA 1-2 kalimat singkat dalam Bahasa Indonesia.`;
      const resText = await callGeminiText(prompt);
      setResult((prev: any) => {
        const newRes = { ...prev };
        newRes.scenes[idx].audio_cue = resText.trim();
        return newRes;
      });
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingAudio(prev => ({ ...prev, [idx]: false }));
    }
  };

  const handleDownloadScript = () => {
    if (!result) return;
    let content = `JUDUL: ${result.title}\nTEMA: ${formData.theme}\nGAYA VISUAL: ${formData.style}\n\n`;
    content += `================ MASTER KARAKTER ================\n\n`;
    result.master_characters.forEach((c: any) => {
      content += `NAMA: ${c.name} (${c.role})\nSIFAT: ${c.personality}\n`;
      if (c.backstory) content += `LATAR BELAKANG: ${c.backstory}\n`;
      content += `VISUAL PROMPT:\n${c.visual_description}\n\n`;
    });
    content += `================ DAFTAR SCENE ================\n\n`;
    result.scenes.forEach((s: any) => {
      content += `--- SCENE ${s.scene_number} ---\n`;
      content += `NARASI: ${s.narration}\n`;
      if (s.audio_cue) content += `AUDIO (BGM/SFX): ${s.audio_cue}\n`;
      content += `DIALOG: "${s.dialogue}"\n\n`;
      content += `TEXT-TO-IMAGE PROMPT:\n${s.text_to_image_prompt}\n\n`;
      content += `IMAGE-TO-VIDEO PROMPT:\n${s.image_to_video_prompt}\n\n`;
    });

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${result.title.replace(/\s+/g, '_')}_Production_Script.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.idea || !formData.title) {
      setError("Judul dan Ide tidak boleh kosong.");
      return;
    }
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      let systemInstruction = "";
      const t2iTemplate = `
        VISUAL STYLE
        The entire scene must be rendered using visual style: ${formData.style}
        SCENE DETAILS
        [SCENE_DESCRIPTION_BASED_ON_NARRATION]
        CAMERA POSITION
        Camera distance: [Specify appropriate camera distance, e.g., Close Up, Medium Shot, Wide Shot]
        OBJECT CONSISTENCY
        Maintain realistic proportions between humans and objects
        Environmental structure must remain consistent with the reference
        Main visual elements must remain recognizable
        VISUAL QUALITY
        Very high quality CGI render
        Highly detailed
        High resolution
        Cinematic composition
        Realistic lighting
      `;

      const i2vTemplate = `
        Create a concise image-to-video prompt for Leonardo AI.

        STYLE: ${formData.style}
        DURATION: 8 seconds

        ACTION:
        The main character [CHARACTER_NAME] performs:
        [CONCISE_ACTION_DESCRIPTION_BASED_ON_NARRATION]

        LIPSYNC:
        Speaking Character: [CHARACTER_NAME]
        Character Details: [BRIEF_VISUAL_DETAILS]
        Dialog: "[DIALOG_CONTENT_INDONESIAN]"
        
        REQUIREMENTS:
        - Maintain exact face & body from image
        - Natural movement & expressions
        - Consistent environment
        - No background music/subtitles
      `;

      if (formData.style === 'Claymation Realistis') {
        systemInstruction = `Anda adalah seorang clay animator profesional. Ubah ide cerita menjadi adegan animasi claymation bergaya plastisin realistis (Nano Banana Pro & Veo 3.1). 
        Format adegan: 1 narasi = 1 adegan (sebutkan bagian narasi mana yang dianimasikan dalam Bahasa Indonesia). 
        JANGAN ADA EFEK GLOWING. Clay halus tanpa sidik jari. 
        
        ATURAN BAHASA:
        1. Narasi, Dialog (field "dialogue"), dan Deskripsi Karakter WAJIB Bahasa Indonesia.
        2. "text_to_image_prompt" WAJIB Bahasa Inggris.
        3. "image_to_video_prompt" WAJIB Bahasa Inggris, KECUALI bagian "Dialog Lipsync" di dalamnya yang WAJIB Bahasa Indonesia.
        
        ATURAN FORMAT KONTEN:
        1. Field "narration" WAJIB format: "Narasi: [Teks Narasi]. Visual: [Deskripsi Visual detail apa yang terlihat di layar, termasuk aksi karakter]".
        2. Field "dialogue" WAJIB format: "[Nama Karakter]: [Isi Dialog]". Pastikan nama karakter tertulis jelas di awal setiap dialog.

        Untuk bagian "text_to_image_prompt", gunakan struktur berikut (dalam Bahasa Inggris):
        ${t2iTemplate}
        Untuk bagian "image_to_video_prompt", gunakan struktur berikut (dalam Bahasa Inggris, kecuali Dialog):
        ${i2vTemplate}
        Master karakter: ${formData.characterCount}. Scene: ${formData.sceneCount}.
        Output JSON format: { "title": "...", "master_characters": [{ "name": "...", "role": "...", "personality": "...", "visual_description": "..." }], "scenes": [{ "scene_number": 1, "narration": "...", "dialogue": "...", "text_to_image_prompt": "...", "image_to_video_prompt": "..." }] }`;
      } else {
        systemInstruction = `Sutradara Animasi AI. Buat dokumen produksi animasi. Judul: "${formData.title}", Gaya: ${formData.style}, Rasio: ${formData.aspectRatio}. 
        
        ATURAN BAHASA:
        1. Narasi, Dialog (field "dialogue"), dan Deskripsi Karakter WAJIB Bahasa Indonesia.
        2. "text_to_image_prompt" WAJIB Bahasa Inggris.
        3. "image_to_video_prompt" WAJIB Bahasa Inggris, KECUALI bagian "Dialog Lipsync" di dalamnya yang WAJIB Bahasa Indonesia.
        
        ATURAN FORMAT KONTEN:
        1. Field "narration" WAJIB format: "Narasi: [Teks Narasi]. Visual: [Deskripsi Visual detail apa yang terlihat di layar, termasuk aksi karakter]".
        2. Field "dialogue" WAJIB format: "[Nama Karakter]: [Isi Dialog]". Pastikan nama karakter tertulis jelas di awal setiap dialog.

        Untuk bagian "text_to_image_prompt", gunakan struktur berikut (dalam Bahasa Inggris):
        ${t2iTemplate}
        Untuk bagian "image_to_video_prompt", gunakan struktur berikut (dalam Bahasa Inggris, kecuali Dialog):
        ${i2vTemplate}
        Master karakter: ${formData.characterCount}. Scene: ${formData.sceneCount}. 
        Pastikan alur nyambung kronologis.
        Output JSON format: { "title": "...", "master_characters": [{ "name": "...", "role": "...", "personality": "...", "visual_description": "..." }], "scenes": [{ "scene_number": 1, "narration": "...", "dialogue": "...", "text_to_image_prompt": "...", "image_to_video_prompt": "..." }] }`;
      }

      const prompt = `Ide: ${formData.title}. Detail: ${formData.idea}. ${formData.visualSuggestion ? `Anjuran Visual Tambahan: ${formData.visualSuggestion}.` : ''} Buat ${formData.sceneCount} scene dan ${formData.characterCount} karakter.`;
      
      let resultText = "";
      if (referenceImage) {
        const model = "gemini-3-flash-preview";
        const response = await genAI.models.generateContent({
          model: model,
          contents: [{ 
            role: 'user', 
            parts: [
              { inlineData: { data: referenceImage.split(',')[1], mimeType: imageFile?.type || 'image/png' } },
              { text: prompt }
            ] 
          }],
          config: {
            systemInstruction: systemInstruction,
            responseMimeType: "application/json"
          }
        });
        resultText = response.text || "{}";
      } else {
        resultText = await callGeminiAPI(prompt, systemInstruction);
      }
      
      setResult(JSON.parse(resultText));
    } catch (err) {
      setError("Gagal merender data animasi. Silakan coba lagi.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-10">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-slate-900 dark:bg-white flex items-center justify-center text-white dark:text-slate-900 shadow-xl">
              <MessageSquare size={24} />
            </div>
            <h2 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight">Animasi Lipsync</h2>
          </div>
          <p className="text-slate-500 dark:text-slate-400 max-w-2xl text-lg">
            Rancang skrip produksi animasi lengkap dengan master karakter, dialog lipsync, dan prompt visual AI.
          </p>
        </div>
        <div className="flex items-center gap-3 p-1 bg-slate-100 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
           <div className="flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-bold text-slate-500 uppercase tracking-wider"><Monitor size={14} /> Desktop</div>
           <div className="flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-bold text-slate-500 uppercase tracking-wider"><TabletIcon size={14} /> Tablet</div>
           <div className="flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-bold text-slate-500 uppercase tracking-wider"><Smartphone size={14} /> Mobile</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Sidebar Input */}
        <div className="lg:col-span-4 space-y-6 h-fit lg:sticky lg:top-8">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <Settings className="w-5 h-5 text-blue-600" />
                <h3 className="font-bold text-slate-900 dark:text-white uppercase tracking-widest text-xs">Konfigurasi Proyek</h3>
              </div>
              <button
                onClick={handleReset}
                className="text-xs text-slate-400 hover:text-rose-500 flex items-center gap-1.5 transition-colors font-medium"
                title="Reset Form"
              >
                <RefreshCw size={12} />
                Reset
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Upload Gambar Referensi */}
              <div className="space-y-3">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">Gambar Referensi (Opsional)</label>
                <div className="relative group">
                  <input 
                    type="file" 
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        setImageFile(file);
                        const reader = new FileReader();
                        reader.onloadend = () => setReferenceImage(reader.result as string);
                        reader.readAsDataURL(file);
                      }
                    }}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                  />
                  <div className={cn(
                    "p-6 rounded-2xl border-2 border-dashed transition-all flex flex-col items-center justify-center gap-2",
                    referenceImage 
                      ? "bg-blue-50 dark:bg-blue-900/10 border-blue-400 dark:border-blue-600" 
                      : "bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 group-hover:border-blue-400"
                  )}>
                    {referenceImage ? (
                      <div className="relative w-full aspect-video rounded-xl overflow-hidden">
                        <img src={referenceImage} alt="Reference" className="w-full h-full object-cover" />
                        <button 
                          onClick={(e) => {
                            e.preventDefault();
                            setReferenceImage(null);
                            setImageFile(null);
                          }}
                          className="absolute top-2 right-2 p-1.5 bg-white/80 dark:bg-black/80 rounded-lg text-rose-600 hover:bg-white dark:hover:bg-black transition-all z-20"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    ) : (
                      <>
                        <div className="w-12 h-12 rounded-2xl bg-white dark:bg-slate-900 flex items-center justify-center text-slate-400 group-hover:text-blue-600 transition-colors shadow-sm">
                          <Plus size={24} />
                        </div>
                        <p className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Klik atau seret gambar</p>
                      </>
                    )}
                  </div>
                </div>
              </div>

              {/* Judul */}
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <label className="text-sm font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">Judul Animasi</label>
                  <button 
                    type="button" 
                    onClick={handleSuggestTitles}
                    disabled={generatingTitle || loading}
                    className="flex items-center gap-1.5 px-3 py-1 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-lg text-[10px] font-bold uppercase tracking-wider hover:bg-blue-100 transition-colors disabled:opacity-50"
                  >
                    {generatingTitle ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                    Ide Viral
                  </button>
                </div>
                <input 
                  type="text" 
                  name="title"
                  value={formData.title}
                  onChange={handleInputChange}
                  placeholder="misal: Petualangan Budi di Mars"
                  className="w-full p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none transition-all text-sm font-medium"
                  required
                />
                <AnimatePresence>
                  {suggestedTitles.length > 0 && (
                    <motion.div 
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="grid grid-cols-1 gap-2 pt-2"
                    >
                      {suggestedTitles.map((t, i) => (
                        <button
                          key={i}
                          type="button"
                          onClick={() => { setFormData(prev => ({ ...prev, title: t })); setSuggestedTitles([]); }}
                          className="text-left text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 hover:border-blue-400 p-3 rounded-xl text-slate-600 dark:text-slate-400 transition-all flex items-center justify-between group"
                        >
                          {t} <ChevronRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-all" />
                        </button>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Tema & Gaya */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Tema</label>
                  <select 
                    name="theme" 
                    value={formData.theme}
                    onChange={handleInputChange}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white text-xs font-bold outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {themes.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Gaya Visual</label>
                  <select 
                    name="style" 
                    value={formData.style}
                    onChange={handleInputChange}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white text-xs font-bold outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {styles.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              </div>

              {/* Karakter & Rasio */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Jml Karakter</label>
                  <input 
                    type="number" 
                    name="characterCount"
                    min="1" max="15" 
                    value={formData.characterCount}
                    onChange={handleInputChange}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white text-xs font-bold outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Rasio Aspek</label>
                  <select 
                    name="aspectRatio" 
                    value={formData.aspectRatio}
                    onChange={handleInputChange}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white text-xs font-bold outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {aspectRatios.map(r => <option key={r} value={r}>{r}</option>)}
                  </select>
                </div>
              </div>

              {/* Anjuran Visual */}
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Anjuran Visual (Opsional)</label>
                <textarea
                  name="visualSuggestion"
                  value={formData.visualSuggestion}
                  onChange={handleInputChange}
                  rows={3}
                  className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white text-sm font-medium outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                  placeholder="Deskripsikan detail visual khusus yang diinginkan..."
                />
              </div>

              {/* Ide Cerita */}
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <label className="text-sm font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">Ide Cerita</label>
                  <div className="flex gap-2">
                    <button 
                      type="button" 
                      onClick={handleGenerateTwist}
                      disabled={generatingTwist || !formData.idea || loading}
                      className="p-1.5 bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400 rounded-lg hover:bg-amber-100 transition-colors disabled:opacity-50"
                      title="Plot Twist"
                    >
                      {generatingTwist ? <Loader2 size={14} className="animate-spin" /> : <Zap size={14} />}
                    </button>
                    <button 
                      type="button" 
                      onClick={handleAutoGenerateIdea}
                      disabled={generatingIdea || loading}
                      className="p-1.5 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-lg hover:bg-blue-100 transition-colors disabled:opacity-50"
                      title="Sempurnakan"
                    >
                      {generatingIdea ? <Loader2 size={14} className="animate-spin" /> : <Wand2 size={14} />}
                    </button>
                  </div>
                </div>
                <textarea 
                  name="idea"
                  value={formData.idea}
                  onChange={handleInputChange}
                  rows={5}
                  className="w-full p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none transition-all text-sm leading-relaxed resize-none"
                  placeholder="Ketik sinopsis singkat atau biarkan AI membantu..."
                />
              </div>

              {/* Jml Scene */}
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Jumlah Scene</label>
                <input 
                  type="number" 
                  name="sceneCount"
                  min="1" max="50" 
                  value={formData.sceneCount}
                  onChange={handleInputChange}
                  className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white text-xs font-bold outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <button 
                type="submit" 
                disabled={loading}
                className={cn(
                  "w-full py-5 rounded-2xl font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 transition-all shadow-xl",
                  loading 
                    ? "bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed" 
                    : "bg-blue-600 hover:bg-blue-700 text-white shadow-blue-500/30 hover:-translate-y-1 active:translate-y-0"
                )}
              >
                {loading ? <Loader2 className="animate-spin" size={20} /> : <Sparkles size={20} />}
                {loading ? "Menyusun Konsep..." : "Generate Script & Prompt"}
              </button>
            </form>
          </div>
          
          {error && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-rose-50 dark:bg-rose-900/20 border border-rose-100 dark:border-rose-800 p-6 rounded-3xl flex items-start gap-4 text-rose-700 dark:text-rose-300"
            >
              <AlertCircle className="w-6 h-6 flex-shrink-0" />
              <p className="text-sm font-bold">{error}</p>
            </motion.div>
          )}
        </div>

        {/* Output Section */}
        <div className="lg:col-span-8 space-y-8">
          {!result && !loading && (
             <div className="bg-white dark:bg-slate-900 p-12 rounded-3xl border-2 border-dashed border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center text-center h-full min-h-[500px] space-y-6">
               <div className="w-20 h-20 bg-slate-50 dark:bg-slate-950 rounded-2xl flex items-center justify-center text-slate-200 dark:text-slate-800">
                 <Clapperboard size={40} />
               </div>
               <div className="space-y-2">
                 <h3 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">Belum Ada Proyek</h3>
                 <p className="text-slate-500 dark:text-slate-400 max-w-sm mx-auto text-base">
                   Isi konfigurasi di sebelah kiri untuk mulai merancang naskah produksi animasi Anda.
                 </p>
               </div>
             </div>
          )}

          {loading && (
             <div className="bg-white dark:bg-slate-900 p-12 rounded-3xl border border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center text-center h-full min-h-[500px] shadow-sm space-y-8">
               <div className="relative">
                 <div className="w-20 h-20 border-4 border-blue-100 dark:border-blue-900 rounded-full" />
                 <div className="w-20 h-20 border-4 border-blue-600 rounded-full border-t-transparent animate-spin absolute top-0" />
                 <Sparkles className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-blue-600" size={28} />
               </div>
               <div className="space-y-2">
                 <h3 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">Menenun Imajinasi</h3>
                 <p className="text-slate-500 dark:text-slate-400 text-base">Merancang karakter, menyusun adegan, dan membuat prompt visual...</p>
               </div>
             </div>
          )}

          {result && !loading && (
            <motion.div 
              ref={resultRef}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-8"
            >
              {/* Result Header */}
              <div className="bg-slate-900 dark:bg-black p-8 rounded-3xl border border-slate-800 shadow-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-6 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-blue-600/10 blur-[100px] rounded-full" />
                <div className="relative z-10 space-y-3">
                  <h2 className="text-3xl font-black text-white tracking-tight italic uppercase leading-none">{result.title}</h2>
                  <div className="flex gap-2">
                    <span className="px-3 py-1 bg-white/10 text-white text-[10px] font-black uppercase tracking-widest rounded-full border border-white/10">{formData.theme}</span>
                    <span className="px-3 py-1 bg-white/10 text-white text-[10px] font-black uppercase tracking-widest rounded-full border border-white/10">{formData.style}</span>
                  </div>
                </div>
                <button 
                  onClick={handleDownloadScript}
                  className="relative z-10 bg-white hover:bg-blue-50 text-slate-900 font-black text-xs uppercase tracking-widest py-3 px-6 rounded-xl transition-all shadow-xl flex items-center gap-2 group"
                >
                  <Download className="w-4 h-4 group-hover:translate-y-0.5 transition-transform" />
                  Export Dokumen
                </button>
              </div>

              {/* Characters Section */}
              <section className="space-y-6">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-blue-600 rounded-xl text-white shadow-lg shadow-blue-500/20">
                    <Users size={20} />
                  </div>
                  <h3 className="text-xl font-black text-slate-900 dark:text-white tracking-tight uppercase italic">Master Karakter</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {result.master_characters?.map((char: any, idx: number) => (
                    <motion.div 
                      key={idx}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.1 }}
                      className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all group"
                    >
                      <div className="flex justify-between items-start mb-4">
                        <div className="space-y-1">
                          <h4 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">{char.name}</h4>
                          <span className="inline-block text-[10px] font-black text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/30 px-2.5 py-0.5 rounded-full uppercase tracking-widest">
                            {char.role}
                          </span>
                        </div>
                        <button
                          onClick={() => handleGenerateBackstory(idx)}
                          disabled={loadingBackstories[idx]}
                          className="p-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-400 hover:text-blue-600 rounded-xl transition-all disabled:opacity-50"
                          title="Generate Backstory"
                        >
                          {loadingBackstories[idx] ? <Loader2 size={16} className="animate-spin" /> : <RefreshCw size={16} />}
                        </button>
                      </div>
                      
                      <div className="space-y-5">
                        <div className="space-y-1.5">
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Kepribadian</span>
                          <p className="text-sm text-slate-700 dark:text-slate-300 font-medium leading-relaxed">{char.personality}</p>
                        </div>
                        
                        <AnimatePresence>
                          {char.backstory && (
                            <motion.div 
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: 'auto' }}
                              className="bg-slate-50 dark:bg-slate-950 p-4 rounded-xl border border-slate-100 dark:border-slate-800"
                            >
                               <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1.5">Latar Belakang</span>
                               <p className="text-xs italic text-slate-600 dark:text-slate-400 leading-relaxed font-medium">"{char.backstory}"</p>
                            </motion.div>
                          )}
                        </AnimatePresence>

                        <div className="bg-slate-900 p-5 rounded-2xl relative overflow-hidden">
                          <div className="flex justify-between items-center mb-3 relative z-10">
                            <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Visual Prompt</span>
                            <button 
                              onClick={() => copyToClipboard(char.visual_description, `c-${idx}`)} 
                              className="p-1.5 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-all"
                            >
                              {copiedStates[`c-${idx}`] ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                            </button>
                          </div>
                          <div className="text-xs font-mono text-slate-400 leading-relaxed h-20 overflow-y-auto custom-scrollbar relative z-10 pr-2">
                            {char.visual_description}
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </section>

              {/* Scenes Section */}
              <section className="space-y-6">
                 <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-blue-600 rounded-xl text-white shadow-lg shadow-blue-500/20">
                    <Clapperboard size={20} />
                  </div>
                  <h3 className="text-xl font-black text-slate-900 dark:text-white tracking-tight uppercase italic">Daftar Adegan</h3>
                </div>

                <div className="space-y-6">
                  {result.scenes?.map((scene: any, idx: number) => (
                    <motion.div 
                      key={idx}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.1 }}
                      className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm hover:shadow-xl transition-all"
                    >
                      <div className="bg-slate-50 dark:bg-slate-950 px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center">
                        <div className="flex items-center gap-3">
                          <span className="w-8 h-8 rounded-full bg-slate-900 dark:bg-white text-white dark:text-slate-900 flex items-center justify-center font-black text-xs">
                            {scene.scene_number}
                          </span>
                          <span className="text-xs font-black text-slate-800 dark:text-slate-200 uppercase tracking-widest">Adegan Produksi</span>
                        </div>
                        <div className="flex gap-2">
                          <button 
                            onClick={() => handleGenerateAudio(idx)} 
                            disabled={loadingAudio[idx]} 
                            className="p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-400 hover:text-amber-600 rounded-xl transition-all disabled:opacity-50"
                            title="Generate BGM & SFX"
                          >
                            {loadingAudio[idx] ? <Loader2 size={16} className="animate-spin" /> : <Music size={16} />}
                          </button>
                          <button 
                            onClick={() => handleEnhanceDialogue(idx)} 
                            disabled={loadingDialogues[idx]}
                            className="p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-400 hover:text-blue-600 rounded-xl transition-all disabled:opacity-50"
                            title="Perbagus Dialog"
                          >
                            {loadingDialogues[idx] ? <Loader2 size={16} className="animate-spin" /> : <RefreshCw size={16} />}
                          </button>
                        </div>
                      </div>

                      <div className="p-6 grid grid-cols-1 lg:grid-cols-2 gap-8">
                        {/* Script Column */}
                        <div className="space-y-6">
                          <div className="space-y-2">
                             <div className="flex items-center gap-2">
                               <Feather size={14} className="text-blue-600" />
                               <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Narasi & Aksi</h5>
                             </div>
                             <p className="text-base text-slate-700 dark:text-slate-300 leading-relaxed font-medium">{scene.narration}</p>
                          </div>

                          <AnimatePresence>
                            {scene.audio_cue && (
                              <motion.div 
                                initial={{ opacity: 0, x: -10 }}
                                animate={{ opacity: 1, x: 0 }}
                                className="bg-amber-50 dark:bg-amber-900/20 p-4 rounded-2xl border border-amber-100 dark:border-amber-800/50"
                              >
                                 <div className="flex items-center gap-2 mb-1.5">
                                   <Music size={12} className="text-amber-600" />
                                   <span className="text-[10px] font-black text-amber-600 dark:text-amber-400 uppercase tracking-widest">Panduan Audio</span>
                                 </div>
                                 <p className="text-xs italic text-amber-700 dark:text-amber-300 leading-relaxed font-medium">"{scene.audio_cue}"</p>
                              </motion.div>
                            )}
                          </AnimatePresence>

                          <div className="space-y-3">
                             <div className="flex items-center gap-2">
                               <Mic size={14} className="text-blue-600" />
                               <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Dialog Lipsync</h5>
                             </div>
                             <div className="bg-slate-50 dark:bg-slate-950 border-l-4 border-blue-600 p-6 rounded-r-2xl relative overflow-hidden">
                                <div className="absolute top-0 right-0 p-2 opacity-10">
                                  <MessageSquare size={32} />
                                </div>
                                <p className="text-lg text-slate-900 dark:text-white italic font-black leading-tight relative z-10">"{scene.dialogue}"</p>
                             </div>
                          </div>
                        </div>

                        {/* Prompt Column */}
                        <div className="space-y-4">
                          <div className="bg-slate-900 p-6 rounded-3xl space-y-5">
                            <div className="space-y-3">
                               <div className="flex justify-between items-center">
                                 <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Text-to-Image Prompt</span>
                                 <button 
                                  onClick={() => copyToClipboard(scene.text_to_image_prompt, `t2i-${idx}`)} 
                                  className="p-1.5 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-all"
                                 >
                                   {copiedStates[`t2i-${idx}`] ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                                 </button>
                               </div>
                               <div className="text-xs font-mono text-slate-400 leading-relaxed h-24 overflow-y-auto custom-scrollbar pr-2">
                                 {scene.text_to_image_prompt}
                               </div>
                            </div>
                            
                            <div className="h-[1px] bg-white/5" />

                            <div className="space-y-3">
                               <div className="flex justify-between items-center">
                                 <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Image-to-Video Prompt</span>
                                 <button 
                                  onClick={() => copyToClipboard(scene.image_to_video_prompt, `i2v-${idx}`)} 
                                  className="p-1.5 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-all"
                                 >
                                   {copiedStates[`i2v-${idx}`] ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                                 </button>
                               </div>
                               <div className="text-xs font-mono text-slate-400 leading-relaxed h-20 overflow-y-auto custom-scrollbar pr-2">
                                 {scene.image_to_video_prompt}
                               </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </section>
            </motion.div>
          )}
        </div>
      </div>

      <style dangerouslySetInnerHTML={{__html: `
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 10px; }
        .custom-scrollbar:hover::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.2); }
        
        input[type="number"]::-webkit-inner-spin-button,
        input[type="number"]::-webkit-outer-spin-button {
          -webkit-appearance: none;
          margin: 0;
        }
      `}} />
    </div>
  );
};
