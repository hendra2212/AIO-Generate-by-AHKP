import React, { useState, useEffect, useRef } from 'react';
import { 
  Sparkles, 
  LayoutTemplate, 
  Wand2, 
  AlertCircle,
  Loader2,
  Users,
  Paintbrush,
  PenTool,
  Target,
  Check,
  Lightbulb,
  Crop,
  Copy,
  ImagePlus,
  X,
  ScanEye,
  Feather,
  Video
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { motion, AnimatePresence } from "motion/react";

// --- Constants ---

const PURPOSES = [
  { id: 'education', label: 'Edukasi / Informasi', en: 'educational and highly informative, objective tone' },
  { id: 'promotion', label: 'Promosi / Komersial', en: 'commercial promotion, persuasive, call-to-action driven' },
  { id: 'health', label: 'Kesehatan / Medis', en: 'health and wellness awareness, trustworthy, medical info' },
  { id: 'social', label: 'Sosial / Kampanye', en: 'social campaign, public awareness, impactful, emotional' }
];

const DESIGN_TYPES = [
  { id: 'infographic', label: 'Infografis', en: 'infographic layout, structured data visualization' },
  { id: 'poster', label: 'Poster', en: 'poster design, eye-catching headline, strong visual hierarchy' },
  { id: 'logo', label: 'Logo / Identitas', en: 'logo design, vector style, minimalistic, brand identity' },
  { id: 'pamphlet', label: 'Pamflet', en: 'pamphlet design, informative, folded or single sheet' },
  { id: 'brochure', label: 'Brosur', en: 'brochure design, multi-page or tri-fold, detailed information' }
];

const AUDIENCES = [
  { id: 'general', label: 'Umum', en: 'general audience' },
  { id: 'kids', label: 'Anak-anak', en: 'children, playful, colorful' },
  { id: 'teens', label: 'Remaja', en: 'teenagers, trendy, dynamic' },
  { id: 'professionals', label: 'Profesional', en: 'business professionals, corporate, clean' },
  { id: 'seniors', label: 'Lansia', en: 'seniors, clear, high contrast, easy to read' }
];

const STYLES = [
  { id: '3d_cartoon', label: '3D Cartoon', en: '3D cartoon style, Pixar-like, vibrant, expressive characters, soft lighting' },
  { id: 'claymation', label: 'Claymation', en: 'claymation style, plasticine texture, stop-motion look, handmade feel, Aardman style' },
  { id: 'custom', label: 'Custom / Lainnya', en: 'custom style' }
];

const ASPECT_RATIOS = [
  { id: '1:1', label: '1:1 (Square)', value: '1:1' },
  { id: '16:9', label: '16:9 (Landscape)', value: '16:9' },
  { id: '9:16', label: '9:16 (Story)', value: '9:16' },
  { id: '4:5', label: '4:5 (Portrait)', value: '4:5' },
  { id: '3:4', label: '3:4 (Standard)', value: '3:4' }
];

// --- Helper Components ---

const SectionLabel = ({ icon: Icon, label }: { icon: any, label: string }) => (
  <div className="flex items-center gap-2 mb-3 text-sm font-medium text-gray-700">
    <Icon className="w-4 h-4 text-indigo-600" />
    <span>{label}</span>
  </div>
);

const SelectButton = ({ 
  selected, 
  onClick, 
  label, 
  subLabel 
}: { 
  selected: boolean, 
  onClick: () => void, 
  label: string,
  subLabel?: string 
}) => (
  <button
    onClick={onClick}
    className={`
      relative px-4 py-3 rounded-xl text-left transition-all duration-200 border
      ${selected 
        ? 'bg-indigo-50 border-indigo-200 shadow-sm ring-1 ring-indigo-200' 
        : 'bg-white border-gray-100 hover:border-gray-200 hover:bg-gray-50'
      }
    `}
  >
    <div className="flex items-center justify-between mb-1">
      <span className={`text-sm font-medium ${selected ? 'text-indigo-900' : 'text-gray-700'}`}>
        {label}
      </span>
      {selected && <Check className="w-3.5 h-3.5 text-indigo-600" />}
    </div>
    {subLabel && (
      <p className={`text-xs ${selected ? 'text-indigo-700/80' : 'text-gray-500'}`}>
        {subLabel}
      </p>
    )}
  </button>
);

export const GraphicDesign: React.FC = () => {
  // --- State ---
  const [topic, setTopic] = useState('');
  const [selectedPurpose, setSelectedPurpose] = useState(PURPOSES[0]);
  const [selectedType, setSelectedType] = useState(DESIGN_TYPES[0]);
  const [selectedAudience, setSelectedAudience] = useState(AUDIENCES[0]);
  const [selectedStyle, setSelectedStyle] = useState(STYLES[0]);
  const [customStyle, setCustomStyle] = useState('');
  const [selectedRatio, setSelectedRatio] = useState(ASPECT_RATIOS[0]);
  
  const [generatedPrompt, setGeneratedPrompt] = useState('');
  const [motionPrompt, setMotionPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // AI Feature States
  const [isSuggestingTopics, setIsSuggestingTopics] = useState(false);
  const [suggestedTopics, setSuggestedTopics] = useState<string[]>([]);
  const [isExtractingImage, setIsExtractingImage] = useState(false);
  const [isMagicFilling, setIsMagicFilling] = useState(false);
  const [isGeneratingMotion, setIsGeneratingMotion] = useState(false);
  
  // Copy States
  const [isCopiedPrompt, setIsCopiedPrompt] = useState(false);
  const [isCopiedMotion, setIsCopiedMotion] = useState(false);

  const [referenceImage, setReferenceImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // --- Logic ---

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setReferenceImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeReferenceImage = () => {
    setReferenceImage(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const copyToClipboard = async (text: string, type: 'prompt' | 'motion') => {
    try {
      await navigator.clipboard.writeText(text);
      if (type === 'prompt') {
        setIsCopiedPrompt(true);
        setTimeout(() => setIsCopiedPrompt(false), 2000);
      } else {
        setIsCopiedMotion(true);
        setTimeout(() => setIsCopiedMotion(false), 2000);
      }
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const suggestIdeas = async () => {
    setIsSuggestingTopics(true);
    setError(null);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
      
      const prompt = `Berikan 5 ide topik desain grafis yang menarik dan spesifik untuk kategori: ${selectedType.label} dengan tujuan: ${selectedPurpose.label}. 
      Format output: hanya list 5 poin singkat tanpa penomoran. Gunakan Bahasa Indonesia.`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
      });
      
      const text = response.text || '';
      
      const ideas = text.split('\n').filter(line => line.trim().length > 0).slice(0, 5);
      setSuggestedTopics(ideas);
    } catch (err) {
      setError('Gagal memuat saran ide. Silakan coba lagi.');
    } finally {
      setIsSuggestingTopics(false);
    }
  };

  const extractImageDetails = async () => {
    if (!referenceImage) return;
    
    setIsExtractingImage(true);
    setError(null);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

      // Remove data URL prefix
      const base64Data = referenceImage.split(',')[1];
      
      const prompt = "Analisis gambar ini dan deskripsikan gaya visual, komposisi, dan elemen kuncinya dalam satu paragraf singkat untuk dijadikan referensi desain.";
      
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: {
          parts: [
            { text: prompt },
            { inlineData: { data: base64Data, mimeType: "image/jpeg" } }
          ]
        }
      });
      
      const text = response.text || '';
      setTopic(prev => (prev ? prev + "\n\nReferensi Visual: " + text : "Referensi Visual: " + text));
    } catch (err) {
      setError('Gagal menganalisis gambar.');
    } finally {
      setIsExtractingImage(false);
    }
  };

  const magicFillParameters = async () => {
    if (!topic) {
      setError('Mohon isi topik terlebih dahulu untuk menggunakan Magic Fill.');
      return;
    }

    setIsMagicFilling(true);
    setError(null);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

      const prompt = `Berdasarkan topik desain ini: "${topic}", sarankan pengaturan terbaik untuk:
      1. Tujuan (pilih satu ID dari: education, promotion, health, social)
      2. Format (pilih satu ID dari: infographic, poster, social_media, logo, banner)
      3. Target Audiens (pilih satu ID dari: general, kids, teens, professionals, seniors)
      4. Gaya Visual (pilih satu ID dari: modern, corporate, playful, vintage, futuristic, 3d_cartoon, claymation)
      
      Format output JSON: {"purpose": "id", "type": "id", "audience": "id", "style": "id"}`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
      });
      const text = response.text || '';
      // Clean markdown code blocks if present
      const jsonStr = text.replace(/```json/g, '').replace(/```/g, '').trim();
      const suggestions = JSON.parse(jsonStr);

      const newPurpose = PURPOSES.find(p => p.id === suggestions.purpose);
      const newType = DESIGN_TYPES.find(t => t.id === suggestions.type);
      const newAudience = AUDIENCES.find(a => a.id === suggestions.audience);
      const newStyle = STYLES.find(s => s.id === suggestions.style);

      if (newPurpose) setSelectedPurpose(newPurpose);
      if (newType) setSelectedType(newType);
      if (newAudience) setSelectedAudience(newAudience);
      if (newStyle) setSelectedStyle(newStyle);

    } catch (err) {
      console.error(err);
      setError('Gagal menerapkan Magic Fill.');
    } finally {
      setIsMagicFilling(false);
    }
  };

  const generateMotionPrompt = async () => {
    setIsGeneratingMotion(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

      const prompt = `Buat motion prompt untuk AI video generation (Runway/Pika) berdasarkan gambar statis ini: "${generatedPrompt}".
      Deskripsikan pergerakan kamera atau elemen yang halus dan sinematik secara SANGAT SINGKAT.
      Output dalam Bahasa Inggris, MAKSIMAL 1 kalimat pendek.`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
      });
      setMotionPrompt(response.text || '');
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingMotion(false);
    }
  };

  const generatePrompt = async () => {
    if (!topic) {
      setError('Mohon isi topik atau deskripsi desain terlebih dahulu.');
      return;
    }

    setIsGenerating(true);
    setError(null);
    setGeneratedPrompt('');
    setMotionPrompt('');

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

      const stylePrompt = selectedStyle.id === 'custom' ? customStyle : selectedStyle.en;

      const prompt = `Bertindaklah sebagai expert prompt engineer. Saya ingin Anda membuat DUA output sekaligus (Visual Prompt dan Animation Prompt) berdasarkan detail berikut:

      KONTEKS DESAIN:
      - Topik/Isi: ${topic}
      - Format: ${selectedType.en}
      - Tujuan: ${selectedPurpose.en}
      - Target Audiens: ${selectedAudience.en}
      - Gaya Visual: ${stylePrompt}
      - Aspek Rasio: ${selectedRatio.value}

      INSTRUKSI UTAMA:
      Buatlah output dengan struktur yang SANGAT SPESIFIK dan format yang TEPAT seperti di bawah ini. Jangan gunakan tanda hubung (-) di depan label. Jaga agar setiap deskripsi tetap SINGKAT dan PADAT (maksimal 1-2 kalimat per poin).

      ---VISUAL PROMPT START---
      Create a high-quality ${stylePrompt} ${selectedType.en} for "${topic}" targeting ${selectedAudience.en}.
      [VISUAL CONCEPT]
      Style: [Deskripsikan gaya visual secara singkat, gunakan bahasa Inggris]
      Hero Image: [Deskripsikan gambar utama secara singkat, subjek, aksi, dan emosi dalam bahasa Inggris]
      Elements: [Deskripsikan elemen pendukung secara singkat dalam bahasa Inggris]
      Background: [Deskripsikan latar belakang secara singkat dalam bahasa Inggris]
      [CONTENT LAYOUT - BAHASA INDONESIA]
      Headline: "[Buat headline yang sangat singkat, padat, dan menarik (maksimal 5-7 kata)]"
      Sub-headline: "[Buat sub-headline singkat (maksimal 10-12 kata)]"
      Key Features:
      [Poin fitur 1 tanpa nomor atau tanda hubung]
      [Poin fitur 2 tanpa nomor atau tanda hubung]
      [Poin fitur 3 tanpa nomor atau tanda hubung]
      [Poin fitur 4 tanpa nomor atau tanda hubung]
      CTA: "[Call to Action yang singkat dan kuat (maksimal 3-5 kata)]"
      [TECHNICAL SPECIFICATIONS]
      Format: High-quality, seamlessly looping animated GIF.
      Animation Style: Key elements (characters, icons) should have subtle, individual movements. The overall background remains mostly static.
      Orientation: ${selectedRatio.value} aspect ratio
      Lighting: [Deskripsikan pencahayaan secara singkat dalam bahasa Inggris]
      Quality: High resolution, clean composition, sharp focus, octane render.
      No watermarks, no external logos.
      Text must be clear, bold, and readable in Bahasa Indonesia using a fun, rounded font.
      ---VISUAL PROMPT END---

      ---ANIMATION PROMPT START---
      Image to Video Prompt

      [ANIMATION INSTRUCTIONS]
      Motion: [Deskripsikan instruksi gerakan animasi secara SINGKAT dalam bahasa Inggris. Fokus pada pergerakan elemen kunci. Berikan catatan CRITICAL bahwa teks body harus statis sedangkan headline boleh memiliki efek pulse/bounce.]
      Pacing: [Deskripsikan tempo animasi secara singkat]
      ---ANIMATION PROMPT END---
      `;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
      });

      const text = response.text || '';
      
      // Parse the output
      const visualMatch = text.match(/---VISUAL PROMPT START---([\s\S]*?)---VISUAL PROMPT END---/);
      const animationMatch = text.match(/---ANIMATION PROMPT START---([\s\S]*?)---ANIMATION PROMPT END---/);

      if (visualMatch && visualMatch[1]) {
        setGeneratedPrompt(visualMatch[1].trim());
      } else {
        // Fallback if regex fails, try to clean up markers if present, or just show full text
        const cleanText = text.replace(/---VISUAL PROMPT START---|---VISUAL PROMPT END---|---ANIMATION PROMPT START---|---ANIMATION PROMPT END---/g, '');
        setGeneratedPrompt(cleanText.trim());
      }

      if (animationMatch && animationMatch[1]) {
        setMotionPrompt(animationMatch[1].trim());
      }

    } catch (err) {
      setError('Terjadi kesalahan saat membuat prompt. Silakan coba lagi.');
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  // --- Render ---

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2 flex items-center gap-3">
          <div className="p-2 bg-indigo-600 rounded-lg">
            <Paintbrush className="w-6 h-6 text-white" />
          </div>
          Desain Grafis & Visual
        </h1>
        <p className="text-gray-600 max-w-2xl">
          Buat prompt detail untuk kebutuhan desain grafis, mulai dari logo, poster, hingga konten media sosial dengan spesifikasi visual yang tepat.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Panel - Input */}
        <div className="lg:col-span-5 space-y-8">
          
          {/* Topic Input */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <div className="flex justify-between items-center mb-4">
              <SectionLabel icon={LayoutTemplate} label="Topik & Konten" />
              <div className="flex gap-2">
                <button
                  onClick={suggestIdeas}
                  disabled={isSuggestingTopics}
                  className="text-xs flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 text-indigo-700 rounded-full hover:bg-indigo-100 transition-colors"
                >
                  {isSuggestingTopics ? <Loader2 className="w-3 h-3 animate-spin" /> : <Lightbulb className="w-3 h-3" />}
                  Saran Ide
                </button>
                <button
                  onClick={magicFillParameters}
                  disabled={isMagicFilling || !topic}
                  className="text-xs flex items-center gap-1.5 px-3 py-1.5 bg-purple-50 text-purple-700 rounded-full hover:bg-purple-100 transition-colors"
                >
                  {isMagicFilling ? <Loader2 className="w-3 h-3 animate-spin" /> : <Wand2 className="w-3 h-3" />}
                  Magic Fill
                </button>
              </div>
            </div>

            <textarea
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="Contoh: ayo menabung"
              className="w-full h-32 p-4 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none text-gray-700 placeholder-gray-400"
            />

            {/* Suggested Topics */}
            <AnimatePresence>
              {suggestedTopics.length > 0 && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-3 flex flex-wrap gap-2"
                >
                  {suggestedTopics.map((idea, idx) => (
                    <button
                      key={idx}
                      onClick={() => setTopic(idea)}
                      className="text-xs px-3 py-1 bg-gray-50 border border-gray-200 rounded-full text-gray-600 hover:bg-gray-100 hover:border-gray-300 transition-colors text-left"
                    >
                      {idea.replace(/^- /, '')}
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>

            {/* Image Reference Upload */}
            <div className="mt-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-medium text-gray-500 flex items-center gap-1">
                  <ImagePlus className="w-3 h-3" />
                  Referensi Gambar (Opsional)
                </span>
                {referenceImage && (
                  <button 
                    onClick={extractImageDetails}
                    disabled={isExtractingImage}
                    className="text-xs text-indigo-600 hover:text-indigo-700 flex items-center gap-1"
                  >
                    {isExtractingImage ? <Loader2 className="w-3 h-3 animate-spin" /> : <ScanEye className="w-3 h-3" />}
                    Analisis Gambar
                  </button>
                )}
              </div>
              
              {!referenceImage ? (
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-gray-200 rounded-xl p-4 flex flex-col items-center justify-center text-center cursor-pointer hover:border-indigo-300 hover:bg-gray-50 transition-colors"
                >
                  <ImagePlus className="w-6 h-6 text-gray-400 mb-2" />
                  <span className="text-xs text-gray-500">Klik untuk upload gambar referensi</span>
                </div>
              ) : (
                <div className="relative rounded-xl overflow-hidden border border-gray-200 group">
                  <img src={referenceImage} alt="Reference" className="w-full h-24 object-cover" />
                  <button 
                    onClick={removeReferenceImage}
                    className="absolute top-1 right-1 p-1 bg-black/50 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              )}
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleImageUpload} 
                accept="image/*" 
                className="hidden" 
              />
            </div>
          </div>

          {/* Parameters Grid */}
          <div className="grid grid-cols-2 gap-4">
            {/* Purpose */}
            <div className="col-span-2 bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
              <SectionLabel icon={Target} label="Tujuan Desain" />
              <div className="grid grid-cols-2 gap-2">
                {PURPOSES.map((p) => (
                  <SelectButton
                    key={p.id}
                    selected={selectedPurpose.id === p.id}
                    onClick={() => setSelectedPurpose(p)}
                    label={p.label}
                  />
                ))}
              </div>
            </div>

            {/* Type */}
            <div className="col-span-2 bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
              <SectionLabel icon={PenTool} label="Format" />
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {DESIGN_TYPES.map((t) => (
                  <SelectButton
                    key={t.id}
                    selected={selectedType.id === t.id}
                    onClick={() => setSelectedType(t)}
                    label={t.label}
                  />
                ))}
              </div>
            </div>

            {/* Audience */}
            <div className="col-span-2 sm:col-span-1 bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
              <SectionLabel icon={Users} label="Target Audiens" />
              <div className="space-y-2">
                {AUDIENCES.map((a) => (
                  <SelectButton
                    key={a.id}
                    selected={selectedAudience.id === a.id}
                    onClick={() => setSelectedAudience(a)}
                    label={a.label}
                  />
                ))}
              </div>
            </div>

            {/* Style */}
            <div className="col-span-2 sm:col-span-1 bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
              <SectionLabel icon={Paintbrush} label="Gaya Visual" />
              <div className="space-y-2">
                {STYLES.map((s) => (
                  <SelectButton
                    key={s.id}
                    selected={selectedStyle.id === s.id}
                    onClick={() => setSelectedStyle(s)}
                    label={s.label}
                  />
                ))}
              </div>
              {selectedStyle.id === 'custom' && (
                <div className="mt-3">
                  <input
                    type="text"
                    value={customStyle}
                    onChange={(e) => setCustomStyle(e.target.value)}
                    placeholder="Deskripsikan gaya visual yang diinginkan..."
                    className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
                  />
                </div>
              )}
            </div>
            
            {/* Aspect Ratio */}
            <div className="col-span-2 bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
              <SectionLabel icon={Crop} label="Aspek Rasio" />
              <div className="flex flex-wrap gap-2">
                {ASPECT_RATIOS.map((r) => (
                  <button
                    key={r.id}
                    onClick={() => setSelectedRatio(r)}
                    className={`
                      px-3 py-1.5 rounded-lg text-xs font-medium border transition-all
                      ${selectedRatio.id === r.id
                        ? 'bg-indigo-50 border-indigo-200 text-indigo-700'
                        : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                      }
                    `}
                  >
                    {r.label}
                  </button>
                ))}
              </div>
            </div>

          </div>

          <button
            onClick={generatePrompt}
            disabled={isGenerating || !topic}
            className={`
              w-full py-4 rounded-xl font-semibold text-white shadow-lg shadow-indigo-200 transition-all transform active:scale-[0.98]
              flex items-center justify-center gap-2
              ${isGenerating || !topic
                ? 'bg-gray-300 cursor-not-allowed shadow-none'
                : 'bg-indigo-600 hover:bg-indigo-700 hover:shadow-indigo-300'
              }
            `}
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Sedang Meracik Prompt...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                Generate Prompt Desain
              </>
            )}
          </button>

          {error && (
            <div className="p-4 bg-red-50 text-red-700 rounded-xl flex items-center gap-2 text-sm">
              <AlertCircle className="w-4 h-4 shrink-0" />
              {error}
            </div>
          )}
        </div>

        {/* Right Panel - Output */}
        <div className="lg:col-span-7">
          <div className="sticky top-8 space-y-6">
            
            {/* Main Prompt Output */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden min-h-[200px] flex flex-col">
              <div className="p-4 border-b border-gray-100 bg-gray-50 flex justify-between items-center">
                <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-indigo-500" />
                  Prompt Result
                </h3>
                {generatedPrompt && (
                  <button
                    onClick={() => copyToClipboard(generatedPrompt, 'prompt')}
                    className="text-xs flex items-center gap-1.5 px-2.5 py-1.5 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 text-gray-600 transition-colors"
                  >
                    {isCopiedPrompt ? <Check className="w-3.5 h-3.5 text-green-600" /> : <Copy className="w-3.5 h-3.5" />}
                    {isCopiedPrompt ? 'Tersalin!' : 'Salin'}
                  </button>
                )}
              </div>
              
              <div className="p-6 flex-grow">
                {generatedPrompt ? (
                  <div className="prose prose-sm max-w-none text-gray-700 leading-relaxed whitespace-pre-wrap font-mono text-sm bg-gray-50 p-4 rounded-xl border border-gray-100">
                    {generatedPrompt}
                  </div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-gray-400 py-12">
                    <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mb-4">
                      <Paintbrush className="w-8 h-8 text-gray-300" />
                    </div>
                    <p className="text-sm">Prompt desain Anda akan muncul di sini</p>
                  </div>
                )}
              </div>
            </div>

            {/* Additional Tools (Motion) */}
            {generatedPrompt && (
              <div className="grid grid-cols-1 gap-6">
                
                {/* Motion Prompt */}
                <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                  <div className="p-4 border-b border-gray-100 bg-gray-50 flex justify-between items-center">
                    <h3 className="font-medium text-gray-900 text-sm flex items-center gap-2">
                      <Video className="w-4 h-4 text-blue-500" />
                      Motion Prompt
                    </h3>
                    {!motionPrompt ? (
                      <button
                        onClick={generateMotionPrompt}
                        disabled={isGeneratingMotion}
                        className="text-xs text-indigo-600 hover:text-indigo-700 font-medium"
                      >
                        {isGeneratingMotion ? 'Generating...' : 'Generate'}
                      </button>
                    ) : (
                      <button
                        onClick={() => copyToClipboard(motionPrompt, 'motion')}
                        className="text-gray-400 hover:text-gray-600"
                      >
                        {isCopiedMotion ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    )}
                  </div>
                  <div className="p-4">
                    {motionPrompt ? (
                      <p className="text-xs font-mono text-gray-600 bg-gray-50 p-3 rounded-lg border border-gray-100">
                        {motionPrompt}
                      </p>
                    ) : (
                      <p className="text-xs text-gray-400 italic">
                        Generate instruksi pergerakan untuk AI Video.
                      </p>
                    )}
                  </div>
                </div>

              </div>
            )}

            {/* Tips Card */}
            <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-2xl p-5 border border-indigo-100">
              <h4 className="font-semibold text-indigo-900 mb-2 flex items-center gap-2">
                <Feather className="w-4 h-4" />
                Tips Desain
              </h4>
              <ul className="text-sm text-indigo-800/80 space-y-1.5 list-disc list-inside">
                <li>Gunakan rasio 1:1 untuk feed Instagram, 9:16 untuk Story/TikTok.</li>
                <li>Sebutkan "vector art" atau "flat design" untuk gaya ilustrasi bersih.</li>
                <li>Gunakan "cinematic lighting" untuk hasil yang lebih dramatis pada poster.</li>
              </ul>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};
