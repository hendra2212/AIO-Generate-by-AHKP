import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Copy, RefreshCw, Send, Sparkles, Check, Trash2 } from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface PromptGeneratorProps {
  title: string;
  description: string;
  type: 'static' | 'lipsync' | 'voiceover' | 'graphic-design';
}

export const PromptGenerator: React.FC<PromptGeneratorProps> = ({ title, description, type }) => {
  const [input, setInput] = useState('');
  const [result, setResult] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);

  // Persistence
  useEffect(() => {
    const savedInput = localStorage.getItem(`prompt_input_${type}`);
    const savedResult = localStorage.getItem(`prompt_result_${type}`);
    if (savedInput) setInput(savedInput);
    if (savedResult) setResult(savedResult);
  }, [type]);

  useEffect(() => {
    localStorage.setItem(`prompt_input_${type}`, input);
  }, [input, type]);

  useEffect(() => {
    localStorage.setItem(`prompt_result_${type}`, result);
  }, [result, type]);

  const handleReset = () => {
    if (window.confirm("Hapus input dan hasil?")) {
      setInput('');
      setResult('');
      localStorage.removeItem(`prompt_input_${type}`);
      localStorage.removeItem(`prompt_result_${type}`);
    }
  };

  const handleGenerate = async () => {
    if (!input) return;
    setIsGenerating(true);
    
    // Simulate generation
    setTimeout(() => {
      let prompt = '';
      if (type === 'static') {
        prompt = `Cinematic shot of ${input}, hyper-realistic, 8k resolution, detailed textures, soft lighting, depth of field, trending on artstation, masterpiece, intricate details, volumetric lighting, shot on 35mm lens.`;
      } else if (type === 'lipsync') {
        prompt = `High-quality talking head video, ${input}, clear facial expressions, natural lip movements, professional lighting, 4k, studio background, sharp focus, 60fps.`;
      } else if (type === 'graphic-design') {
        prompt = `Professional graphic design for ${input}, vector art, clean lines, minimalist, modern typography, high contrast, brand identity, adobe illustrator style, 8k, award winning design.`;
      } else {
        prompt = `[Voice: Professional, Male, Deep Tone] "Halo, ini adalah skrip voice over untuk ${input}. Harap baca dengan nada yang antusias, jelas, dan berwibawa."`;
      }
      setResult(prompt);
      setIsGenerating(false);
    }, 1500);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-lg shadow-blue-500/20">
              <Sparkles size={20} />
            </div>
            <h2 className="text-3xl font-bold text-slate-900 dark:text-white tracking-tight">{title}</h2>
          </div>
          <p className="text-slate-500 dark:text-slate-400 max-w-xl">{description}</p>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={handleReset}
            className="p-2 text-slate-400 hover:text-rose-500 transition-colors rounded-xl hover:bg-rose-50 dark:hover:bg-rose-900/10"
            title="Reset"
          >
            <Trash2 size={20} />
          </button>
          <button className="px-4 py-2 text-sm font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors">
            Riwayat
          </button>
          <button className="px-4 py-2 text-sm font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors">
            Templat
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        <div className="lg:col-span-3 space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 shadow-sm space-y-6">
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">Konsep Konten</label>
                <span className="text-[10px] font-bold text-slate-400">{input.length}/500</span>
              </div>
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="misal: Kota futuristik dengan mobil terbang saat matahari terbenam..."
                className="w-full h-48 p-5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all outline-none resize-none text-slate-900 dark:text-white text-lg leading-relaxed"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Gaya Visual</label>
                <select className="w-full p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-sm outline-none focus:ring-2 focus:ring-blue-500">
                  <option>Realistik</option>
                  <option>Anime</option>
                  <option>Cyberpunk</option>
                  <option>Minimalis</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Rasio Aspek</label>
                <select className="w-full p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-sm outline-none focus:ring-2 focus:ring-blue-500">
                  <option>16:9 (Landscape)</option>
                  <option>9:16 (Portrait)</option>
                  <option>1:1 (Square)</option>
                </select>
              </div>
            </div>

            <button
              onClick={handleGenerate}
              disabled={isGenerating || !input}
              className={cn(
                "w-full py-5 rounded-2xl font-bold flex items-center justify-center gap-3 transition-all shadow-xl text-lg",
                isGenerating || !input 
                  ? "bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed" 
                  : "bg-blue-600 hover:bg-blue-700 text-white shadow-blue-500/30 hover:-translate-y-1 active:translate-y-0"
              )}
            >
              {isGenerating ? (
                <RefreshCw className="animate-spin" size={24} />
              ) : (
                <Sparkles size={24} />
              )}
              {isGenerating ? 'Menghasilkan...' : 'Buat Prompt Sekarang'}
            </button>
          </div>
        </div>

        <div className="lg:col-span-2">
          <AnimatePresence mode="wait">
            {result ? (
              <motion.div
                key="result"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-slate-900 dark:bg-black rounded-3xl p-8 border border-slate-800 shadow-2xl h-full flex flex-col"
              >
                <div className="flex justify-between items-center mb-6">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Hasil Generasi</span>
                  </div>
                  <button 
                    onClick={copyToClipboard}
                    className="p-3 bg-white/5 hover:bg-white/10 rounded-xl text-slate-400 hover:text-white transition-all flex items-center gap-2"
                  >
                    {copied ? (
                      <>
                        <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest">Tersalin!</span>
                        <Check size={18} className="text-emerald-400" />
                      </>
                    ) : (
                      <Copy size={18} />
                    )}
                  </button>
                </div>
                
                <div className="flex-1 bg-white/5 rounded-2xl p-6 font-mono text-sm text-slate-300 leading-relaxed overflow-y-auto border border-white/5">
                  {result}
                </div>

                <div className="mt-6 pt-6 border-t border-white/10 flex items-center justify-between">
                  <button className="text-xs font-bold text-slate-500 hover:text-slate-300 transition-colors uppercase tracking-widest">
                    Edit Manual
                  </button>
                  <button className="flex items-center gap-2 text-xs font-bold text-blue-400 hover:text-blue-300 transition-colors uppercase tracking-widest">
                    Gunakan Templat <Send size={14} />
                  </button>
                </div>
              </motion.div>
            ) : (
              <div className="h-full border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-3xl flex flex-col items-center justify-center p-12 text-center space-y-4">
                <div className="w-16 h-16 rounded-full bg-slate-50 dark:bg-slate-900 flex items-center justify-center text-slate-300 dark:text-slate-700">
                  <Sparkles size={32} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 dark:text-white">Belum Ada Hasil</h4>
                  <p className="text-sm text-slate-500 dark:text-slate-400 max-w-[200px] mx-auto">
                    Isi konsep di sebelah kiri untuk mulai menghasilkan prompt AI.
                  </p>
                </div>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};
