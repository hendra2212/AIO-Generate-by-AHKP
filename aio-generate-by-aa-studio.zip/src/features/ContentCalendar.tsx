import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import { 
  Calendar, Sparkles, Target, Smartphone, 
  Users, Loader2, CheckCircle2, Copy, 
  RefreshCw, TrendingUp, Hash
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

interface ContentPlan {
  day: number;
  title: string;
  hook: string;
  structure: string;
  cta: string;
  hashtags: string[];
}

export const ContentCalendar: React.FC = () => {
  const [niche, setNiche] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('cc_niche') || '';
    }
    return '';
  });
  const [platform, setPlatform] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('cc_platform') || 'TikTok';
    }
    return 'TikTok';
  });
  const [audience, setAudience] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('cc_audience') || 'Umum';
    }
    return 'Umum';
  });
  
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedPlan, setGeneratedPlan] = useState<ContentPlan[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('cc_plan');
      return saved ? JSON.parse(saved) : [];
    }
    return [];
  });
  const [lastGeneratedNiche, setLastGeneratedNiche] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('cc_last_niche') || '';
    }
    return '';
  });
  const [error, setError] = useState<string | null>(null);

  React.useEffect(() => {
    localStorage.setItem('cc_niche', niche);
    localStorage.setItem('cc_platform', platform);
    localStorage.setItem('cc_audience', audience);
    localStorage.setItem('cc_plan', JSON.stringify(generatedPlan));
    localStorage.setItem('cc_last_niche', lastGeneratedNiche);
  }, [niche, platform, audience, generatedPlan, lastGeneratedNiche]);

  const handleGenerate = async () => {
    if (!niche.trim()) {
      setError('Mohon isi topik/niche terlebih dahulu.');
      return;
    }

    setIsGenerating(true);
    setError(null);
    
    try {
      const prompt = `
        Bertindaklah sebagai Social Media Strategist ahli yang spesialis dalam membuat konten viral (FYP).
        
        Buatkan rencana konten 7 hari yang TERSTRUKTUR dan SEMPURNA untuk:
        - Topik/Niche: ${niche}
        - Platform: ${platform}
        - Target Audiens: ${audience}
        
        Tujuan: Menghasilkan konten yang engaging, shareable, dan memiliki retensi tinggi (high watch time).
        
        Berikan output HANYA dalam format JSON Array valid seperti ini:
        [
          {
            "day": 1,
            "title": "Judul Konten yang Menarik (Clickbait tapi jujur)",
            "hook": "Kalimat 3 detik pertama untuk menahan audiens",
            "structure": "Ringkasan alur konten (Awal - Tengah - Akhir)",
            "cta": "Call to Action yang spesifik",
            "hashtags": ["tag1", "tag2", "tag3"]
          }
        ]
        
        Pastikan ada 7 item dalam array untuk 7 hari. Bahasa Indonesia yang gaul, relevan, dan sesuai platform.
      `;

      const response = await genAI.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json"
        }
      });

      const text = response.text || "[]";
      const data = JSON.parse(text);
      setGeneratedPlan(data);
      setLastGeneratedNiche(niche);

    } catch (err) {
      console.error(err);
      setError('Gagal menghasilkan rencana konten. Silakan coba lagi.');
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    // Could add a toast here
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="space-y-2">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-rose-600 flex items-center justify-center text-white shadow-xl shadow-rose-500/20">
            <Calendar size={24} />
          </div>
          <h2 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight">Kalender Konten Viral</h2>
        </div>
        <p className="text-slate-500 dark:text-slate-400 max-w-2xl text-lg">
          Generate ide konten 7 hari yang terstruktur untuk mengejar FYP di berbagai platform.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Input Panel */}
        <div className="lg:col-span-4 space-y-6 h-fit lg:sticky lg:top-8">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div className="flex items-center gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
              <Sparkles className="w-5 h-5 text-rose-600" />
              <h3 className="font-bold text-slate-900 dark:text-white uppercase tracking-widest text-xs">Konfigurasi Strategi</h3>
            </div>

            <div className="space-y-5">
              {/* Niche Input */}
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <Target size={12} /> Topik / Niche Viral
                </label>
                <input
                  type="text"
                  value={niche}
                  onChange={(e) => setNiche(e.target.value)}
                  placeholder="Contoh: Tips Diet Sehat, Tutorial Coding, Kucing Lucu..."
                  className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm focus:ring-2 focus:ring-rose-500 outline-none"
                />
              </div>

              {/* Platform Selection */}
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <Smartphone size={12} /> Platform
                </label>
                <select
                  value={platform}
                  onChange={(e) => setPlatform(e.target.value)}
                  className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm focus:ring-2 focus:ring-rose-500 outline-none"
                >
                  <option value="TikTok">TikTok</option>
                  <option value="Instagram Reels">Instagram Reels</option>
                  <option value="YouTube Shorts">YouTube Shorts</option>
                  <option value="Twitter / X">Twitter / X</option>
                  <option value="LinkedIn">LinkedIn</option>
                </select>
              </div>

              {/* Audience Selection */}
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <Users size={12} /> Target Audiens
                </label>
                <select
                  value={audience}
                  onChange={(e) => setAudience(e.target.value)}
                  className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm focus:ring-2 focus:ring-rose-500 outline-none"
                >
                  <option value="Umum">Umum (General)</option>
                  <option value="Anak-anak">Anak-anak</option>
                  <option value="Remaja (Gen Z)">Remaja (Gen Z)</option>
                  <option value="Dewasa Muda (Millennials)">Dewasa Muda (Millennials)</option>
                  <option value="Profesional / Bisnis">Profesional / Bisnis</option>
                  <option value="Ibu Rumah Tangga">Ibu Rumah Tangga</option>
                </select>
              </div>

              <button
                onClick={handleGenerate}
                disabled={isGenerating}
                className={`
                  w-full py-4 rounded-xl font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 transition-all shadow-lg
                  ${isGenerating 
                    ? 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed' 
                    : 'bg-rose-600 hover:bg-rose-700 text-white shadow-rose-500/30 hover:-translate-y-1 active:translate-y-0'}
                `}
              >
                {isGenerating ? <Loader2 className="animate-spin" size={18} /> : <TrendingUp size={18} />}
                {isGenerating ? 'Merancang Strategi...' : 'Generate 7-Day Plan'}
              </button>
            </div>
          </div>
        </div>

        {/* Results Area */}
        <div className="lg:col-span-8 space-y-6">
          {error && (
            <div className="bg-rose-50 dark:bg-rose-900/20 border border-rose-100 dark:border-rose-800 p-4 rounded-xl text-rose-600 dark:text-rose-300 text-sm font-medium">
              {error}
            </div>
          )}

          {generatedPlan.length > 0 && niche === lastGeneratedNiche ? (
            <div className="space-y-6">
              {generatedPlan.map((plan, index) => (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  key={plan.day}
                  className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm hover:shadow-md transition-shadow"
                >
                  <div className="bg-slate-50 dark:bg-slate-950/50 px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="bg-rose-100 dark:bg-rose-900/30 text-rose-600 dark:text-rose-400 px-3 py-1 rounded-lg text-xs font-black uppercase tracking-wider">
                        Hari {plan.day}
                      </span>
                      <h3 className="font-bold text-slate-900 dark:text-white">{plan.title}</h3>
                    </div>
                    <button 
                      onClick={() => copyToClipboard(`${plan.title}\n\nHook: ${plan.hook}\n\nIsi: ${plan.structure}\n\nCTA: ${plan.cta}`)}
                      className="text-slate-400 hover:text-rose-600 transition-colors"
                      title="Copy Plan"
                    >
                      <Copy size={18} />
                    </button>
                  </div>
                  
                  <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1 block">Hook (3 Detik Pertama)</label>
                        <p className="text-slate-700 dark:text-slate-300 font-medium italic">"{plan.hook}"</p>
                      </div>
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1 block">Struktur Konten</label>
                        <p className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed">{plan.structure}</p>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1 block">Call to Action (CTA)</label>
                        <div className="bg-rose-50 dark:bg-rose-900/10 border border-rose-100 dark:border-rose-800/30 p-3 rounded-xl text-rose-700 dark:text-rose-300 text-sm font-bold">
                          {plan.cta}
                        </div>
                      </div>
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1 block flex items-center gap-1">
                          <Hash size={10} /> Hashtags
                        </label>
                        <div className="flex flex-wrap gap-2">
                          {plan.hashtags.map((tag, i) => (
                            <span key={i} className="text-xs text-blue-600 dark:text-blue-400 hover:underline cursor-pointer">
                              #{tag.replace('#', '')}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            !isGenerating && (
              <div className="flex flex-col items-center justify-center h-64 bg-slate-50 dark:bg-slate-900/50 rounded-3xl border-2 border-dashed border-slate-200 dark:border-slate-800 text-center p-6">
                <div className="w-16 h-16 bg-white dark:bg-slate-800 rounded-full flex items-center justify-center mb-4 shadow-sm">
                  <Sparkles className="text-slate-300" size={32} />
                </div>
                <h3 className="font-bold text-slate-900 dark:text-white mb-1">Belum Ada Rencana Konten</h3>
                <p className="text-slate-500 dark:text-slate-400 text-sm max-w-md">
                  Isi konfigurasi di sebelah kiri dan klik "Generate 7-Day Plan" untuk mendapatkan strategi konten viral Anda.
                </p>
              </div>
            )
          )}
        </div>
      </div>
    </div>
  );
};
