import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  PenTool, Target, Briefcase, Palette, Sparkles, 
  Loader2, AlertCircle, Check, Copy, LayoutTemplate,
  BookOpen, Lightbulb, Image as ImageIcon, Download, RefreshCw,
  Upload, X
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { cn } from '@/src/lib/utils';

const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

const PERSONALITIES = [
  "Modern", "Luxury", "Minimalist", "Futuristic", 
  "Professional", "Medical", "Friendly", "Playful", "Bold"
];

const LOGO_STYLES = [
  "Minimalist", "Geometric", "Monogram", "Corporate", 
  "Luxury", "Modern Tech", "Vintage", "Abstract", "Mascot",
  "Wordmark Logo", "Pictorial", "Lettermark"
];

export const LogoDesign: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<any>(null);
  const [copiedStates, setCopiedStates] = useState<Record<string, boolean>>({});

  const [logoImages, setLogoImages] = useState<Record<number, string>>({});
  const [loadingLogoImages, setLoadingLogoImages] = useState<Record<number, boolean>>({});
  
  const [mockupImages, setMockupImages] = useState<Record<number, string>>({});
  const [loadingMockupImages, setLoadingMockupImages] = useState<Record<number, boolean>>({});

  const [activeLogoIndex, setActiveLogoIndex] = useState<number>(0);
  const [referenceImage, setReferenceImage] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    brandName: '',
    tagline: '',
    industry: '',
    personality: 'Modern',
    targetAudience: '',
    preferredColors: '',
    logoStyle: 'Minimalist',
    referenceText: ''
  });

  const resultRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (result && !loading && resultRef.current) {
      resultRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, [result, loading]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setReferenceImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedStates(prev => ({ ...prev, [id]: true }));
    setTimeout(() => setCopiedStates(prev => ({ ...prev, [id]: false })), 2000);
  };

  const handleRenderLogo = async (index: number, prompt: string) => {
    setLoadingLogoImages(prev => ({ ...prev, [index]: true }));
    try {
      const response = await genAI.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: prompt,
      });
      
      let imageUrl = '';
      for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
          imageUrl = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
          break;
        }
      }
      
      if (imageUrl) {
        setLogoImages(prev => ({ ...prev, [index]: imageUrl }));
      }
    } catch (err) {
      console.error(err);
      alert('Gagal merender logo.');
    } finally {
      setLoadingLogoImages(prev => ({ ...prev, [index]: false }));
    }
  };

  const handleRenderMockup = async (index: number, prompt: string) => {
    const logoImage = logoImages[activeLogoIndex];
    if (!logoImage) {
      alert('Silakan render logo terlebih dahulu pada konsep yang dipilih untuk digunakan sebagai referensi mockup.');
      return;
    }

    setLoadingMockupImages(prev => ({ ...prev, [index]: true }));
    try {
      const contents: any[] = [
        {
          role: 'user',
          parts: [
            { text: `Apply the provided logo image onto this mockup scene: ${prompt}. Ensure the logo is placed naturally, realistically, and clearly on the product or surface described.` },
            {
              inlineData: {
                mimeType: logoImage.split(';')[0].split(':')[1],
                data: logoImage.split(',')[1]
              }
            }
          ]
        }
      ];

      const response = await genAI.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: contents,
      });
      
      let imageUrl = '';
      for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
          imageUrl = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
          break;
        }
      }
      
      if (imageUrl) {
        setMockupImages(prev => ({ ...prev, [index]: imageUrl }));
      }
    } catch (err) {
      console.error(err);
      alert('Gagal merender mockup.');
    } finally {
      setLoadingMockupImages(prev => ({ ...prev, [index]: false }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.brandName || !formData.industry || !formData.targetAudience) {
      setError("Brand Name, Industry, dan Target Audience wajib diisi.");
      return;
    }
    
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const systemInstruction = `
        Anda adalah Creative Director, Brand Strategist, dan Logo Designer profesional yang memiliki pengalaman membuat identitas visual untuk berbagai brand modern, startup, perusahaan, dan bisnis profesional.
        Tugas Anda adalah membantu pengguna membuat konsep branding dan desain logo profesional yang kuat, modern, dan mudah diingat.
        Semua output harus terlihat seperti hasil kerja branding agency profesional.

        Jika pengguna memberikan referensi (baik berupa gambar atau teks), Anda HARUS mempertimbangkannya sebagai inspirasi utama atau batasan desain sesuai permintaan pengguna.

        Gunakan bahasa yang jelas, profesional, dan mudah dipahami.

        OUTPUT HARUS DALAM FORMAT JSON DENGAN STRUKTUR BERIKUT:
        {
          "brand_strategy_analysis": {
            "character": "Karakter brand...",
            "core_values": "Nilai utama brand...",
            "visual_message": "Pesan visual yang ingin disampaikan...",
            "market_positioning": "Positioning brand di pasar..."
          },
          "brand_story": "Cerita singkat mengenai brand yang menarik, emosional, dan mudah diingat...",
          "brand_personality_framework": {
            "vision": "...",
            "mission": "...",
            "core_values": ["...", "...", "..."],
            "emotional_branding": "..."
          },
          "logo_concept_ideas": [
            {
              "concept_name": "...",
              "main_visual_idea": "...",
              "symbol_used": "...",
              "symbol_meaning": "...",
              "design_style": "...",
              "ai_generation_prompt": "Prompt ultra-detail untuk konsep ini..."
            }
          ],
          "brand_mockup_visual_prompts": [
            {
              "media": "T-Shirt / Seragam",
              "prompt": "..."
            },
            {
              "media": "Mug / Gelas",
              "prompt": "..."
            },
            {
              "media": "Notebook / Buku",
              "prompt": "..."
            },
            {
              "media": "Business Card",
              "prompt": "..."
            },
            {
              "media": "Product Packaging",
              "prompt": "..."
            },
            {
              "media": "Office Signage",
              "prompt": "..."
            },
            {
              "media": "Tote Bag",
              "prompt": "..."
            },
            {
              "media": "Coffee Cup",
              "prompt": "..."
            },
            {
              "media": "Website Hero Section",
              "prompt": "..."
            },
            {
              "media": "Billboard",
              "prompt": "..."
            }
          ]
        }

        ATURAN DESAIN:
        Logo dan branding harus modern, profesional, mudah diingat, clean dan minimal, cocok untuk digital dan cetak.
        Gunakan gaya desain seperti modern branding, startup branding, premium corporate design.
        Prompt AI Logo Generation (ai_generation_prompt) harus ultra-detail untuk Midjourney/DALL-E/dll (contoh: Professional minimalist logo design for "Brand Name", modern geometric symbol...).
        Prompt Mockup harus realistis (contoh: Realistic premium t-shirt mockup featuring...).
      `;

      const userPrompt = `
        INPUT DATA:
        Brand Name: ${formData.brandName}
        Tagline: ${formData.tagline || '-'}
        Industry / Business Type: ${formData.industry}
        Brand Personality: ${formData.personality}
        Target Audience: ${formData.targetAudience}
        Preferred Colors: ${formData.preferredColors || '-'}
        Logo Style: ${formData.logoStyle}
        Reference Idea (Text): ${formData.referenceText || '-'}
        Reference Image: ${referenceImage ? 'Terlampir' : 'Tidak ada'}
      `;

      const contents: any[] = [{ role: 'user', parts: [{ text: userPrompt }] }];
      
      if (referenceImage) {
        contents[0].parts.push({
          inlineData: {
            mimeType: referenceImage.split(';')[0].split(':')[1],
            data: referenceImage.split(',')[1]
          }
        });
      }

      const response = await genAI.models.generateContent({
        model: "gemini-2.5-flash",
        contents: contents,
        config: {
          systemInstruction: systemInstruction,
          responseMimeType: "application/json"
        }
      });

      const text = response.text || "{}";
      setResult(JSON.parse(text));

    } catch (err) {
      console.error(err);
      setError("Gagal menghasilkan konsep branding. Silakan coba lagi.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight flex items-center gap-3">
            <div className="p-2 bg-indigo-600 rounded-xl text-white shadow-lg shadow-indigo-500/20">
              <PenTool size={24} />
            </div>
            Desain <span className="text-indigo-600 dark:text-indigo-400">Logo & Branding</span>
          </h2>
          <p className="text-slate-500 dark:text-slate-400 mt-1">
            Buat konsep identitas visual profesional layaknya creative agency.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Input Form */}
        <div className="lg:col-span-4 space-y-6 h-fit lg:sticky lg:top-8">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div className="flex items-center gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
              <Briefcase className="w-5 h-5 text-indigo-600" />
              <h3 className="font-bold text-slate-900 dark:text-white uppercase tracking-widest text-xs">Brand Brief</h3>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Brand Name *</label>
                  <input 
                    type="text" 
                    name="brandName"
                    value={formData.brandName}
                    onChange={handleInputChange}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-medium outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="Contoh: TechNova"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Tagline (Opsional)</label>
                  <input 
                    type="text" 
                    name="tagline"
                    value={formData.tagline}
                    onChange={handleInputChange}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-medium outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="Contoh: Innovating the Future"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Industry / Business Type *</label>
                  <input 
                    type="text" 
                    name="industry"
                    value={formData.industry}
                    onChange={handleInputChange}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-medium outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="Contoh: Software SaaS, F&B, Fashion..."
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Target Audience *</label>
                  <input 
                    type="text" 
                    name="targetAudience"
                    value={formData.targetAudience}
                    onChange={handleInputChange}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-medium outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="Contoh: Profesional muda, Gen Z..."
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Brand Personality</label>
                  <select 
                    name="personality"
                    value={formData.personality}
                    onChange={handleInputChange}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-medium outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    {PERSONALITIES.map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Logo Style</label>
                  <select 
                    name="logoStyle"
                    value={formData.logoStyle}
                    onChange={handleInputChange}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-medium outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    {LOGO_STYLES.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Preferred Colors (Opsional)</label>
                <input 
                  type="text" 
                  name="preferredColors"
                  value={formData.preferredColors}
                  onChange={handleInputChange}
                  className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-sm font-medium outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="Contoh: Navy Blue & Gold"
                />
              </div>

              <div className="space-y-4 pt-2">
                <div className="flex items-center gap-2">
                  <Lightbulb size={14} className="text-indigo-600" />
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Ide Referensi (Opsional)</span>
                </div>
                
                <div className="space-y-3">
                  <textarea
                    name="referenceText"
                    value={formData.referenceText}
                    onChange={handleInputChange}
                    rows={2}
                    className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-medium outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                    placeholder="Tulis ide atau referensi manual di sini..."
                  />
                  
                  <div className="relative">
                    {referenceImage ? (
                      <div className="relative w-full aspect-video rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 group">
                        <img src={referenceImage} alt="Reference" className="w-full h-full object-cover" />
                        <button 
                          type="button"
                          onClick={() => setReferenceImage(null)}
                          className="absolute top-2 right-2 p-1.5 bg-white/80 dark:bg-slate-900/80 rounded-lg text-rose-600 opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X size={16} />
                        </button>
                      </div>
                    ) : (
                      <label className="flex flex-col items-center justify-center w-full h-24 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-xl cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                        <div className="flex flex-col items-center justify-center pt-5 pb-6">
                          <Upload size={20} className="text-slate-400 mb-2" />
                          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Upload Referensi Gambar</p>
                        </div>
                        <input type="file" className="hidden" accept="image/*" onChange={handleImageUpload} />
                      </label>
                    )}
                  </div>
                </div>
              </div>

              <button 
                type="submit" 
                disabled={loading}
                className={cn(
                  "w-full py-4 rounded-xl font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 transition-all shadow-lg",
                  loading 
                    ? "bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed" 
                    : "bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-500/30 hover:-translate-y-1 active:translate-y-0"
                )}
              >
                {loading ? <Loader2 className="animate-spin" size={18} /> : <Sparkles size={18} />}
                {loading ? "Merancang Identitas..." : "Generate Branding"}
              </button>
            </form>
          </div>

          {error && (
            <div className="bg-rose-50 dark:bg-rose-900/20 border border-rose-100 dark:border-rose-800 p-4 rounded-xl flex items-start gap-3 text-rose-600 dark:text-rose-300">
              <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <p className="text-sm font-medium">{error}</p>
            </div>
          )}
        </div>

        {/* Output Section */}
        <div className="lg:col-span-8 space-y-8">
          {!result && !loading && (
            <div className="bg-white dark:bg-slate-900 p-12 rounded-3xl border-2 border-dashed border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center text-center h-full min-h-[500px] space-y-6">
              <div className="w-20 h-20 bg-slate-50 dark:bg-slate-950 rounded-2xl flex items-center justify-center text-slate-200 dark:text-slate-800">
                <PenTool size={40} />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">Belum Ada Konsep</h3>
                <p className="text-slate-500 dark:text-slate-400 max-w-sm mx-auto text-base">
                  Isi brief di samping untuk mulai merancang identitas visual brand Anda.
                </p>
              </div>
            </div>
          )}

          {loading && (
            <div className="bg-white dark:bg-slate-900 p-12 rounded-3xl border border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center text-center h-full min-h-[500px] shadow-sm space-y-8">
              <div className="relative">
                <div className="w-20 h-20 border-4 border-indigo-100 dark:border-indigo-900 rounded-full" />
                <div className="w-20 h-20 border-4 border-indigo-600 rounded-full border-t-transparent animate-spin absolute top-0" />
                <Sparkles className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-indigo-600" size={28} />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">Merancang Brand Identity</h3>
                <p className="text-slate-500 dark:text-slate-400 text-base">Menyusun strategi, konsep logo, dan prompt visual...</p>
              </div>
            </div>
          )}

          {result && !loading && (
            <div ref={resultRef} className="space-y-8">
              
              {/* 1. Brand Strategy Analysis */}
              <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
                <div className="bg-slate-50 dark:bg-slate-950/50 px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3">
                  <Target className="text-indigo-600" size={20} />
                  <h3 className="font-black text-slate-900 dark:text-white uppercase tracking-widest text-sm">1. Brand Strategy Analysis</h3>
                </div>
                <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                  {Object.entries(result.brand_strategy_analysis).map(([key, value]) => (
                    <div key={key} className="space-y-2">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{key.replace(/_/g, ' ')}</span>
                      <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">{String(value)}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* 2. Brand Story */}
              <div className="bg-indigo-600 text-white rounded-3xl p-8 shadow-lg relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 blur-[100px] rounded-full" />
                <div className="relative z-10 space-y-4">
                  <div className="flex items-center gap-3">
                    <BookOpen size={24} className="text-indigo-200" />
                    <h3 className="text-xl font-black tracking-tight uppercase italic">2. Brand Story</h3>
                  </div>
                  <p className="text-lg font-medium leading-relaxed text-indigo-50">
                    "{result.brand_story}"
                  </p>
                </div>
              </div>

              {/* 3. Brand Personality Framework */}
              <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
                <div className="bg-slate-50 dark:bg-slate-950/50 px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3">
                  <LayoutTemplate className="text-indigo-600" size={20} />
                  <h3 className="font-black text-slate-900 dark:text-white uppercase tracking-widest text-sm">3. Brand Personality Framework</h3>
                </div>
                <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-2">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Vision</span>
                    <p className="text-sm font-medium text-slate-800 dark:text-slate-200">{result.brand_personality_framework.vision}</p>
                  </div>
                  <div className="space-y-2">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Mission</span>
                    <p className="text-sm font-medium text-slate-800 dark:text-slate-200">{result.brand_personality_framework.mission}</p>
                  </div>
                  <div className="space-y-2">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Emotional Branding</span>
                    <p className="text-sm font-medium text-slate-800 dark:text-slate-200">{result.brand_personality_framework.emotional_branding}</p>
                  </div>
                  <div className="space-y-2">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Core Values</span>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {result.brand_personality_framework.core_values.map((val: string, i: number) => (
                        <span key={i} className="px-3 py-1 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-full text-xs font-bold">
                          {val}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* 4. Logo Concept Ideas & Prompts */}
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-indigo-600 rounded-lg text-white">
                    <Lightbulb size={18} />
                  </div>
                  <h3 className="font-black text-slate-900 dark:text-white uppercase tracking-widest text-lg">4. Logo Concept Ideas & Prompts</h3>
                </div>
                <div className="grid grid-cols-1 gap-6">
                  {result.logo_concept_ideas.map((concept: any, idx: number) => (
                    <motion.div 
                      key={idx}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.1 }}
                      className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                          <h4 className="text-lg font-bold text-slate-900 dark:text-white">{concept.concept_name}</h4>
                          {activeLogoIndex === idx && logoImages[idx] && (
                            <span className="px-2 py-0.5 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded text-[10px] font-bold uppercase tracking-wider flex items-center gap-1">
                              <Check size={10} /> Active for Mockups
                            </span>
                          )}
                        </div>
                        <span className="px-3 py-1 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-full text-xs font-bold uppercase tracking-wider">
                          {concept.design_style}
                        </span>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="space-y-1">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Main Visual Idea</span>
                          <p className="text-sm text-slate-700 dark:text-slate-300">{concept.main_visual_idea}</p>
                        </div>
                        <div className="space-y-1">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Symbol Used</span>
                          <p className="text-sm text-slate-700 dark:text-slate-300">{concept.symbol_used}</p>
                        </div>
                        <div className="space-y-1">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Symbol Meaning</span>
                          <p className="text-sm text-slate-700 dark:text-slate-300">{concept.symbol_meaning}</p>
                        </div>
                      </div>

                      {/* Prompt & Render Area */}
                      <div className="pt-6 border-t border-slate-100 dark:border-slate-800 grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest">AI Generation Prompt</span>
                            <button 
                              onClick={() => copyToClipboard(concept.ai_generation_prompt, `logo-prompt-${idx}`)}
                              className="text-slate-400 hover:text-indigo-600 transition-colors"
                            >
                              {copiedStates[`logo-prompt-${idx}`] ? <Check size={14} /> : <Copy size={14} />}
                            </button>
                          </div>
                          <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
                            <p className="text-xs font-mono text-slate-600 dark:text-slate-400 leading-relaxed">{concept.ai_generation_prompt}</p>
                          </div>
                        </div>

                        <div>
                          {logoImages[idx] ? (
                            <div className="relative aspect-square w-full max-w-[240px] mx-auto rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 group">
                              <img src={logoImages[idx]} alt={`Logo Concept ${idx + 1}`} className="w-full h-full object-cover" />
                              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                                <button 
                                  onClick={() => {
                                    const link = document.createElement('a');
                                    link.href = logoImages[idx];
                                    link.download = `logo-concept-${idx + 1}.png`;
                                    link.click();
                                  }}
                                  className="p-2 bg-white/20 hover:bg-white/40 rounded-lg text-white transition-colors"
                                  title="Download Image"
                                >
                                  <Download size={16} />
                                </button>
                                <button 
                                  onClick={() => handleRenderLogo(idx, concept.ai_generation_prompt)}
                                  className="p-2 bg-white/20 hover:bg-white/40 rounded-lg text-white transition-colors"
                                  title="Regenerate"
                                >
                                  <RefreshCw size={16} />
                                </button>
                              </div>
                              <button 
                                onClick={() => setActiveLogoIndex(idx)}
                                className={cn(
                                  "absolute bottom-2 left-1/2 -translate-x-1/2 px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all",
                                  activeLogoIndex === idx 
                                    ? "bg-emerald-600 text-white" 
                                    : "bg-white/90 text-slate-900 hover:bg-white"
                                )}
                              >
                                {activeLogoIndex === idx ? "Active for Mockups" : "Use for Mockups"}
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => handleRenderLogo(idx, concept.ai_generation_prompt)}
                              disabled={loadingLogoImages[idx]}
                              className="w-full max-w-[240px] mx-auto aspect-square rounded-xl border-2 border-dashed border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center gap-2 text-slate-400 hover:text-indigo-600 hover:border-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/10 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                              {loadingLogoImages[idx] ? (
                                <>
                                  <Loader2 size={24} className="animate-spin text-indigo-600" />
                                  <span className="text-xs font-bold text-indigo-600">Rendering Logo...</span>
                                </>
                              ) : (
                                <>
                                  <ImageIcon size={24} />
                                  <span className="text-xs font-bold uppercase tracking-wider">Render Logo</span>
                                </>
                              )}
                            </button>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* 5. Brand Mockup Visual Prompts */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-indigo-600 rounded-lg text-white">
                      <ImageIcon size={18} />
                    </div>
                    <h3 className="font-black text-slate-900 dark:text-white uppercase tracking-widest text-lg">5. Brand Mockup Visual Prompts</h3>
                  </div>
                  
                  {logoImages[activeLogoIndex] && (
                    <div className="flex items-center gap-3 px-4 py-2 bg-slate-100 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
                      <div className="w-8 h-8 rounded-lg overflow-hidden border border-slate-300 dark:border-slate-600">
                        <img src={logoImages[activeLogoIndex]} alt="Active Logo" className="w-full h-full object-cover" />
                      </div>
                      <div className="flex flex-col">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none">Using Logo</span>
                        <span className="text-xs font-bold text-slate-700 dark:text-slate-300">{result.logo_concept_ideas[activeLogoIndex].concept_name}</span>
                      </div>
                    </div>
                  )}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {result.brand_mockup_visual_prompts.map((mockup: any, idx: number) => (
                    <div key={idx} className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest">{mockup.media}</span>
                        <button 
                          onClick={() => copyToClipboard(mockup.prompt, `mockup-prompt-${idx}`)}
                          className="text-slate-400 hover:text-indigo-600 transition-colors"
                        >
                          {copiedStates[`mockup-prompt-${idx}`] ? <Check size={14} /> : <Copy size={14} />}
                        </button>
                      </div>
                      <p className="text-xs font-mono text-slate-500 dark:text-slate-400 leading-relaxed">{mockup.prompt}</p>
                      
                      {/* Render Area */}
                      <div className="mt-4">
                        {mockupImages[idx] ? (
                          <div className="relative aspect-video rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 group">
                            <img src={mockupImages[idx]} alt={`Mockup ${mockup.media}`} className="w-full h-full object-cover" />
                            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                              <button 
                                onClick={() => {
                                  const link = document.createElement('a');
                                  link.href = mockupImages[idx];
                                  link.download = `mockup-${mockup.media.replace(/[^a-z0-9]/gi, '-').toLowerCase()}.png`;
                                  link.click();
                                }}
                                className="p-2 bg-white/20 hover:bg-white/40 rounded-lg text-white transition-colors"
                                title="Download Image"
                              >
                                <Download size={16} />
                              </button>
                              <button 
                                onClick={() => handleRenderMockup(idx, mockup.prompt)}
                                className="p-2 bg-white/20 hover:bg-white/40 rounded-lg text-white transition-colors"
                                title="Regenerate"
                              >
                                <RefreshCw size={16} />
                              </button>
                            </div>
                          </div>
                        ) : (
                          <button
                            onClick={() => handleRenderMockup(idx, mockup.prompt)}
                            disabled={loadingMockupImages[idx]}
                            className="w-full aspect-video rounded-xl border-2 border-dashed border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center gap-2 text-slate-400 hover:text-indigo-600 hover:border-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/10 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                            {loadingMockupImages[idx] ? (
                              <>
                                <Loader2 size={24} className="animate-spin text-indigo-600" />
                                <span className="text-xs font-bold text-indigo-600">Rendering...</span>
                              </>
                            ) : (
                              <>
                                <ImageIcon size={24} />
                                <span className="text-xs font-bold uppercase tracking-wider">Render Mockup</span>
                              </>
                            )}
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}
        </div>
      </div>
    </div>
  );
};
