import React, { useState, useEffect } from 'react';
import { 
  Wand2, Clapperboard, Image as ImageIcon, Video, Copy, Check, CheckCircle2, 
  ChevronRight, FileText, Settings, Loader2, RefreshCw, Music, Eye, 
  Headphones, Sparkles, LayoutTemplate, PenTool, Hash, MessageSquare, 
  TrendingUp, Mic, MonitorPlay, Zap, Megaphone, BarChart, DollarSign, Share2, Layers, Smartphone, Magnet, Target, Send
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";
import { cn } from '@/src/lib/utils';

// --- API Configuration using SDK ---
const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

const callGeminiAPI = async (promptText: string, systemInstruction: string) => {
  try {
    const model = "gemini-3-flash-preview"; // Using the recommended flash model for speed
    const response = await genAI.models.generateContent({
      model: model,
      contents: [{ role: 'user', parts: [{ text: promptText }] }],
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json"
      }
    });
    return response.text || "{}";
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Gagal menghubungi AI.");
  }
};

const GAYA_VISUAL_OPTIONS = [
  "Cinematic Realism, 8k, Unreal",
  "Pixar 3D Animation Style",
  "Dark Fantasy Cinematic",
  "Studio Ghibli Anime",
  "Cyberpunk Neon Sci-Fi",
  "Claymation"
];

const REFERENSI_LAGU_OPTIONS = [
  "Auto",
  "Dark Ambient Misterius",
  "Epic Orchestral",
  "Lofi Chill & Relax",
  "Sci-Fi Synthwave",
  "Acoustic Storytelling",
  "Horror Suspense"
];

const KATEGORI_OPTIONS = ["Edukasi", "Storytelling", "Fakta Menarik"];
const JUMLAH_ADEGAN_OPTIONS = [6, 8, 10, 12, 14, 16];

const GAYA_BAHASA_OPTIONS = ["Normal", "Loe Gue", "Absurd", "Loe Gue + Absurd", "Komedi"];
const JARAK_KAMERA_OPTIONS = ["Auto", "Extreme Close Up", "Close Up", "Medium Shot", "Long Shot", "Extreme Long Shot"];

export const StaticAnimation: React.FC = () => {
  // --- App State ---
  const [activeTab, setActiveTab] = useState('config'); // config, script, visuals
  const [loading, setLoading] = useState(false);
  const [loadingScene, setLoadingScene] = useState<number | null>(null);
  const [copiedStates, setCopiedStates] = useState<Record<string, boolean>>({});

  // Inputs
  const [inputs, setInputs] = useState({
    kategori: "Fakta Menarik",
    tema: "",
    gayaVisual: "",
    referensiLagu: "Auto",
    jumlahAdegan: 14,
    anjuranVisual: "",
    gayaBahasa: "Normal",
    absurdLevel: 5,
    jarakKamera: "Auto"
  });

  // Generated Data
  const [scriptData, setScriptData] = useState<any>({ deskripsi: "", rekomendasi_backsound: null, adegan: [] });
  const [visualPrompts, setVisualPrompts] = useState<Record<number, any>>({});
  
  // LLM Feature States
  const [topicIdeas, setTopicIdeas] = useState<string[]>([]);
  const [loadingTopics, setLoadingTopics] = useState(false);
  
  const [socialMeta, setSocialMeta] = useState<any>(null);
  const [loadingSocial, setLoadingSocial] = useState(false);

  const [voiceData, setVoiceData] = useState<any>(null);
  const [loadingVoice, setLoadingVoice] = useState(false);

  const [thumbnailData, setThumbnailData] = useState<any>(null);
  const [loadingThumbnail, setLoadingThumbnail] = useState(false);

  const [titleIdeasData, setTitleIdeasData] = useState<any>(null);
  const [loadingTitleIdeas, setLoadingTitleIdeas] = useState(false);

  const [engagementData, setEngagementData] = useState<any>(null);
  const [loadingEngagement, setLoadingEngagement] = useState(false);

  const [repurposeData, setRepurposeData] = useState<any>(null);
  const [loadingRepurpose, setLoadingRepurpose] = useState(false);

  const [sponsorData, setSponsorData] = useState<any>(null);
  const [loadingSponsor, setLoadingSponsor] = useState(false);

  const [hooksData, setHooksData] = useState<any>(null);
  const [loadingHooks, setLoadingHooks] = useState(false);

  const [audienceData, setAudienceData] = useState<any>(null);
  const [loadingAudience, setLoadingAudience] = useState(false);

  // --- Persistence Logic ---
  useEffect(() => {
    const savedState = localStorage.getItem('staticAnimationState');
    if (savedState) {
      try {
        const parsed = JSON.parse(savedState);
        const savedTime = parsed.timestamp;
        const currentTime = new Date().getTime();
        
        // Check if 1 hour (3600000 ms) has passed
        if (savedTime && (currentTime - savedTime < 3600000)) {
          if (parsed.activeTab) setActiveTab(parsed.activeTab);
          if (parsed.inputs) setInputs(prev => ({ ...prev, ...parsed.inputs }));
          if (parsed.scriptData) setScriptData(parsed.scriptData);
          if (parsed.visualPrompts) setVisualPrompts(parsed.visualPrompts);
          if (parsed.topicIdeas) setTopicIdeas(parsed.topicIdeas);
          if (parsed.socialMeta) setSocialMeta(parsed.socialMeta);
          if (parsed.voiceData) setVoiceData(parsed.voiceData);
          if (parsed.thumbnailData) setThumbnailData(parsed.thumbnailData);
          if (parsed.titleIdeasData) setTitleIdeasData(parsed.titleIdeasData);
          if (parsed.engagementData) setEngagementData(parsed.engagementData);
          if (parsed.repurposeData) setRepurposeData(parsed.repurposeData);
          if (parsed.sponsorData) setSponsorData(parsed.sponsorData);
          if (parsed.hooksData) setHooksData(parsed.hooksData);
          if (parsed.audienceData) setAudienceData(parsed.audienceData);
        } else {
          // Clear expired state
          localStorage.removeItem('staticAnimationState');
        }
      } catch (e) {
        console.error("Failed to load saved state", e);
      }
    }
  }, []);

  useEffect(() => {
    const stateToSave = {
      timestamp: new Date().getTime(),
      activeTab,
      inputs,
      scriptData,
      visualPrompts,
      topicIdeas,
      socialMeta,
      voiceData,
      thumbnailData,
      titleIdeasData,
      engagementData,
      repurposeData,
      sponsorData,
      hooksData,
      audienceData
    };
    localStorage.setItem('staticAnimationState', JSON.stringify(stateToSave));
  }, [
    activeTab, inputs, scriptData, visualPrompts, topicIdeas, 
    socialMeta, voiceData, thumbnailData, titleIdeasData, 
    engagementData, repurposeData, sponsorData, hooksData, audienceData
  ]);

  // --- Handlers ---
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setInputs(prev => ({ ...prev, [name]: value }));
  };

  const copyToClipboard = (text: string, id: string) => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    setCopiedStates(prev => ({ ...prev, [id]: true }));
    setTimeout(() => {
      setCopiedStates(prev => ({ ...prev, [id]: false }));
    }, 2000);
  };

  // --- AI Generation Logic ---

  const generateTopicIdeas = async () => {
    if (!inputs.tema.trim()) {
      alert("Silakan ketik ide dasar atau topik cerita di kolom 'Topik / Judul Cerita' terlebih dahulu!");
      return;
    }

    setLoadingTopics(true);
    const systemPrompt = `
      Anda adalah ahli tren TikTok dan Content Strategist jenius.
      Tugas Anda adalah mengembangkan ide dasar menjadi 3 ide judul/topik cerita turunan yang SANGAT memancing rasa penasaran (hook/clickbait tapi berbobot, faktual, dan edukatif) yang siap viral.
      Kembalikan HANYA dalam format JSON: { "ide": ["Ide Viral 1", "Ide Viral 2", "Ide Viral 3"] }
    `;
    const userPrompt = `Kategori: ${inputs.kategori}\nIde Dasar Topik: ${inputs.tema}\n\nKembangkan ide dasar di atas menjadi 3 topik spesifik yang sangat viral!`;

    try {
      const resultText = await callGeminiAPI(userPrompt, systemPrompt);
      const parsedData = JSON.parse(resultText);
      if (parsedData && Array.isArray(parsedData.ide)) {
        setTopicIdeas(parsedData.ide);
      }
    } catch (error) {
      console.error("Gagal mendapatkan ide topik:", error);
    } finally {
      setLoadingTopics(false);
    }
  };

  const generateScript = async () => {
    setLoading(true);
    setScriptData({ deskripsi: "", rekomendasi_backsound: null, adegan: [] });
    setVisualPrompts({});
    
    // Reset all post-generation metas
    setSocialMeta(null);
    setVoiceData(null);
    setThumbnailData(null);
    setTitleIdeasData(null);
    setEngagementData(null);
    setRepurposeData(null);
    setSponsorData(null);
    setHooksData(null);
    setAudienceData(null);
    
    setActiveTab('script');
    
    const systemPrompt = `
      Anda adalah seorang penulis naskah profesional, peneliti konten, dan ahli retensi audiens untuk platform video pendek (TikTok/Reels/Shorts).
      Tugas Anda: Buat skrip konten storytelling yang SANGAT MENARIK, memancing rasa penasaran (curiosity gap), dan membuat penonton bertahan hingga detik terakhir.

      STRUKTUR ALUR CERITA (WAJIB):
      Ikuti alur cerita berikut secara berurutan (sesuaikan jumlahnya dengan total ${inputs.jumlahAdegan} adegan yang diminta, namun prioritaskan poin-poin kunci ini):
      1. Hook pembuka dengan kalimat yang memancing rasa penasaran.
      2. Perkenalan topiknya secara menarik.
      3. Penjelasan singkat mengenai topik tersebut.
      4. Fakta dasarnya secara jelas.
      5. Penjelasan mendalam dari fakta tersebut.
      6. Asal-usul dan lokasi kejadian atau fenomena tersebut.
      7. Penjelasan detail tentang asal-usul dan lokasinya.
      8. Bagian paling mengejutkan atau plot twist dari topik ini.
      9. Fakta tambahan yang jarang diketahui orang banyak.
      10. Penjelasan dari fakta tambahan tersebut.
      11. Sisi unik lain yang belum banyak dibahas di media lain.
      12. Penjelasan detail sisi unik tersebut.
      13. Pelajaran penting atau insight berharga dari cerita ini.
      14. Pertanyaan penutup untuk mengajak interaksi penonton di komentar.

      Jika jumlah adegan yang diminta (${inputs.jumlahAdegan}) kurang dari 14, gabungkan beberapa poin di atas tanpa menghilangkan Hook, Fakta Utama, Pelajaran, dan Pertanyaan Penutup. Jika lebih dari 14, kembangkan penjelasan pada poin-poin yang ada.

      Aturan Ketat:
      1. Bahasa narasi ringan, "storytelling" banget, edukatif, dan sangat mudah divisualisasikan.
      2. Kalimat narasi senatural mungkin (seperti orang bercerita langsung).
      3. MAKSIMAL 20 KATA PER KALIMAT NARASI agar narasi lebih lengkap namun tetap mudah dipahami.
      4. GAYA BAHASA: Gunakan gaya bahasa "${inputs.gayaBahasa}"${inputs.gayaBahasa.includes("Absurd") ? ` dengan tingkat keanehan/absurditas level ${inputs.absurdLevel} dari 10 (semakin tinggi semakin tidak masuk akal dan liar)` : ""}.
      5. Untuk bagian "deskripsi" (Data Riset), tuliskan 3-5 PARAGRAF faktual yang mendalam sebagai referensi.
      6. Berikan rekomendasi BACKSOUND yang epik${inputs.referensiLagu && inputs.referensiLagu !== "Auto" ? ` berdasarkan preferensi pengguna: "${inputs.referensiLagu}"` : ' yang sesuai dengan tema cerita'}.
      7. Anda HARUS menghasilkan TEPAT ${inputs.jumlahAdegan} adegan/scene.
      8. Output HARUS dalam format JSON yang valid.

      Struktur JSON:
      {
        "deskripsi": "...",
        "rekomendasi_backsound": {
          "genre": "...",
          "mood": "...",
          "panduan_pencarian": "..."
        },
        "adegan": [
          {
            "bagian": "Contoh: Hook / Klimaks / CTA",
            "nada": "Contoh: Misterius / Antusias / Serius",
            "narasi": "..."
          }
        ]
      }
    `;

    const userPrompt = `Buatkan script untuk kategori ${inputs.kategori} dengan topik/judul: ${inputs.tema}.${inputs.referensiLagu && inputs.referensiLagu !== "Auto" ? ` Preferensi Lagu: ${inputs.referensiLagu}` : ''}`;

    try {
      const resultText = await callGeminiAPI(userPrompt, systemPrompt);
      const parsedData = JSON.parse(resultText);
      setScriptData({
        deskripsi: parsedData?.deskripsi || "",
        rekomendasi_backsound: parsedData?.rekomendasi_backsound || null,
        adegan: Array.isArray(parsedData?.adegan) ? parsedData.adegan : []
      });
    } catch (error) {
      console.error(error);
      setActiveTab('config');
    } finally {
      setLoading(false);
    }
  };

  const generateSocialMeta = async () => {
    setLoadingSocial(true);
    const systemPrompt = `
      Anda adalah Social Media Manager jenius khusus untuk algoritma TikTok dan Reels.
      Tugas Anda merumuskan Caption, Hashtag viral, dan Hook Text (1-2 kalimat pendek).
      Kembalikan dalam format JSON:
      {
        "caption": "...",
        "hashtags": "#...",
        "hook_text": "..."
      }
    `;
    const fullNarrative = (scriptData?.adegan || []).map((s: any) => s?.narasi || "").join(" ");
    const userPrompt = `Naskah: ${fullNarrative}\n\nTopik: ${inputs.tema}`;
    try {
      const resultText = await callGeminiAPI(userPrompt, systemPrompt);
      setSocialMeta(JSON.parse(resultText));
    } catch (error) { console.error(error); } finally { setLoadingSocial(false); }
  };

  const generateVoiceoverMeta = async () => {
    setLoadingVoice(true);
    const systemPrompt = `
      Anda adalah seorang Audio Director dan ahli AI Text-To-Speech (TTS).
      Tentukan Karakter Suara, Nada & Kecepatan, dan Prompt AI Voice (English).
      Format JSON:
      {
        "karakter": "...",
        "nada_kecepatan": "...",
        "ai_prompt": "..."
      }
    `;
    const fullNarrative = (scriptData?.adegan || []).map((s: any) => s?.narasi || "").join(" ");
    const userPrompt = `Topik: ${inputs.tema}\nNaskah:\n${fullNarrative}`;
    try {
      const resultText = await callGeminiAPI(userPrompt, systemPrompt);
      setVoiceData(JSON.parse(resultText));
    } catch (error) { console.error(error); } finally { setLoadingVoice(false); }
  };

  const generateThumbnailIdea = async () => {
    setLoadingThumbnail(true);
    const systemPrompt = `
      Anda adalah seorang YouTube & TikTok Thumbnail Designer ahli yang spesialis dalam menciptakan visual viral dan clicky.
      Tugas Anda: Merancang 1 ide thumbnail yang SANGAT MENARIK, berkualitas tinggi, dan memicu rasa penasaran (curiosity gap).
      
      Anda harus menghasilkan:
      1. Teks Thumbnail: Judul yang singkat, padat, dan provokatif yang akan diletakkan di thumbnail.
      2. Elemen Visual: Deskripsi elemen utama yang harus ada di gambar.
      3. Suasana/Latar: Mood, pencahayaan, dan latar belakang.
      4. IMAGE PROMPT (BAHASA INGGRIS): Prompt text-to-image yang sangat detail untuk AI Image Generator (seperti Midjourney/DALL-E). 
         - Sertakan deskripsi teks judul yang terintegrasi dalam visual (misal: "with bold 3D text that says '...'").
         - Gunakan style visual yang menarik (Cinematic, Hyper-realistic, atau sesuai tema).
         - Pastikan komposisinya pas antara subjek visual dan ruang untuk teks.
      5. Alasan Desain: Penjelasan mengapa desain ini akan berhasil menarik klik.

      Format JSON:
      {
        "teks_thumbnail": "...",
        "elemen_visual": "...",
        "suasana": "...",
        "image_prompt": "...",
        "alasan_desain": "..."
      }
    `;
    const fullNarrative = (scriptData?.adegan || []).map((s: any) => s?.narasi || "").join(" ");
    const userPrompt = `Topik/Judul: ${inputs.tema}\nNaskah Singkat:\n${fullNarrative}`;
    try {
      const resultText = await callGeminiAPI(userPrompt, systemPrompt);
      setThumbnailData(JSON.parse(resultText));
    } catch (error) { console.error(error); } finally { setLoadingThumbnail(false); }
  };

  const generateTitleIdeas = async () => {
    setLoadingTitleIdeas(true);
    const systemPrompt = `
      Anda adalah Pakar SEO dan Copywriter Handal.
      Berikan 5 variasi judul: Clickbait, SEO, Penasaran, Storytelling, Kontroversial.
      Format JSON:
      {
        "judul_clickbait": "...",
        "judul_seo": "...",
        "judul_penasaran": "...",
        "judul_storytelling": "...",
        "judul_kontroversial": "..."
      }
    `;
    const fullNarrative = (scriptData?.adegan || []).map((s: any) => s?.narasi || "").join(" ");
    const userPrompt = `Topik: ${inputs.tema}\nNaskah Singkat:\n${fullNarrative}`;
    try {
      const resultText = await callGeminiAPI(userPrompt, systemPrompt);
      setTitleIdeasData(JSON.parse(resultText));
    } catch (error) { console.error(error); } finally { setLoadingTitleIdeas(false); }
  };

  const generateEngagementPlan = async () => {
    setLoadingEngagement(true);
    const systemPrompt = `
      Anda adalah Manajer Komunitas / Social Media Strategist.
      Rumuskan Komentar Pinned, Pertanyaan Polling, dan Tantangan Penonton.
      Format JSON:
      {
        "komentar_pinned": "...",
        "pertanyaan_polling": "...",
        "tantangan_penonton": "..."
      }
    `;
    const fullNarrative = (scriptData?.adegan || []).map((s: any) => s?.narasi || "").join(" ");
    const userPrompt = `Topik: ${inputs.tema}\nNaskah Singkat:\n${fullNarrative}`;
    try {
      const resultText = await callGeminiAPI(userPrompt, systemPrompt);
      setEngagementData(JSON.parse(resultText));
    } catch (error) { console.error(error); } finally { setLoadingEngagement(false); }
  };

  const generateRepurposePlan = async () => {
    setLoadingRepurpose(true);
    const systemPrompt = `
      Anda adalah Content Repurposing Expert.
      Buat Twitter/X Thread (4-6 tweet) dan IG Carousel (5 Slide).
      Format JSON:
      {
        "twitter_thread": ["..."],
        "ig_carousel": ["..."]
      }
    `;
    const fullNarrative = (scriptData?.adegan || []).map((s: any) => s?.narasi || "").join(" ");
    const userPrompt = `Topik: ${inputs.tema}\nNaskah Sumber:\n${fullNarrative}`;
    try {
      const resultText = await callGeminiAPI(userPrompt, systemPrompt);
      setRepurposeData(JSON.parse(resultText));
    } catch (error) { console.error(error); } finally { setLoadingRepurpose(false); }
  };

  const generateSponsorIdea = async () => {
    setLoadingSponsor(true);
    const systemPrompt = `
      Anda adalah Ahli Monetisasi Kreator.
      Berikan Kategori Produk, Ide Penawaran, dan Kalimat Transisi (Pitch).
      Format JSON:
      {
        "kategori_produk": "...",
        "ide_penawaran": "...",
        "kalimat_transisi": "..."
      }
    `;
    const fullNarrative = (scriptData?.adegan || []).map((s: any) => s?.narasi || "").join(" ");
    const userPrompt = `Topik: ${inputs.tema}\nNaskah Sumber:\n${fullNarrative}`;
    try {
      const resultText = await callGeminiAPI(userPrompt, systemPrompt);
      setSponsorData(JSON.parse(resultText));
    } catch (error) { console.error(error); } finally { setLoadingSponsor(false); }
  };

  const generateAlternateHooks = async () => {
    setLoadingHooks(true);
    const systemPrompt = `
      Anda adalah Pakar Retensi Video Pendek.
      Buat 3 alternatif Hook: Pertanyaan Provokatif, Fakta Mengejutkan, Emosional.
      Format JSON:
      {
        "hook_pertanyaan": "...",
        "hook_fakta": "...",
        "hook_emosional": "..."
      }
    `;
    const fullNarrative = (scriptData?.adegan || []).map((s: any) => s?.narasi || "").join(" ");
    const userPrompt = `Naskah Asli:\n${fullNarrative}`;
    try {
      const resultText = await callGeminiAPI(userPrompt, systemPrompt);
      setHooksData(JSON.parse(resultText));
    } catch (error) { console.error(error); } finally { setLoadingHooks(false); }
  };

  const generateAudienceStrategy = async () => {
    setLoadingAudience(true);
    const systemPrompt = `
      Anda adalah Analis Algoritma TikTok.
      Tentukan Target Persona, Pemicu Psikologis, dan Rekomendasi Waktu Posting.
      Format JSON:
      {
        "target_persona": "...",
        "pemicu_psikologis": "...",
        "waktu_posting": "..."
      }
    `;
    const fullNarrative = (scriptData?.adegan || []).map((s: any) => s?.narasi || "").join(" ");
    const userPrompt = `Analisis naskah berikut:\n${fullNarrative}`;
    try {
      const resultText = await callGeminiAPI(userPrompt, systemPrompt);
      setAudienceData(JSON.parse(resultText));
    } catch (error) { console.error(error); } finally { setLoadingAudience(false); }
  };

  const generateVisualPromptForScene = async (index: number, sceneData: any) => {
    setLoadingScene(index);
    
    const gayaVisualAktif = inputs.gayaVisual.trim() !== "" ? inputs.gayaVisual : "Cinematic Realism, 8k, Unreal Engine 5";
    const anjuranVisualAktif = inputs.anjuranVisual.trim() !== "" ? inputs.anjuranVisual : "Buat visual yang dramatis, proporsional, dan menarik perhatian penonton";

    const systemPrompt = `
      Anda adalah seorang Visual Artist profesional dan prompt engineer ahli dalam memvisualisasikan narasi menjadi gambar/animasi premium.
      Tugas Anda: Merancang 1 visual adegan yang SANGAT DETAIL dan SINKRON dengan narasi yang diberikan.

      ATURAN KHUSUS:
      1. Satu Narasi = Satu Adegan. Fokus pada inti narasi.
      2. Visual harus masuk akal, premium, dan tidak kaku. Hindari visual lelucon (seperti balok kayu bersalaman).
      3. Gerakan harus smooth, natural, dan sesuai kebutuhan adegan.
      4. Jangan ada efek glowing.
      5. Jika gaya visual adalah "Claymation":
         - Gunakan gaya "Aardman-style claymotion".
         - Karakter dari clay halus tanpa sidik jari yang terlihat (smooth clay).
         - Tekstur sedikit tidak rata (slightly uneven textures) tapi tetap premium.
         - Ambil jalan tengah: jangan terlalu clay dan jangan terlalu realistis.
      6. Untuk gaya visual lain, sesuaikan material dan tekstur agar tetap premium dan hyper-realistis.
      7. Output harus dalam format JSON.

      STRUKTUR PROMPT (BAHASA INGGRIS):
      "A wide scenic view of [deskripsi setting], in expressive [Style] with ultra-HD cinematic detail. [Deskripsi utama aksi/cerita pada scene]. Characters are made of [Material] with [Texture], and enhanced ultra-HD details, animated with exaggerated gestures and expressive eyes that shine under cinematic lighting. [Detail tambahan tentang lingkungan, efek, dan suasana dengan kualitas tinggi, seperti bayangan tajam, pantulan cahaya, atau tekstur tanah/air yang sangat detail]. Lighting is highly cinematic, with realistic ultra-HD shadows and vibrant natural tones, creating strong depth and atmosphere. The overall scene feels alive in ultra-HD clarity, with subtle background movements (rustling leaves, drifting smoke, distant animals moving) rendered in sharp detail, enhancing the storytelling. A vertical 9:16"

      Struktur JSON:
      {
        "penjelasan_visual": "Jelaskan dalam Bahasa Indonesia apa yang digambarkan dalam prompt ini dan narasi mana yang dianimasikan agar pengguna tahu.",
        "final_prompt": "Prompt lengkap dalam Bahasa Inggris mengikuti struktur di atas."
      }
    `;

    const userPrompt = `
      Narasi: "${sceneData.narasi}"
      Gaya Visual: ${gayaVisualAktif}
      Catatan Tambahan: ${anjuranVisualAktif}
      ${inputs.jarakKamera !== "Auto" ? `Jarak Kamera: ${inputs.jarakKamera}` : ""}
    `;

    try {
      const resultText = await callGeminiAPI(userPrompt, systemPrompt);
      const parsedData = JSON.parse(resultText);
      
      setVisualPrompts(prev => ({
        ...prev,
        [index]: {
          penjelasan_visual: parsedData?.penjelasan_visual || "",
          final_prompt: parsedData?.final_prompt || ""
        }
      }));
    } catch (error) {
      console.error(error);
      setVisualPrompts(prev => ({
        ...prev,
        [index]: { penjelasan_visual: "Gagal memproses penjelasan.", final_prompt: "Gagal memproses prompt." }
      }));
    } finally {
      setLoadingScene(null);
    }
  };

  const isScriptGenerated = scriptData && Array.isArray(scriptData.adegan) && scriptData.adegan.length > 0;

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight flex items-center gap-3">
            <div className="p-2 bg-blue-600 rounded-xl text-white shadow-lg shadow-blue-500/20">
              <Sparkles size={24} />
            </div>
            Animasi Statis <span className="text-blue-600 dark:text-blue-400">Studio</span>
          </h2>
          <p className="text-slate-500 dark:text-slate-400 mt-1">Rancang naskah dan visual animasi statis kelas dunia dengan AI.</p>
        </div>

        {/* Stepper Navigation */}
        <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-900 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-800">
          {[
            { id: 'config', label: 'Konfigurasi', icon: Settings, step: 1 },
            { id: 'script', label: 'Naskah', icon: FileText, step: 2 },
            { id: 'visuals', label: 'Visual', icon: Clapperboard, step: 3 }
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            const isDisabled = tab.id !== 'config' && !isScriptGenerated;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                disabled={isDisabled}
                className={cn(
                  "flex items-center px-4 py-2 rounded-xl text-xs font-bold transition-all duration-300",
                  isActive 
                    ? "bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-sm" 
                    : "text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 disabled:opacity-40"
                )}
              >
                <span className={cn(
                  "w-5 h-5 rounded-full flex items-center justify-center text-[10px] mr-2",
                  isActive ? "bg-blue-600 text-white" : "bg-slate-200 dark:bg-slate-700 text-slate-500"
                )}>
                  {tab.step}
                </span>
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      <AnimatePresence mode="wait">
        {/* TAB 1: Configuration */}
        {activeTab === 'config' && (
          <motion.div
            key="config"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-8"
          >
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 shadow-sm space-y-8">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-50 dark:bg-blue-900/30 rounded-xl text-blue-600">
                  <LayoutTemplate size={20} />
                </div>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white">Struktur Konten</h3>
              </div>

              <div className="space-y-6">
                <div className="space-y-3">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Pilih Kategori</label>
                  <div className="flex flex-wrap gap-2">
                    {KATEGORI_OPTIONS.map((kat) => (
                      <button
                        key={kat}
                        onClick={() => setInputs(prev => ({ ...prev, kategori: kat }))}
                        className={cn(
                          "px-4 py-2 rounded-xl text-sm font-bold border transition-all",
                          inputs.kategori === kat 
                            ? "bg-blue-600 text-white border-blue-600 shadow-lg shadow-blue-500/20" 
                            : "bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:border-blue-400"
                        )}
                      >
                        {kat}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Topik / Judul Cerita</label>
                    <button 
                      onClick={generateTopicIdeas}
                      disabled={loadingTopics}
                      className="text-[10px] font-bold text-blue-600 dark:text-blue-400 flex items-center gap-1 hover:underline disabled:opacity-50"
                    >
                      {loadingTopics ? <Loader2 size={12} className="animate-spin"/> : <Sparkles size={12}/>}
                      Kembangkan Ide Viral
                    </button>
                  </div>
                  <input 
                    type="text" 
                    name="tema" 
                    value={inputs.tema} 
                    onChange={handleInputChange}
                    placeholder="misal: Misteri Segitiga Bermuda..."
                    className="w-full p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none transition-all text-slate-900 dark:text-white"
                  />
                  
                  {topicIdeas.length > 0 && (
                    <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-2xl border border-blue-100 dark:border-blue-800 space-y-2">
                      <p className="text-[10px] font-bold text-blue-600 uppercase tracking-widest flex items-center gap-1">
                        <TrendingUp size={12}/> Rekomendasi Judul Viral:
                      </p>
                      <div className="flex flex-col gap-2">
                        {topicIdeas.map((idea, idx) => (
                          <button 
                            key={idx}
                            onClick={() => setInputs(prev => ({...prev, tema: idea}))}
                            className="text-left text-xs font-medium text-slate-700 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                          >
                            • {idea}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div className="space-y-3">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Durasi (Jumlah Adegan)</label>
                  <div className="flex flex-wrap gap-2">
                    {JUMLAH_ADEGAN_OPTIONS.map((num) => (
                      <button
                        key={num}
                        onClick={() => setInputs(prev => ({ ...prev, jumlahAdegan: num }))}
                        className={cn(
                          "px-4 py-2 rounded-xl text-sm font-bold border transition-all",
                          inputs.jumlahAdegan === num 
                            ? "bg-blue-600 text-white border-blue-600" 
                            : "bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:border-blue-400"
                        )}
                      >
                        {num} Scene
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Gaya Bahasa</label>
                  <div className="flex flex-wrap gap-2">
                    {GAYA_BAHASA_OPTIONS.map((gaya) => (
                      <button
                        key={gaya}
                        onClick={() => setInputs(prev => ({ ...prev, gayaBahasa: gaya }))}
                        className={cn(
                          "px-4 py-2 rounded-xl text-sm font-bold border transition-all",
                          inputs.gayaBahasa === gaya 
                            ? "bg-blue-600 text-white border-blue-600 shadow-lg shadow-blue-500/20" 
                            : "bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:border-blue-400"
                        )}
                      >
                        {gaya}
                      </button>
                    ))}
                  </div>
                </div>

                {inputs.gayaBahasa.includes("Absurd") && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="space-y-3 p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800"
                  >
                    <div className="flex justify-between items-center">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Level Absurd: {inputs.absurdLevel}</label>
                      <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest">
                        {inputs.absurdLevel <= 3 ? 'Sedikit Aneh' : inputs.absurdLevel <= 7 ? 'Sangat Absurd' : 'Gila / Tidak Masuk Akal'}
                      </span>
                    </div>
                    <input 
                      type="range" 
                      min="1" 
                      max="10" 
                      step="1"
                      value={inputs.absurdLevel}
                      onChange={(e) => setInputs(prev => ({ ...prev, absurdLevel: parseInt(e.target.value) }))}
                      className="w-full h-2 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-600"
                    />
                    <div className="flex justify-between text-[10px] font-bold text-slate-400">
                      <span>1</span>
                      <span>5</span>
                      <span>10</span>
                    </div>
                  </motion.div>
                )}
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 shadow-sm space-y-8">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-50 dark:bg-indigo-900/30 rounded-xl text-indigo-600">
                  <PenTool size={20} />
                </div>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white">Estetika Studio</h3>
              </div>

              <div className="space-y-6">
                <div className="space-y-3">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <Headphones size={14}/> Preferensi Backsound <span className="text-slate-500 normal-case font-normal">(Optional)</span>
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {REFERENSI_LAGU_OPTIONS.map((lagu) => (
                      <button
                        key={lagu}
                        onClick={() => setInputs(prev => ({ ...prev, referensiLagu: lagu }))}
                        className={cn(
                          "px-3 py-1.5 rounded-lg text-xs font-bold border transition-all",
                          inputs.referensiLagu === lagu 
                            ? "bg-indigo-600 text-white border-indigo-600" 
                            : "bg-slate-50 dark:bg-slate-950 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:border-indigo-400"
                        )}
                      >
                        {lagu}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <Video size={14}/> Jarak Kamera (Camera Distance) <span className="text-slate-500 normal-case font-normal">(Optional)</span>
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {JARAK_KAMERA_OPTIONS.map((jarak) => (
                      <button
                        key={jarak}
                        onClick={() => setInputs(prev => ({ ...prev, jarakKamera: jarak }))}
                        className={cn(
                          "px-3 py-1.5 rounded-lg text-xs font-bold border transition-all",
                          inputs.jarakKamera === jarak 
                            ? "bg-indigo-600 text-white border-indigo-600" 
                            : "bg-slate-50 dark:bg-slate-950 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:border-indigo-400"
                        )}
                      >
                        {jarak}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <Eye size={14}/> Gaya Visual (Art Style)
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {GAYA_VISUAL_OPTIONS.map((gaya) => (
                      <button
                        key={gaya}
                        onClick={() => setInputs(prev => ({ ...prev, gayaVisual: gaya }))}
                        className={cn(
                          "px-3 py-1.5 rounded-lg text-xs font-bold border transition-all",
                          inputs.gayaVisual === gaya 
                            ? "bg-indigo-600 text-white border-indigo-600" 
                            : "bg-slate-50 dark:bg-slate-950 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:border-indigo-400"
                        )}
                      >
                        {gaya}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Anjuran Visual Tambahan</label>
                  <textarea 
                    name="anjuranVisual" 
                    value={inputs.anjuranVisual} 
                    onChange={handleInputChange}
                    placeholder="misal: Fokus pada pencahayaan dramatis..."
                    className="w-full h-24 p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-slate-900 dark:text-white resize-none text-sm"
                  />
                </div>
              </div>

              <button 
                onClick={generateScript}
                disabled={loading || !inputs.tema.trim()}
                className={cn(
                  "w-full py-5 rounded-2xl font-bold flex items-center justify-center gap-3 transition-all shadow-xl text-lg",
                  loading || !inputs.tema.trim()
                    ? "bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed"
                    : "bg-blue-600 hover:bg-blue-700 text-white shadow-blue-500/30 hover:-translate-y-1"
                )}
              >
                {loading ? <Loader2 className="animate-spin" size={24}/> : <Wand2 size={24}/>}
                {loading ? 'Memproses AI...' : 'Generate Naskah Otomatis'}
              </button>
            </div>
          </motion.div>
        )}

        {/* TAB 2: Script Result */}
        {activeTab === 'script' && (
          <motion.div
            key="script"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="max-w-5xl mx-auto space-y-8"
          >
            {loading ? (
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-16 shadow-sm flex flex-col items-center justify-center min-h-[400px]">
                <div className="relative w-20 h-20 mb-6">
                  <div className="absolute inset-0 rounded-full border-t-2 border-blue-600 animate-spin"></div>
                  <Wand2 className="absolute inset-0 m-auto w-8 h-8 text-blue-600 animate-pulse" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2 tracking-tight">Meracik Mahakarya</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400">AI sedang menganalisis fakta dan menyusun struktur cerita...</p>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {scriptData.rekomendasi_backsound && (
                    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 shadow-sm relative overflow-hidden group">
                      <div className="absolute -right-4 -bottom-4 opacity-5 group-hover:scale-110 transition-transform duration-500">
                        <Music size={120} />
                      </div>
                      <div className="flex items-center gap-3 mb-6">
                        <div className="p-2 bg-blue-50 dark:bg-blue-900/30 rounded-xl text-blue-600">
                          <Headphones size={20} />
                        </div>
                        <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Music Director</h4>
                      </div>
                      <div className="space-y-4">
                        <h3 className="text-2xl font-bold text-slate-900 dark:text-white">{scriptData.rekomendasi_backsound.genre}</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-800">
                            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-widest block mb-1">Mood</span>
                            <p className="text-slate-700 dark:text-slate-300 text-sm font-bold">{scriptData.rekomendasi_backsound.mood}</p>
                          </div>
                          <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-xl border border-blue-100 dark:border-blue-800">
                            <span className="text-[10px] text-blue-600 uppercase font-bold tracking-widest block mb-1">Keyword</span>
                            <p className="text-blue-700 dark:text-blue-300 text-sm font-bold">"{scriptData.rekomendasi_backsound.panduan_pencarian}"</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 shadow-sm relative overflow-hidden group">
                    {!voiceData ? (
                      <div className="flex flex-col items-center justify-center text-center h-full py-4 space-y-4">
                        <div className="p-4 bg-emerald-50 dark:bg-emerald-900/20 rounded-full text-emerald-600">
                          <Mic size={32} />
                        </div>
                        <div>
                          <h4 className="text-lg font-bold text-slate-900 dark:text-white">Butuh Pengisi Suara?</h4>
                          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-[200px] mx-auto">AI akan menganalisis persona suara terbaik untuk naskah ini.</p>
                        </div>
                        <button 
                          onClick={generateVoiceoverMeta}
                          disabled={loadingVoice}
                          className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 transition-all shadow-lg shadow-emerald-500/20"
                        >
                          {loadingVoice ? <Loader2 size={14} className="animate-spin"/> : <Sparkles size={14}/>}
                          Generate AI Voice Prompt
                        </button>
                      </div>
                    ) : (
                      <div className="animate-in fade-in duration-500">
                        <div className="flex items-center gap-3 mb-6">
                          <div className="p-2 bg-emerald-50 dark:bg-emerald-900/30 rounded-xl text-emerald-600">
                            <Mic size={20} />
                          </div>
                          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Voice Director</h4>
                        </div>
                        <div className="space-y-4">
                          <h3 className="text-2xl font-bold text-slate-900 dark:text-white">{voiceData.karakter}</h3>
                          <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-800">
                            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-widest block mb-1">Nada & Kecepatan</span>
                            <p className="text-slate-700 dark:text-slate-300 text-sm font-medium">{voiceData.nada_kecepatan}</p>
                          </div>
                          <div className="p-3 bg-emerald-50 dark:bg-emerald-900/20 rounded-xl border border-emerald-100 dark:border-emerald-800 relative group">
                            <button 
                              onClick={() => copyToClipboard(voiceData.ai_prompt, 'voice')} 
                              className="absolute top-3 right-3 text-emerald-600 hover:scale-110 transition-transform"
                            >
                               {copiedStates['voice'] ? <CheckCircle2 size={16}/> : <Copy size={16}/>}
                            </button>
                            <span className="text-[10px] text-emerald-600 uppercase font-bold tracking-widest block mb-1">ElevenLabs Prompt</span>
                            <p className="text-emerald-800 dark:text-emerald-200 text-xs font-mono pr-8 truncate">{voiceData.ai_prompt}</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 shadow-sm">
                  <div className="flex items-center gap-3 mb-8">
                    <div className="p-2 bg-blue-50 dark:bg-blue-900/30 rounded-xl text-blue-600">
                      <FileText size={20} />
                    </div>
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">Data Riset & Fakta Ilmiah</h3>
                  </div>
                  <div className="space-y-4">
                    {scriptData?.deskripsi?.split('\n').map((paragraph: string, index: number) => (
                      paragraph.trim() ? (
                        <p key={index} className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed">
                          {paragraph}
                        </p>
                      ) : null
                    ))}
                  </div>
                </div>

                <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 shadow-sm">
                  <div className="flex justify-between items-end mb-10 pb-6 border-b border-slate-100 dark:border-slate-800">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-indigo-50 dark:bg-indigo-900/30 rounded-xl text-indigo-600">
                        <Clapperboard size={20} />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">Final Script</h3>
                        <p className="text-xs text-slate-500 dark:text-slate-400">Naskah siap baca dengan durasi optimal.</p>
                      </div>
                    </div>
                    <span className="px-3 py-1 bg-slate-100 dark:bg-slate-800 rounded-lg text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                      {scriptData?.adegan?.length || 0} Scenes
                    </span>
                  </div>

                  <div className="space-y-6">
                    {scriptData?.adegan?.map((scene: any, idx: number) => (
                      <div key={idx} className="flex gap-6 group">
                        <div className="flex flex-col items-center">
                          <div className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-xs font-bold text-slate-500 group-hover:bg-blue-600 group-hover:text-white transition-all">
                            {idx + 1}
                          </div>
                          <div className="w-px flex-1 bg-slate-100 dark:bg-slate-800 my-2" />
                        </div>
                        <div className="flex-1 pb-8">
                          <div className="flex items-center gap-3 mb-2">
                            <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest">{scene.bagian}</span>
                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest bg-slate-50 dark:bg-slate-950 px-2 py-0.5 rounded">Nada: {scene.nada}</span>
                          </div>
                          <p className="text-slate-900 dark:text-white font-medium leading-relaxed">"{scene.narasi}"</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-12 pt-8 border-t border-slate-100 dark:border-slate-800">
                    <div className="flex items-center gap-3 mb-8">
                      <div className="p-2 bg-cyan-50 dark:bg-cyan-900/30 rounded-xl text-cyan-600">
                        <TrendingUp size={20} />
                      </div>
                      <h3 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">Toolkit Viral & SEO</h3>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                      {[
                        { id: 'title', label: 'Optimasi Judul', icon: Zap, action: generateTitleIdeas, loading: loadingTitleIdeas, data: titleIdeasData, color: 'text-indigo-500', bg: 'hover:bg-indigo-50 dark:hover:bg-indigo-900/20' },
                        { id: 'hook', label: 'Variasi Hook', icon: Magnet, action: generateAlternateHooks, loading: loadingHooks, data: hooksData, color: 'text-red-500', bg: 'hover:bg-red-50 dark:hover:bg-red-900/20' },
                        { id: 'social', label: 'Caption & SEO', icon: Hash, action: generateSocialMeta, loading: loadingSocial, data: socialMeta, color: 'text-cyan-500', bg: 'hover:bg-cyan-50 dark:hover:bg-cyan-900/20' },
                        { id: 'engagement', label: 'Interaksi', icon: Megaphone, action: generateEngagementPlan, loading: loadingEngagement, data: engagementData, color: 'text-orange-500', bg: 'hover:bg-orange-50 dark:hover:bg-orange-900/20' }
                      ].map((tool) => (
                        <button 
                          key={tool.id}
                          onClick={tool.action}
                          disabled={tool.loading || tool.data !== null}
                          className={cn(
                            "p-4 bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 rounded-2xl flex flex-col items-center justify-center text-center transition-all disabled:opacity-50",
                            tool.bg
                          )}
                        >
                          {tool.loading ? <Loader2 size={20} className="animate-spin mb-2"/> : <tool.icon size={20} className={cn("mb-2", tool.color)}/>}
                          <span className="text-[10px] font-bold text-slate-600 dark:text-slate-400 uppercase tracking-widest">{tool.label}</span>
                        </button>
                      ))}
                    </div>

                    <div className="space-y-6">
                      {titleIdeasData && (
                        <div className="p-6 bg-indigo-50 dark:bg-indigo-900/10 border border-indigo-100 dark:border-indigo-800 rounded-2xl animate-in slide-in-from-bottom-4">
                          <h4 className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest mb-4 flex items-center gap-2">
                            <Zap size={14}/> Variasi Judul (A/B Testing)
                          </h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            {[
                              { label: '🔥 Clickbait', val: titleIdeasData.judul_clickbait },
                              { label: '🔍 SEO Focus', val: titleIdeasData.judul_seo },
                              { label: '🤔 Penasaran', val: titleIdeasData.judul_penasaran },
                              { label: '📖 Storytelling', val: titleIdeasData.judul_storytelling },
                              { label: '⚡ Kontroversial', val: titleIdeasData.judul_kontroversial }
                            ].map((item, idx) => (
                              <div key={idx} className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800 flex justify-between items-center group">
                                <div>
                                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest block mb-1">{item.label}</span>
                                  <p className="text-sm font-medium text-slate-700 dark:text-slate-300">{item.val}</p>
                                </div>
                                <button onClick={() => copyToClipboard(item.val, `title-${idx}`)} className="text-slate-400 hover:text-indigo-600 transition-colors">
                                  {copiedStates[`title-${idx}`] ? <CheckCircle2 size={16}/> : <Copy size={16}/>}
                                </button>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {hooksData && (
                        <div className="p-6 bg-red-50 dark:bg-red-900/10 border border-red-100 dark:border-red-800 rounded-2xl animate-in slide-in-from-bottom-4">
                          <h4 className="text-[10px] font-bold text-red-600 uppercase tracking-widest mb-4 flex items-center gap-2">
                            <Magnet size={14}/> Alternatif Hook 3 Detik Pertama
                          </h4>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            {[
                              { label: 'Provokatif', val: hooksData.hook_pertanyaan },
                              { label: 'Fakta Gila', val: hooksData.hook_fakta },
                              { label: 'Emosional', val: hooksData.hook_emosional }
                            ].map((item, idx) => (
                              <div key={idx} className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800 relative group">
                                <button onClick={() => copyToClipboard(item.val, `hook-${idx}`)} className="absolute top-3 right-3 text-slate-400 hover:text-red-600">
                                  {copiedStates[`hook-${idx}`] ? <CheckCircle2 size={14}/> : <Copy size={14}/>}
                                </button>
                                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest block mb-2">{item.label}</span>
                                <p className="text-xs font-medium text-slate-700 dark:text-slate-300 leading-relaxed pr-6">"{item.val}"</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="mt-12 flex justify-end">
                    <button 
                      onClick={() => setActiveTab('visuals')}
                      className="px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-bold flex items-center gap-2 shadow-xl shadow-blue-500/20 transition-all hover:-translate-y-1"
                    >
                      Buka Visual Studio <ChevronRight size={20}/>
                    </button>
                  </div>
                </div>
              </>
            )}
          </motion.div>
        )}

        {/* TAB 3: Visual Studio */}
        {activeTab === 'visuals' && (
          <motion.div
            key="visuals"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="max-w-5xl mx-auto space-y-8"
          >
            <div className="p-6 bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800 rounded-3xl flex items-center gap-4">
              <div className="p-2 bg-blue-600 rounded-xl text-white">
                <Sparkles size={20} />
              </div>
              <p className="text-sm font-medium text-blue-800 dark:text-blue-200">Hasilkan ide visual dan prompt untuk setiap adegan secara spesifik.</p>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 shadow-sm relative overflow-hidden group">
              {!thumbnailData ? (
                <button 
                  onClick={generateThumbnailIdea}
                  disabled={loadingThumbnail}
                  className="w-full py-12 flex flex-col items-center justify-center gap-4 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl hover:bg-slate-50 dark:hover:bg-slate-950 transition-all"
                >
                  {loadingThumbnail ? <Loader2 size={32} className="animate-spin text-blue-600"/> : <MonitorPlay size={32} className="text-blue-600"/>}
                  <div className="text-center">
                    <h4 className="font-bold text-slate-900 dark:text-white">Rancang Cover / Thumbnail</h4>
                    <p className="text-xs text-slate-500">AI akan merancang ide visual thumbnail yang clicky.</p>
                  </div>
                </button>
              ) : (
                <div className="animate-in fade-in duration-500">
                  <div className="flex items-center gap-3 mb-8">
                    <div className="p-2 bg-purple-50 dark:bg-purple-900/30 rounded-xl text-purple-600">
                      <MonitorPlay size={20} />
                    </div>
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">Thumbnail Director</h3>
                  </div>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <div className="space-y-6">
                      <div className="p-8 bg-slate-900 rounded-3xl border border-slate-800 flex flex-col justify-center items-center text-center space-y-4 min-h-[240px] relative overflow-hidden">
                        <div className="absolute inset-0 bg-gradient-to-br from-purple-600/20 to-blue-600/20 opacity-50"></div>
                        <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest relative z-10">Preview Teks Thumbnail</span>
                        <h2 className="text-4xl font-black text-white italic uppercase leading-tight relative z-10 drop-shadow-2xl">
                          "{thumbnailData.teks_thumbnail}"
                        </h2>
                      </div>
                      
                      <div className="p-6 bg-blue-50 dark:bg-blue-900/20 rounded-2xl border border-blue-100 dark:border-blue-800 space-y-2">
                        <span className="text-[10px] text-blue-600 dark:text-blue-400 font-bold uppercase tracking-widest flex items-center gap-2">
                          <Sparkles size={12}/> Strategi Psikologis
                        </span>
                        <p className="text-sm text-blue-900 dark:text-blue-100 italic">"{thumbnailData.alasan_desain}"</p>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-800">
                        <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest block mb-1">Elemen Visual Utama</span>
                        <p className="text-sm text-slate-700 dark:text-slate-300 font-medium">{thumbnailData.elemen_visual}</p>
                      </div>
                      <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-800">
                        <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest block mb-1">Suasana & Mood</span>
                        <p className="text-sm text-slate-700 dark:text-slate-300 font-medium">{thumbnailData.suasana}</p>
                      </div>
                      <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-xl border border-purple-100 dark:border-purple-800 space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-[10px] text-purple-600 dark:text-purple-400 font-bold uppercase tracking-widest">Image Prompt (AI Generator)</span>
                          <button 
                            onClick={() => copyToClipboard(thumbnailData.image_prompt, 'thumb-prompt')}
                            className="p-1.5 hover:bg-purple-100 dark:hover:bg-purple-900/50 rounded-lg transition-colors text-purple-600"
                          >
                            {copiedStates['thumb-prompt'] ? <Check size={14}/> : <Copy size={14}/>}
                          </button>
                        </div>
                        <p className="text-xs text-purple-900 dark:text-purple-200 font-mono leading-relaxed bg-white/50 dark:bg-black/30 p-3 rounded-lg border border-purple-100/50 dark:border-purple-800/50">
                          {thumbnailData.image_prompt}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="space-y-6">
              {scriptData?.adegan?.map((scene: any, idx: number) => {
                const isGenerated = !!visualPrompts[idx];
                const isLoading = loadingScene === idx;
                return (
                  <div key={idx} className={cn(
                    "bg-white dark:bg-slate-900 border rounded-3xl overflow-hidden transition-all duration-300",
                    isGenerated ? "border-blue-200 dark:border-blue-900/50 shadow-md" : "border-slate-200 dark:border-slate-800"
                  )}>
                    <div className="p-8">
                      <div className="flex justify-between items-center mb-6">
                        <div className="flex items-center gap-4">
                          <span className="px-3 py-1 bg-slate-900 text-white text-[10px] font-bold rounded-lg">SCENE {idx + 1}</span>
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{scene.bagian}</span>
                        </div>
                        {!isGenerated ? (
                          <button 
                            onClick={() => generateVisualPromptForScene(idx, scene)}
                            disabled={isLoading}
                            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 transition-all shadow-lg shadow-blue-500/20"
                          >
                            {isLoading ? <Loader2 size={14} className="animate-spin"/> : <Eye size={14}/>}
                            Rancang Visual
                          </button>
                        ) : (
                          <button 
                            onClick={() => generateVisualPromptForScene(idx, scene)}
                            disabled={isLoading}
                            className="text-[10px] font-bold text-slate-400 hover:text-blue-600 flex items-center gap-1"
                          >
                            <RefreshCw size={12} className={cn(isLoading && "animate-spin")}/> Regenerate
                          </button>
                        )}
                      </div>

                      <p className="text-xl font-bold text-slate-900 dark:text-white leading-relaxed mb-8">"{scene.narasi}"</p>

                      {isGenerated && (
                        <div className="space-y-6 animate-in fade-in duration-500">
                          <div className="p-5 bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800 rounded-2xl">
                            <div className="flex items-center gap-2 text-blue-600 mb-2">
                              <Eye size={16} />
                              <span className="text-[10px] font-bold uppercase tracking-widest">Penjelasan Visual</span>
                            </div>
                            <p className="text-sm text-blue-900 dark:text-blue-100 font-medium leading-relaxed">{visualPrompts[idx].penjelasan_visual}</p>
                          </div>

                          <div className="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden">
                            <div className="px-4 py-3 border-b border-slate-800 flex justify-between items-center">
                              <div className="flex items-center gap-2">
                                <Sparkles size={14} className="text-blue-400" />
                                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Final Studio Prompt</span>
                              </div>
                              <button onClick={() => copyToClipboard(visualPrompts[idx].final_prompt, `prompt-${idx}`)} className="text-slate-500 hover:text-white transition-colors">
                                {copiedStates[`prompt-${idx}`] ? <CheckCircle2 size={14}/> : <Copy size={14}/>}
                              </button>
                            </div>
                            <div className="p-5">
                              <p className="text-xs font-mono text-slate-300 leading-relaxed whitespace-pre-wrap">{visualPrompts[idx].final_prompt}</p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
