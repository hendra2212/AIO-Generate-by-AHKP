export type Feature = 'dashboard' | 'calendar' | 'static' | 'lipsync' | 'affiliate' | 'voiceover' | 'graphic-design' | 'logo-design' | 'education-promotion';

export interface PromptTemplate {
  id: string;
  name: string;
  description: string;
  template: string;
  category: Feature;
}

export interface ContentItem {
  id: string;
  title: string;
  date: string;
  type: string;
  status: 'planned' | 'completed' | 'in-progress';
}
